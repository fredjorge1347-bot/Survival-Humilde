package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DelHomeCommand implements CommandExecutor {

    private final Main plugin;

    public DelHomeCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Uso: /delhome <nome>");
            return true;
        }

        String name = args[0].toLowerCase();
        boolean deleted = plugin.getHomeManager().deleteHome(player.getUniqueId(), name);

        if (deleted) {
            player.sendMessage(ChatColor.GREEN + "Home '" + name + "' removida.");
        } else {
            player.sendMessage(ChatColor.RED + "Home '" + name + "' nao encontrada.");
        }
        return true;
    }
}
