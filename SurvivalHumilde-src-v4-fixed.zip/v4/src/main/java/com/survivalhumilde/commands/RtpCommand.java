package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;
import java.util.Set;

/**
 * Teleporte Aleatório Simples e Estável.
 *
 * Usa world.getHighestBlockAt() em vez de ChunkGenerator ou APIs de bioma
 * para evitar o VerifyError que ocorre com biomas customizados (Geyser/mods).
 *
 * Fluxo:
 * 1. Escolhe X e Z aleatórios dentro do raio configurado.
 * 2. Obtém a altura mais alta naquela coluna (síncrono na thread principal).
 * 3. Verifica se o bloco é seguro (não é lava, não é void, etc.).
 * 4. Teleporta o jogador.
 *
 * Tentativas máximas: 10. Se nenhum local seguro for encontrado, avisa o jogador.
 */
public class RtpCommand implements CommandExecutor {

    private final Main plugin;
    private final Random random = new Random();

    // Blocos considerados inseguros para pousar
    private static final Set<Material> UNSAFE_GROUND = Set.of(
            Material.LAVA, Material.WATER, Material.FIRE,
            Material.MAGMA_BLOCK, Material.CACTUS, Material.CAMPFIRE,
            Material.SOUL_CAMPFIRE, Material.SWEET_BERRY_BUSH
    );

    private static final Set<Material> UNSAFE_FEET = Set.of(
            Material.LAVA, Material.FIRE, Material.MAGMA_BLOCK,
            Material.CACTUS, Material.SWEET_BERRY_BUSH
    );

    public RtpCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        String worldName = plugin.getConfig().getString("rtp.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            player.sendMessage(ChatColor.RED + "Mundo de RTP nao encontrado.");
            return true;
        }

        int minR = plugin.getConfig().getInt("rtp.min-radius", 100);
        int maxR = plugin.getConfig().getInt("rtp.max-radius", 5000);

        player.sendMessage(ChatColor.YELLOW + "Procurando local seguro...");

        // Toda a lógica roda na thread principal pois getHighestBlockAt
        // acessa dados do mundo que não são thread-safe.
        // É simples o suficiente para não causar lag perceptível.
        findAndTeleport(player, world, minR, maxR, 10);

        return true;
    }

    /**
     * Tenta até maxAttempts vezes encontrar um local seguro.
     * Roda tudo na thread principal (sem async) para usar getHighestBlockAt
     * de forma segura e evitar qualquer VerifyError de bioma.
     */
    private void findAndTeleport(Player player, World world, int minR, int maxR, int attemptsLeft) {
        if (attemptsLeft <= 0) {
            player.sendMessage(ChatColor.RED + "Nao foi possivel encontrar local seguro. Tente novamente.");
            return;
        }

        // Gera coordenadas aleatórias em anel (entre minR e maxR)
        int range = maxR - minR;
        int x = (random.nextBoolean() ? 1 : -1) * (minR + random.nextInt(range));
        int z = (random.nextBoolean() ? 1 : -1) * (minR + random.nextInt(range));

        // getHighestBlockAt é a API mais estável e simples — sem biomas, sem chunk gen
        @SuppressWarnings("deprecation")
        Block highest = world.getHighestBlockAt(x, z);
        int y = highest.getY();

        // Verificações de segurança simples
        if (y <= world.getMinHeight()) {
            // Coluna vazia (void) — tentar de novo
            plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> findAndTeleport(player, world, minR, maxR, attemptsLeft - 1), 1L);
            return;
        }

        Block groundBlock = world.getBlockAt(x, y, z);
        Block feetBlock   = world.getBlockAt(x, y + 1, z);
        Block headBlock   = world.getBlockAt(x, y + 2, z);

        // O bloco do chão não pode ser inseguro
        if (UNSAFE_GROUND.contains(groundBlock.getType())) {
            plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> findAndTeleport(player, world, minR, maxR, attemptsLeft - 1), 1L);
            return;
        }

        // Os blocos dos pés e da cabeça devem ser passáveis (ar, grama alta, etc.)
        if (!feetBlock.isPassable() || !headBlock.isPassable()) {
            plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> findAndTeleport(player, world, minR, maxR, attemptsLeft - 1), 1L);
            return;
        }

        // Local seguro encontrado!
        Location dest = new Location(world, x + 0.5, y + 1, z + 0.5);

        if (!player.isOnline()) return;
        player.teleport(dest);
        player.sendMessage(ChatColor.GREEN + "Teleportado! Coordenadas: "
                + ChatColor.WHITE + x + ", " + y + ", " + z);
    }
}
