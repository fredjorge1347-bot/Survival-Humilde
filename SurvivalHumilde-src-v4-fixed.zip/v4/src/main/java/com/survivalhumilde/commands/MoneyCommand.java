package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MoneyCommand implements CommandExecutor {

    private final Main plugin;

    public MoneyCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (args.length == 0) {
            // Ver o próprio saldo
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Use: /money <jogador>");
                return true;
            }
            double bal = plugin.getEconomy().getBalance(player);
            player.sendMessage(ChatColor.GREEN + "Saldo: " + ChatColor.YELLOW + plugin.getEconomy().format(bal));
            return true;
        }

        // Ver saldo de outro jogador (qualquer um pode usar)
        String targetName = args[0];

        // Busca async para não travar ao procurar jogador offline
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            @SuppressWarnings("deprecation")
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);

            // Verifica se já jogou antes
            if (!target.hasPlayedBefore() && !target.isOnline()) {
                Bukkit.getScheduler().runTask(plugin, () ->
                    sender.sendMessage(ChatColor.RED + "Jogador nao encontrado."));
                return;
            }

            double bal = plugin.getEconomy().getBalance(target);
            Bukkit.getScheduler().runTask(plugin, () ->
                sender.sendMessage(ChatColor.GREEN + "Saldo de " + target.getName() + ": "
                        + ChatColor.YELLOW + plugin.getEconomy().format(bal)));
        });

        return true;
    }
}
