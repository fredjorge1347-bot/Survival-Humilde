package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class TpDenyCommand implements CommandExecutor {

    private final Main plugin;

    public TpDenyCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player target)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        UUID requesterId = plugin.getTpaManager().getPendingRequesterFor(target.getUniqueId());

        if (requesterId == null) {
            target.sendMessage(ChatColor.RED + "Nenhum pedido de TPA pendente.");
            return true;
        }

        Player requester = Bukkit.getPlayer(requesterId);
        plugin.getTpaManager().cancelRequest(requesterId);

        target.sendMessage(ChatColor.YELLOW + "Pedido de TPA recusado.");
        if (requester != null && requester.isOnline()) {
            requester.sendMessage(ChatColor.RED + target.getName() + " recusou seu pedido de TPA.");
        }

        return true;
    }
}
