package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand implements CommandExecutor {

    private final Main plugin;

    public PayCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores podem usar este comando.");
            return true;
        }

        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Uso: /pay <jogador> <quantia>");
            return true;
        }

        String targetName = args[0];
        double amount;

        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Quantia invalida.");
            return true;
        }

        if (amount <= 0) {
            player.sendMessage(ChatColor.RED + "A quantia deve ser maior que zero.");
            return true;
        }

        if (targetName.equalsIgnoreCase(player.getName())) {
            player.sendMessage(ChatColor.RED + "Voce nao pode se pagar.");
            return true;
        }

        // Buscar jogador online apenas (pay é transação ativa)
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null || !target.isOnline()) {
            player.sendMessage(ChatColor.RED + "Jogador nao encontrado ou offline.");
            return true;
        }

        // Verificar saldo e realizar transferência na thread principal
        if (!plugin.getEconomy().has(player, amount)) {
            player.sendMessage(ChatColor.RED + "Saldo insuficiente!");
            return true;
        }

        plugin.getEconomy().withdraw(player, amount);
        plugin.getEconomy().deposit(target, amount);

        String formatted = plugin.getEconomy().format(amount);
        player.sendMessage(ChatColor.GREEN + "Voce pagou " + formatted + " para " + target.getName() + ".");
        target.sendMessage(ChatColor.GREEN + player.getName() + " te enviou " + formatted + "!");

        return true;
    }
}
