package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ServicoCommand implements CommandExecutor {

    private final Main plugin;
    // UUID -> timestamp do último uso (em ms)
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public ServicoCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Uso: /servico <mensagem>");
            player.sendMessage(ChatColor.GRAY + "Ex: /servico Faço casas por 500 moedas!");
            return true;
        }

        int cooldownSeconds = plugin.getConfig().getInt("servico.cooldown-seconds", 120);
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();

        // Verificar cooldown
        if (cooldowns.containsKey(uuid)) {
            long lastUse = cooldowns.get(uuid);
            long elapsed = (now - lastUse) / 1000;
            if (elapsed < cooldownSeconds) {
                long remaining = cooldownSeconds - elapsed;
                player.sendMessage(ChatColor.RED + "Aguarde " + remaining + "s para anunciar novamente.");
                return true;
            }
        }

        // Montar a mensagem do serviço
        String mensagem = String.join(" ", args);

        // Limitar tamanho da mensagem (amigável para mobile)
        if (mensagem.length() > 120) {
            player.sendMessage(ChatColor.RED + "Mensagem muito longa! Maximo: 120 caracteres.");
            return true;
        }

        // Registrar cooldown
        cooldowns.put(uuid, now);

        // Broadcast formatado — cores simples para compatibilidade mobile/Geyser
        Bukkit.broadcastMessage(ChatColor.GOLD + "========[ SERVICO ]========");
        Bukkit.broadcastMessage(ChatColor.YELLOW + "[" + player.getName() + "] "
                + ChatColor.WHITE + mensagem);
        Bukkit.broadcastMessage(ChatColor.GRAY + "Contato: " + ChatColor.AQUA + player.getName());
        Bukkit.broadcastMessage(ChatColor.GOLD + "===========================");

        player.sendMessage(ChatColor.GREEN + "Anuncio enviado com sucesso!");

        return true;
    }
}
