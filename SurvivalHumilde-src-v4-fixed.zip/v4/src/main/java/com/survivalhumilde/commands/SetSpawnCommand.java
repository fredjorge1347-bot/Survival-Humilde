package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand implements CommandExecutor {

    private final Main plugin;

    public SetSpawnCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }
        if (!player.hasPermission("survivalhumilde.admin")) {
            player.sendMessage(ChatColor.RED + "Sem permissao.");
            return true;
        }

        plugin.getDataManager().setSpawn(player.getLocation());
        player.sendMessage(ChatColor.GREEN + "Spawn definido aqui!");
        return true;
    }
}
