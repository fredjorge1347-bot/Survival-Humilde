package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class HomeCommand implements CommandExecutor {

    private final Main plugin;

    public HomeCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        Map<String, Location> homes = plugin.getHomeManager().getHomes(player.getUniqueId());

        // Sem argumentos: ir para "home" ou listar
        if (args.length == 0) {
            if (homes.isEmpty()) {
                player.sendMessage(ChatColor.YELLOW + "Voce nao tem homes. Use /sethome.");
                return true;
            }
            if (homes.containsKey("home")) {
                teleportHome(player, "home", homes.get("home"));
                return true;
            }
            // Listar homes disponíveis
            player.sendMessage(ChatColor.YELLOW + "Suas homes: " + ChatColor.WHITE + String.join(", ", homes.keySet()));
            player.sendMessage(ChatColor.GRAY + "Use /home <nome>");
            return true;
        }

        String name = args[0].toLowerCase();
        Location loc = homes.get(name);

        if (loc == null) {
            player.sendMessage(ChatColor.RED + "Home '" + name + "' nao encontrada.");
            if (!homes.isEmpty()) {
                player.sendMessage(ChatColor.GRAY + "Suas homes: " + String.join(", ", homes.keySet()));
            }
            return true;
        }

        teleportHome(player, name, loc);
        return true;
    }

    private void teleportHome(Player player, String name, Location loc) {
        int delay = plugin.getConfig().getInt("teleport.teleport-delay", 3);
        Location startLoc = player.getLocation().clone();

        player.sendMessage(ChatColor.YELLOW + "Teleportando para '" + name + "' em " + delay + "s...");

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            if (player.getLocation().distanceSquared(startLoc) > 1.0) {
                player.sendMessage(ChatColor.RED + "Teleporte cancelado! Voce se moveu.");
                return;
            }
            player.teleport(loc);
            player.sendMessage(ChatColor.GREEN + "Chegou em '" + name + "'!");
        }, delay * 20L);
    }
}
