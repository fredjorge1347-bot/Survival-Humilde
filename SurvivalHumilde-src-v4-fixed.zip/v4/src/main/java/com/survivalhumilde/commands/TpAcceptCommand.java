package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class TpAcceptCommand implements CommandExecutor {

    private final Main plugin;

    public TpAcceptCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player target)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        UUID requesterId = plugin.getTpaManager().getPendingRequesterFor(target.getUniqueId());

        if (requesterId == null) {
            target.sendMessage(ChatColor.RED + "Nenhum pedido de TPA pendente.");
            return true;
        }

        Player requester = Bukkit.getPlayer(requesterId);

        // Cancela o pedido antes de teleportar
        plugin.getTpaManager().cancelRequest(requesterId);

        if (requester == null || !requester.isOnline()) {
            target.sendMessage(ChatColor.RED + "O jogador ficou offline.");
            return true;
        }

        int delay = plugin.getConfig().getInt("teleport.teleport-delay", 3);

        requester.sendMessage(ChatColor.GREEN + target.getName() + " aceitou! Teleportando em " + delay + "s...");
        target.sendMessage(ChatColor.GREEN + "TPA aceito! " + requester.getName() + " chegara em " + delay + "s.");

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!requester.isOnline() || !target.isOnline()) return;
            requester.teleport(target.getLocation());
            requester.sendMessage(ChatColor.GREEN + "Teleportado para " + target.getName() + "!");
        }, delay * 20L);

        return true;
    }
}
