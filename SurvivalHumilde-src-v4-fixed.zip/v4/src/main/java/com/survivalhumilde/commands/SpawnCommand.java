package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand implements CommandExecutor {

    private final Main plugin;

    public SpawnCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        int delay = plugin.getConfig().getInt("teleport.teleport-delay", 3);

        player.sendMessage(ChatColor.YELLOW + "Teleportando ao spawn em " + delay + "s...");

        // Guardar posição para detectar movimento (anti-abuse)
        Location startLoc = player.getLocation().clone();

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            // Verificar se o jogador se moveu
            if (player.getLocation().distanceSquared(startLoc) > 1.0) {
                player.sendMessage(ChatColor.RED + "Teleporte cancelado! Voce se moveu.");
                return;
            }
            Location spawn = plugin.getDataManager().getSpawn();
            player.teleport(spawn);
            player.sendMessage(ChatColor.GREEN + "Bem-vindo(a) ao spawn!");
        }, delay * 20L);

        return true;
    }
}
