package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpaCommand implements CommandExecutor {

    private final Main plugin;

    public TpaCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Uso: /tpa <jogador>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            player.sendMessage(ChatColor.RED + "Jogador nao encontrado ou offline.");
            return true;
        }

        if (target.equals(player)) {
            player.sendMessage(ChatColor.RED + "Voce nao pode pedir TPA para si mesmo.");
            return true;
        }

        int timeout = plugin.getConfig().getInt("teleport.tpa-timeout", 60);

        plugin.getTpaManager().sendRequest(player, target);

        player.sendMessage(ChatColor.YELLOW + "Pedido de TPA enviado para " + target.getName() + ".");
        player.sendMessage(ChatColor.GRAY + "Expira em " + timeout + "s.");

        target.sendMessage(ChatColor.AQUA + player.getName() + ChatColor.YELLOW + " quer se teleportar ate voce.");
        target.sendMessage(ChatColor.GREEN + "/tpaccept " + ChatColor.RED + "/tpdeny");

        return true;
    }
}
