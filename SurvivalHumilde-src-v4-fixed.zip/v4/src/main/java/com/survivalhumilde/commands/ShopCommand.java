package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import com.survivalhumilde.shop.ShopItem;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {

    private final Main plugin;

    public ShopCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        // /loja — abre GUI
        if (args.length == 0) {
            plugin.getShopGUI().openMain(player);
            return true;
        }

        // /loja <item> — ver preço
        if (args.length == 1) {
            String name = args[0];
            ShopItem si = plugin.getShopManager().findByName(name);
            if (si == null) {
                player.sendMessage(ChatColor.RED + "Item nao encontrado: " + name);
                player.sendMessage(ChatColor.GRAY + "Use /loja para ver todos os itens.");
                return true;
            }
            player.sendMessage(ChatColor.YELLOW + "=== " + si.getDisplayName() + " ===");
            player.sendMessage(ChatColor.GREEN + "Comprar: " + plugin.getEconomy().format(si.getBuyPrice()));
            if (si.getSellPrice() > 0) {
                player.sendMessage(ChatColor.GOLD + "Vender: " + plugin.getEconomy().format(si.getSellPrice()));
            }
            return true;
        }

        // /loja comprar <item> [qtd]
        // /loja vender <item> [qtd]
        if (args.length >= 2) {
            String action = args[0].toLowerCase();
            String name = args[1];
            int qty = 1;

            if (args.length >= 3) {
                try { qty = Integer.parseInt(args[2]); }
                catch (NumberFormatException e) {
                    player.sendMessage(ChatColor.RED + "Quantidade invalida.");
                    return true;
                }
            }

            qty = Math.max(1, Math.min(64, qty));

            ShopItem si = plugin.getShopManager().findByName(name);
            if (si == null) {
                player.sendMessage(ChatColor.RED + "Item nao encontrado: " + name);
                return true;
            }

            if (action.equals("comprar") || action.equals("c")) {
                plugin.getShopGUI().openBuyConfirm(player, si, qty);
            } else if (action.equals("vender") || action.equals("v")) {
                if (si.getSellPrice() <= 0) {
                    player.sendMessage(ChatColor.RED + "Este item nao pode ser vendido.");
                    return true;
                }
                plugin.getShopGUI().openSellConfirm(player, si, qty);
            } else {
                player.sendMessage(ChatColor.RED + "Uso: /loja [comprar|vender] <item> [qtd]");
            }
        }

        return true;
    }
}
