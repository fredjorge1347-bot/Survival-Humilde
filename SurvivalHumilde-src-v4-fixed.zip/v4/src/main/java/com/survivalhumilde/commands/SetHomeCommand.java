package com.survivalhumilde.commands;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetHomeCommand implements CommandExecutor {

    private final Main plugin;

    public SetHomeCommand(Main plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        String name = (args.length > 0) ? args[0].toLowerCase() : "home";

        // Validar nome
        if (!name.matches("[a-z0-9_]{1,16}")) {
            player.sendMessage(ChatColor.RED + "Nome invalido. Use letras, numeros e _.");
            return true;
        }

        boolean success = plugin.getHomeManager().setHome(
                player.getUniqueId(), name, player.getLocation());

        if (success) {
            player.sendMessage(ChatColor.GREEN + "Home '" + name + "' definida!");
        } else {
            player.sendMessage(ChatColor.RED + "Limite de homes atingido ("
                    + plugin.getHomeManager().getMaxHomes() + ").");
        }
        return true;
    }
}
