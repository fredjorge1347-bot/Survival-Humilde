package com.survivalhumilde.arena;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ArenaManager {

    private final Main plugin;
    private final Map<String, ArenaMatch> matches = new LinkedHashMap<>();
    private final Map<UUID, String> playerMatch = new HashMap<>();  // player -> matchId
    private Location arenaSpawnA;
    private Location arenaSpawnB;
    private File configFile;
    private FileConfiguration arenaConfig;

    public ArenaManager(Main plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    private void loadConfig() {
        configFile = new File(plugin.getDataFolder(), "arena.yml");
        if (!configFile.exists()) try { configFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        arenaConfig = YamlConfiguration.loadConfiguration(configFile);
        arenaSpawnA = loadLocation("spawn-a");
        arenaSpawnB = loadLocation("spawn-b");
    }

    private Location loadLocation(String key) {
        if (!arenaConfig.contains(key + ".world")) return null;
        World world = Bukkit.getWorld(arenaConfig.getString(key + ".world", "world"));
        if (world == null) return null;
        return new Location(world,
                arenaConfig.getDouble(key + ".x"),
                arenaConfig.getDouble(key + ".y"),
                arenaConfig.getDouble(key + ".z"),
                (float) arenaConfig.getDouble(key + ".yaw"), 0);
    }

    public void setArenaSpawn(String which, Location loc) {
        arenaConfig.set("spawn-" + which + ".world", loc.getWorld() != null ? loc.getWorld().getName() : "world");
        arenaConfig.set("spawn-" + which + ".x", loc.getX());
        arenaConfig.set("spawn-" + which + ".y", loc.getY());
        arenaConfig.set("spawn-" + which + ".z", loc.getZ());
        arenaConfig.set("spawn-" + which + ".yaw", (double) loc.getYaw());
        try { arenaConfig.save(configFile); } catch (IOException e) { e.printStackTrace(); }
        if (which.equals("a")) arenaSpawnA = loc;
        else arenaSpawnB = loc;
    }

    public Location getArenaSpawnA() { return arenaSpawnA; }
    public Location getArenaSpawnB() { return arenaSpawnB; }
    public boolean hasArenaSetup() { return arenaSpawnA != null && arenaSpawnB != null; }

    public ArenaMatch createMatch(UUID creator, ArenaMatch.Mode mode, boolean betting) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        ArenaMatch match = new ArenaMatch(id, mode, betting, creator);
        matches.put(id, match);
        playerMatch.put(creator, id);
        return match;
    }

    public boolean joinMatch(UUID player, String matchId) {
        ArenaMatch match = matches.get(matchId);
        if (match == null || match.getState() != ArenaMatch.State.WAITING) return false;
        if (isInMatch(player)) return false;
        if (!match.teamBFull()) {
            match.getTeamB().add(player);
            playerMatch.put(player, matchId);
            return true;
        }
        return false;
    }

    public boolean isInMatch(UUID player) { return playerMatch.containsKey(player); }

    public ArenaMatch getMatchOfPlayer(UUID player) {
        String id = playerMatch.get(player);
        return id == null ? null : matches.get(id);
    }

    public ArenaMatch getMatch(String id) { return matches.get(id); }

    public Collection<ArenaMatch> getOpenMatches() {
        List<ArenaMatch> open = new ArrayList<>();
        for (ArenaMatch m : matches.values()) {
            if (m.getState() == ArenaMatch.State.WAITING && !m.isFull()) open.add(m);
        }
        return open;
    }

    public void startMatch(ArenaMatch match) {
        if (!hasArenaSetup()) return;
        match.setState(ArenaMatch.State.IN_PROGRESS);

        // Salvar e teleportar todos
        List<UUID> teamA = match.getTeamA();
        List<UUID> teamB = match.getTeamB();

        for (UUID uuid : teamA) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            match.saveLocation(uuid, p.getLocation());
            match.saveInventory(uuid, p.getInventory().getContents(), p.getInventory().getArmorContents());
            p.getInventory().clear();
            p.teleport(arenaSpawnA);
        }
        for (UUID uuid : teamB) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            match.saveLocation(uuid, p.getLocation());
            match.saveInventory(uuid, p.getInventory().getContents(), p.getInventory().getArmorContents());
            p.getInventory().clear();
            p.teleport(arenaSpawnB);
        }

        // Dar kit básico de arena
        giveArenaKit(match);

        broadcastMatch(match, "§c⚔ §eA batalha começou! §c" + match.getMode().name() + (match.isBetting() ? " §6[COM APOSTA]" : ""));
    }

    private void giveArenaKit(ArenaMatch match) {
        for (UUID uuid : match.getAllPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            p.getInventory().addItem(new ItemStack(org.bukkit.Material.IRON_SWORD));
            p.getInventory().addItem(new ItemStack(org.bukkit.Material.BOW));
            p.getInventory().addItem(new ItemStack(org.bukkit.Material.ARROW, 16));
            p.getInventory().addItem(new ItemStack(org.bukkit.Material.COOKED_BEEF, 8));
            p.getInventory().setHelmet(new ItemStack(org.bukkit.Material.IRON_HELMET));
            p.getInventory().setChestplate(new ItemStack(org.bukkit.Material.IRON_CHESTPLATE));
            p.getInventory().setLeggings(new ItemStack(org.bukkit.Material.IRON_LEGGINGS));
            p.getInventory().setBoots(new ItemStack(org.bukkit.Material.IRON_BOOTS));
            p.setHealth(20);
            p.setFoodLevel(20);
        }
    }

    public void endMatch(ArenaMatch match, List<UUID> winners, List<UUID> losers) {
        match.setState(ArenaMatch.State.FINISHED);

        // Distribui apostas para os vencedores
        if (match.isBetting()) {
            List<ItemStack> allBets = new ArrayList<>();
            for (UUID loser : losers) {
                List<ItemStack> bet = match.getBetItems().get(loser);
                if (bet != null) allBets.addAll(bet);
            }
            // Retorna apostas dos vencedores + pega itens dos perdedores
            for (UUID loser : losers) {
                List<ItemStack> bet = match.getBetItems().get(loser);
                if (bet != null) {
                    // Dar para o vencedor
                    for (UUID winner : winners) {
                        Player wp = Bukkit.getPlayer(winner);
                        if (wp != null) {
                            for (ItemStack item : bet) {
                                if (item != null) wp.getInventory().addItem(item);
                            }
                        }
                    }
                }
            }
        }

        // Restaura inventários e teleporta de volta
        for (UUID uuid : match.getAllPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            p.getInventory().clear();
            ItemStack[] inv = match.getSavedInventory(uuid);
            ItemStack[] armor = match.getSavedArmor(uuid);
            if (inv != null) p.getInventory().setContents(inv);
            if (armor != null) p.getInventory().setArmorContents(armor);
            p.setHealth(20);
            p.setFoodLevel(20);
            Location saved = match.getSavedLocation(uuid);
            if (saved != null) p.teleport(saved);
        }

        // Mensagens
        for (UUID w : winners) {
            Player wp = Bukkit.getPlayer(w);
            if (wp != null) wp.sendMessage("§a§l★ VOCÊ VENCEU! ★" + (match.isBetting() ? " §6Apostas adicionadas ao inventário!" : ""));
        }
        for (UUID l : losers) {
            Player lp = Bukkit.getPlayer(l);
            if (lp != null) lp.sendMessage("§c§lVocê perdeu a batalha." + (match.isBetting() ? " §cSeus itens apostados foram ao vencedor." : ""));
        }

        broadcastMatch(match, "§c⚔ §eBatalha encerrada! Vencedor: §a" + getNames(winners));

        // Remover partida
        for (UUID uuid : match.getAllPlayers()) playerMatch.remove(uuid);
        matches.remove(match.getId());
    }

    public void forfeitMatch(UUID player) {
        ArenaMatch match = getMatchOfPlayer(player);
        if (match == null || match.getState() != ArenaMatch.State.IN_PROGRESS) return;
        List<UUID> losers = match.isTeamA(player) ? match.getTeamA() : match.getTeamB();
        List<UUID> winners = match.isTeamA(player) ? match.getTeamB() : match.getTeamA();
        endMatch(match, winners, losers);
    }

    private String getNames(List<UUID> players) {
        StringBuilder sb = new StringBuilder();
        for (UUID uuid : players) {
            org.bukkit.OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            if (sb.length() > 0) sb.append(", ");
            sb.append(op.getName());
        }
        return sb.toString();
    }

    private void broadcastMatch(ArenaMatch match, String msg) {
        for (UUID uuid : match.getAllPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
    }
}
