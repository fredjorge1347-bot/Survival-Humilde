package com.survivalhumilde.arena;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArenaGUI {

    private final Main plugin;

    public ArenaGUI(Main plugin) {
        this.plugin = plugin;
    }

    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§c⚔ Arena PvP");

        inv.setItem(10, buildItem(Material.IRON_SWORD, "§e1v1 Sem Aposta",
                Arrays.asList("§7Duela 1x1 sem apostar itens.", "§7Kit de arena fornecido.", "", "§aClique para criar")));
        inv.setItem(11, buildItem(Material.DIAMOND_SWORD, "§61v1 Com Aposta",
                Arrays.asList("§7Duela 1x1 apostando itens.", "§7Vencedor leva os itens.", "", "§aClique para criar")));
        inv.setItem(13, buildItem(Material.CROSSBOW, "§e2v2 Sem Aposta",
                Arrays.asList("§7Batalha em equipe 2v2.", "§7Kit de arena fornecido.", "", "§aClique para criar")));
        inv.setItem(14, buildItem(Material.NETHERITE_SWORD, "§62v2 Com Aposta",
                Arrays.asList("§7Batalha 2v2 apostando itens.", "§7Time vencedor leva tudo.", "", "§aClique para criar")));
        inv.setItem(16, buildItem(Material.BOOK, "§bPartidas Abertas",
                Arrays.asList("§7Veja partidas aguardando jogadores.", "", "§aClique para ver")));

        player.openInventory(inv);
    }

    public void openOpenMatches(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§b📋 Partidas Abertas");
        int slot = 0;
        for (ArenaMatch match : plugin.getArenaManager().getOpenMatches()) {
            if (slot >= 54) break;
            String mode = match.getMode() == ArenaMatch.Mode.DUEL_1v1 ? "1v1" : "2v2";
            String type = match.isBetting() ? "§6COM APOSTA" : "§aSEM APOSTA";
            Material mat = match.isBetting() ? Material.GOLD_INGOT : Material.IRON_INGOT;
            String creator = Bukkit.getOfflinePlayer(match.getTeamA().get(0)).getName();
            inv.setItem(slot++, buildItem(mat, "§e" + mode + " " + type,
                    Arrays.asList("§7Criado por: §f" + creator,
                            "§7Jogadores: §f" + match.getAllPlayers().size() + "/" + (match.getMaxPerTeam() * 2),
                            "", "§aClique para entrar",
                            "§8ID: " + match.getId())));
        }
        if (slot == 0) inv.setItem(22, buildItem(Material.BARRIER, "§cNenhuma partida disponível", List.of()));
        player.openInventory(inv);
    }

    public void openBetMenu(Player player, ArenaMatch match) {
        Inventory inv = Bukkit.createInventory(null, 45, "§6Apostar Itens");
        inv.setItem(40, buildItem(Material.LIME_STAINED_GLASS_PANE, "§aConfirmar Aposta",
                Arrays.asList("§7Coloque seus itens nas", "§7slots acima e confirme.", "", "§aClique para confirmar")));
        inv.setItem(41, buildItem(Material.RED_STAINED_GLASS_PANE, "§cCancelar",
                List.of("§7Cancelar e sair da partida.")));
        player.openInventory(inv);
    }

    public static ItemStack buildItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            List<String> l = new ArrayList<>(lore);
            meta.setLore(l);
            item.setItemMeta(meta);
        }
        return item;
    }
}
