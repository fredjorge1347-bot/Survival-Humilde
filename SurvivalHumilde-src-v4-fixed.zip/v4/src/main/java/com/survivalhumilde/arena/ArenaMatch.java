package com.survivalhumilde.arena;

import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ArenaMatch {

    public enum Mode { DUEL_1v1, DUEL_2v2 }
    public enum State { WAITING, IN_PROGRESS, FINISHED }

    private final String id;
    private final Mode mode;
    private final boolean betting;
    private State state = State.WAITING;

    // Time A e Time B
    private final List<UUID> teamA = new ArrayList<>();
    private final List<UUID> teamB = new ArrayList<>();

    // Apostas: player -> itens apostados
    private final Map<UUID, List<ItemStack>> betItems = new HashMap<>();

    // Posições salvas antes de entrar na arena
    private final Map<UUID, org.bukkit.Location> savedLocations = new HashMap<>();

    // Inventários salvos
    private final Map<UUID, ItemStack[]> savedInventories = new HashMap<>();
    private final Map<UUID, ItemStack[]> savedArmor = new HashMap<>();

    public ArenaMatch(String id, Mode mode, boolean betting, UUID creator) {
        this.id = id;
        this.mode = mode;
        this.betting = betting;
        teamA.add(creator);
    }

    public String getId() { return id; }
    public Mode getMode() { return mode; }
    public boolean isBetting() { return betting; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }

    public List<UUID> getTeamA() { return teamA; }
    public List<UUID> getTeamB() { return teamB; }

    public int getMaxPerTeam() { return mode == Mode.DUEL_1v1 ? 1 : 2; }

    public boolean teamAFull() { return teamA.size() >= getMaxPerTeam(); }
    public boolean teamBFull() { return teamB.size() >= getMaxPerTeam(); }
    public boolean isFull() { return teamAFull() && teamBFull(); }

    public boolean isParticipant(UUID uuid) {
        return teamA.contains(uuid) || teamB.contains(uuid);
    }

    public boolean isTeamA(UUID uuid) { return teamA.contains(uuid); }

    public void addBet(UUID player, List<ItemStack> items) { betItems.put(player, new ArrayList<>(items)); }
    public Map<UUID, List<ItemStack>> getBetItems() { return betItems; }

    public void saveLocation(UUID player, org.bukkit.Location loc) { savedLocations.put(player, loc); }
    public org.bukkit.Location getSavedLocation(UUID player) { return savedLocations.get(player); }

    public void saveInventory(UUID player, ItemStack[] inv, ItemStack[] armor) {
        savedInventories.put(player, inv.clone());
        savedArmor.put(player, armor.clone());
    }
    public ItemStack[] getSavedInventory(UUID player) { return savedInventories.get(player); }
    public ItemStack[] getSavedArmor(UUID player) { return savedArmor.get(player); }

    public List<UUID> getAllPlayers() {
        List<UUID> all = new ArrayList<>(teamA);
        all.addAll(teamB);
        return all;
    }

    public List<UUID> getOpposingTeam(UUID player) {
        if (teamA.contains(player)) return teamB;
        return teamA;
    }
}
