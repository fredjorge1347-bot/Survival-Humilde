package com.survivalhumilde.arena;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ArenaListener implements Listener {

    private final Main plugin;
    private final ArenaManager arenaManager;
    private final ArenaGUI gui;

    // Partidas aguardando aposta
    private final Map<UUID, String> awaitingBet = new HashMap<>();
    // Itens que o player colocou no menu de aposta
    private final Map<UUID, Inventory> betInventories = new HashMap<>();

    public ArenaListener(Main plugin) {
        this.plugin = plugin;
        this.arenaManager = plugin.getArenaManager();
        this.gui = new ArenaGUI(plugin);
    }

    // ---------- MORTE NA ARENA ----------
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        if (!arenaManager.isInMatch(dead.getUniqueId())) return;

        ArenaMatch match = arenaManager.getMatchOfPlayer(dead.getUniqueId());
        if (match == null || match.getState() != ArenaMatch.State.IN_PROGRESS) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        // Identifica times
        List<UUID> losers = match.isTeamA(dead.getUniqueId()) ? match.getTeamA() : match.getTeamB();
        List<UUID> winners = match.isTeamA(dead.getUniqueId()) ? match.getTeamB() : match.getTeamA();

        // Verifica se todo o time perdeu (1v1 -> direto; 2v2 -> checar se ambos morreram)
        boolean allLost = losers.stream().allMatch(uuid -> {
            if (uuid.equals(dead.getUniqueId())) return true;
            Player p = Bukkit.getPlayer(uuid);
            return p == null || p.isDead() || p.getHealth() <= 0;
        });

        if (allLost) {
            // Precisa rodar depois do evento de morte
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                // Respawna o player morto antes de teleportar
                dead.spigot().respawn();
                arenaManager.endMatch(match, winners, losers);
            }, 5L);
        } else {
            dead.sendMessage(ChatColor.RED + "Você morreu! Aguardando o resultado da equipe...");
        }
    }

    // ---------- QUIT DURANTE BATALHA ----------
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!arenaManager.isInMatch(player.getUniqueId())) return;
        ArenaMatch match = arenaManager.getMatchOfPlayer(player.getUniqueId());
        if (match != null && match.getState() == ArenaMatch.State.IN_PROGRESS) {
            arenaManager.forfeitMatch(player.getUniqueId());
        } else if (match != null) {
            // Ainda aguardando — remove da partida
            removeFromWaiting(player.getUniqueId(), match);
        }
    }

    private void removeFromWaiting(UUID uuid, ArenaMatch match) {
        match.getTeamA().remove(uuid);
        match.getTeamB().remove(uuid);
    }

    // ---------- CLIQUES NO GUI ----------
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();

        // --- Menu principal da arena ---
        if (title.equals("§c⚔ Arena PvP")) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;
            switch (event.getSlot()) {
                case 10 -> handleCreateMatch(player, ArenaMatch.Mode.DUEL_1v1, false);
                case 11 -> handleCreateMatch(player, ArenaMatch.Mode.DUEL_1v1, true);
                case 13 -> handleCreateMatch(player, ArenaMatch.Mode.DUEL_2v2, false);
                case 14 -> handleCreateMatch(player, ArenaMatch.Mode.DUEL_2v2, true);
                case 16 -> { player.closeInventory(); gui.openOpenMatches(player); }
            }
            return;
        }

        // --- Lista de partidas abertas ---
        if (title.equals("§b📋 Partidas Abertas")) {
            event.setCancelled(true);
            ItemStack item = event.getCurrentItem();
            if (item == null || !item.hasItemMeta() || item.getItemMeta().getLore() == null) return;
            List<String> lore = item.getItemMeta().getLore();
            String matchId = null;
            for (String line : lore) {
                if (line.startsWith("§8ID: ")) {
                    matchId = line.substring("§8ID: ".length());
                    break;
                }
            }
            if (matchId == null) return;
            handleJoinMatch(player, matchId);
            return;
        }

        // --- Menu de aposta ---
        if (title.equals("§6Apostar Itens")) {
            if (event.getSlot() == 40) {
                // Confirmar aposta
                event.setCancelled(true);
                confirmBet(player, event.getView().getTopInventory());
            } else if (event.getSlot() == 41) {
                // Cancelar
                event.setCancelled(true);
                cancelBet(player, event.getView().getTopInventory());
            }
            // Slots 0-39: livre para colocar itens
        }
    }

    private void handleCreateMatch(Player player, ArenaMatch.Mode mode, boolean betting) {
        if (!arenaManager.hasArenaSetup()) {
            player.sendMessage(ChatColor.RED + "A arena ainda não foi configurada! Contate um admin.");
            return;
        }
        if (arenaManager.isInMatch(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Você já está em uma partida!");
            return;
        }
        player.closeInventory();
        ArenaMatch match = arenaManager.createMatch(player.getUniqueId(), mode, betting);
        player.sendMessage(ChatColor.GREEN + "Partida criada! ID: §e" + match.getId());
        player.sendMessage(ChatColor.GRAY + "Aguardando oponente entrar...");

        if (betting) {
            awaitingBet.put(player.getUniqueId(), match.getId());
            gui.openBetMenu(player, match);
            player.sendMessage(ChatColor.YELLOW + "Coloque os itens que deseja apostar no menu e confirme.");
        }
    }

    private void handleJoinMatch(Player player, String matchId) {
        if (!arenaManager.hasArenaSetup()) { player.sendMessage(ChatColor.RED + "Arena não configurada."); return; }
        if (arenaManager.isInMatch(player.getUniqueId())) { player.sendMessage(ChatColor.RED + "Você já está em uma partida!"); return; }

        boolean joined = arenaManager.joinMatch(player.getUniqueId(), matchId);
        if (!joined) { player.sendMessage(ChatColor.RED + "Não foi possível entrar nessa partida."); return; }

        player.closeInventory();
        ArenaMatch match = arenaManager.getMatch(matchId);
        player.sendMessage(ChatColor.GREEN + "Você entrou na partida §e" + matchId);

        if (match.isBetting()) {
            awaitingBet.put(player.getUniqueId(), matchId);
            gui.openBetMenu(player, match);
        } else if (match.isFull()) {
            arenaManager.startMatch(match);
        }
    }

    private void confirmBet(Player player, org.bukkit.inventory.Inventory betInv) {
        String matchId = awaitingBet.get(player.getUniqueId());
        if (matchId == null) return;

        List<ItemStack> items = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack item = betInv.getItem(i);
            if (item != null) {
                items.add(item.clone());
                // Remove do inventário do player
                player.getInventory().remove(item);
            }
        }

        ArenaMatch match = arenaManager.getMatch(matchId);
        if (match == null) { player.sendMessage(ChatColor.RED + "Partida não encontrada."); return; }

        match.addBet(player.getUniqueId(), items);
        awaitingBet.remove(player.getUniqueId());
        player.closeInventory();
        player.sendMessage(ChatColor.GREEN + "Aposta registrada com " + items.size() + " item(s)!");

        if (match.isFull() && match.getBetItems().size() >= 2) {
            arenaManager.startMatch(match);
        }
    }

    private void cancelBet(Player player, org.bukkit.inventory.Inventory betInv) {
        // Retorna itens que estavam no menu
        for (int i = 0; i < 36; i++) {
            ItemStack item = betInv.getItem(i);
            if (item != null) player.getInventory().addItem(item);
        }
        awaitingBet.remove(player.getUniqueId());
        // Remove da partida
        ArenaMatch match = arenaManager.getMatchOfPlayer(player.getUniqueId());
        if (match != null) {
            match.getTeamA().remove(player.getUniqueId());
            match.getTeamB().remove(player.getUniqueId());
        }
        player.closeInventory();
        player.sendMessage(ChatColor.YELLOW + "Você cancelou a entrada na arena.");
    }
}
