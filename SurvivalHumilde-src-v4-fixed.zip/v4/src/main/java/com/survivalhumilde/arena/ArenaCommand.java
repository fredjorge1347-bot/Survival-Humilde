package com.survivalhumilde.arena;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ArenaCommand implements CommandExecutor {

    private final Main plugin;
    private final ArenaManager manager;
    private final ArenaGUI gui;

    public ArenaCommand(Main plugin) {
        this.plugin = plugin;
        this.manager = plugin.getArenaManager();
        this.gui = new ArenaGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }

        if (label.equalsIgnoreCase("construirarena")) {
            if (!player.hasPermission("survivalhumilde.admin")) {
                player.sendMessage(ChatColor.RED + "Sem permissão.");
                return true;
            }
            ArenaBuilder builder = new ArenaBuilder(plugin);
            Location[] spawns = builder.build(player);
            // Salva os spawns automaticamente
            manager.setArenaSpawn("a", spawns[0]);
            manager.setArenaSpawn("b", spawns[1]);
            player.sendMessage(ChatColor.GREEN + "Spawns A e B definidos automaticamente!");
            return true;
        }

        if (label.equalsIgnoreCase("setarena")) {
            if (!player.hasPermission("survivalhumilde.admin")) {
                player.sendMessage(ChatColor.RED + "Sem permissão.");
                return true;
            }
            if (args.length < 1 || (!args[0].equalsIgnoreCase("a") && !args[0].equalsIgnoreCase("b"))) {
                player.sendMessage(ChatColor.RED + "Uso: /setarena <a|b>");
                return true;
            }
            manager.setArenaSpawn(args[0].toLowerCase(), player.getLocation());
            player.sendMessage(ChatColor.GREEN + "Spawn da arena §e" + args[0].toUpperCase() + " §adefinido!");
            return true;
        }

        // /arena
        if (args.length > 0 && args[0].equalsIgnoreCase("sair")) {
            if (manager.isInMatch(player.getUniqueId())) {
                ArenaMatch match = manager.getMatchOfPlayer(player.getUniqueId());
                if (match != null && match.getState() == ArenaMatch.State.IN_PROGRESS) {
                    manager.forfeitMatch(player.getUniqueId());
                    player.sendMessage(ChatColor.YELLOW + "Você desistiu da batalha.");
                } else {
                    player.sendMessage(ChatColor.RED + "Você não está em batalha ativa.");
                }
            } else {
                player.sendMessage(ChatColor.RED + "Você não está em uma partida.");
            }
            return true;
        }

        if (manager.isInMatch(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Você já está em uma partida! Use /arena sair para desistir.");
            return true;
        }

        gui.openMainMenu(player);
        return true;
    }
}
