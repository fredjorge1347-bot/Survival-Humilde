package com.survivalhumilde.arena;

import com.survivalhumilde.Main;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

/**
 * Constrói uma arena PvP 40x40 com:
 * - Chão de quartzo liso
 * - Paredes de 4 blocos de altura em pedra polida
 * - Quinas em pedra polida
 * - Linha central de lã vermelha/azul separando os times
 * - Dois spawns marcados com blocos coloridos
 * - Tochas nas paredes para iluminação
 * - Arquibancada opcional nas bordas
 *
 * Uso: /construirarena — constrói centrada no jogador
 */
public class ArenaBuilder {

    // Dimensões
    private static final int RAIO       = 20;   // 40x40 total
    private static final int ALTURA_PAREDE = 5;
    private static final int DISTANCIA_SPAWN = 8; // blocos do centro até cada spawn

    // Materiais
    private static final Material MAT_CHAO        = Material.QUARTZ_BLOCK;
    private static final Material MAT_CHAO_ALT    = Material.SMOOTH_QUARTZ;   // xadrez leve
    private static final Material MAT_PAREDE      = Material.POLISHED_ANDESITE;
    private static final Material MAT_QUINA       = Material.POLISHED_DIORITE;
    private static final Material MAT_BORDA       = Material.STONE_BRICK_SLAB;
    private static final Material MAT_SPAWN_A     = Material.BLUE_WOOL;
    private static final Material MAT_SPAWN_B     = Material.RED_WOOL;
    private static final Material MAT_LINHA       = Material.WHITE_CONCRETE;
    private static final Material MAT_ARQ         = Material.POLISHED_ANDESITE_SLAB;
    private static final Material MAT_ESCADA      = Material.POLISHED_ANDESITE_STAIRS;
    private static final Material MAT_LUZ         = Material.SEA_LANTERN;
    private static final Material MAT_VIDRO       = Material.WHITE_STAINED_GLASS;
    private static final Material AR              = Material.AIR;

    private final Main plugin;

    public ArenaBuilder(Main plugin) {
        this.plugin = plugin;
    }

    /**
     * Constrói a arena centrada na localização do jogador.
     * Retorna os dois pontos de spawn (A e B) para o ArenaManager salvar.
     */
    public Location[] build(Player player) {
        World world = player.getWorld();
        int cx = player.getLocation().getBlockX();
        int cy = player.getLocation().getBlockY();
        int cz = player.getLocation().getBlockZ();

        player.sendMessage("§e⚒ Construindo arena... aguarde.");

        // ---- CHÃO ----
        for (int x = -RAIO; x <= RAIO; x++) {
            for (int z = -RAIO; z <= RAIO; z++) {
                // Padrão xadrez leve
                Material mat = ((Math.abs(x) + Math.abs(z)) % 2 == 0) ? MAT_CHAO : MAT_CHAO_ALT;
                setBlock(world, cx + x, cy, cz + z, mat);
                // Limpar espaço interno (3 blocos acima do chão)
                for (int y = 1; y <= ALTURA_PAREDE + 2; y++) {
                    setBlock(world, cx + x, cy + y, cz + z, AR);
                }
            }
        }

        // ---- LINHA CENTRAL (Z=0) ----
        for (int x = -RAIO; x <= RAIO; x++) {
            setBlock(world, cx + x, cy, cz, MAT_LINHA);
        }

        // ---- PAREDES (N, S, L, O) ----
        for (int i = -RAIO; i <= RAIO; i++) {
            for (int y = 1; y <= ALTURA_PAREDE; y++) {
                // Norte (z = -RAIO)
                setBlock(world, cx + i, cy + y, cz - RAIO, MAT_PAREDE);
                // Sul  (z = +RAIO)
                setBlock(world, cx + i, cy + y, cz + RAIO, MAT_PAREDE);
                // Oeste (x = -RAIO)
                setBlock(world, cx - RAIO, cy + y, cz + i, MAT_PAREDE);
                // Leste (x = +RAIO)
                setBlock(world, cx + RAIO, cy + y, cz + i, MAT_PAREDE);
            }
        }

        // ---- QUINAS (pilares mais grossos) ----
        int[] corners = {-RAIO, RAIO};
        for (int cx2 : corners) {
            for (int cz2 : corners) {
                for (int y = 1; y <= ALTURA_PAREDE + 1; y++) {
                    setBlock(world, cx + cx2, cy + y, cz + cz2, MAT_QUINA);
                }
                // Luz no topo das quinas
                setBlock(world, cx + cx2, cy + ALTURA_PAREDE + 2, cz + cz2, MAT_LUZ);
            }
        }

        // ---- ILUMINAÇÃO NAS PAREDES (a cada 8 blocos) ----
        for (int i = -RAIO + 4; i <= RAIO - 4; i += 8) {
            int y = ALTURA_PAREDE; // no topo da parede
            setBlock(world, cx + i, cy + y, cz - RAIO, MAT_LUZ);
            setBlock(world, cx + i, cy + y, cz + RAIO, MAT_LUZ);
            setBlock(world, cx - RAIO, cy + y, cz + i, MAT_LUZ);
            setBlock(world, cx + RAIO, cy + y, cz + i, MAT_LUZ);
        }

        // ---- VIDRO NO TOPO DAS PAREDES ----
        for (int i = -RAIO; i <= RAIO; i++) {
            setBlock(world, cx + i,     cy + ALTURA_PAREDE + 1, cz - RAIO, MAT_VIDRO);
            setBlock(world, cx + i,     cy + ALTURA_PAREDE + 1, cz + RAIO, MAT_VIDRO);
            setBlock(world, cx - RAIO,  cy + ALTURA_PAREDE + 1, cz + i,    MAT_VIDRO);
            setBlock(world, cx + RAIO,  cy + ALTURA_PAREDE + 1, cz + i,    MAT_VIDRO);
        }

        // ---- ARQUIBANCADA (fora da arena, nas 4 faces) ----
        buildStands(world, cx, cy, cz);

        // ---- MARCADORES DE SPAWN ----
        // Spawn A — lado norte (z negativo)
        int spawnAz = cz - DISTANCIA_SPAWN;
        int spawnBz = cz + DISTANCIA_SPAWN;

        // Cruz 3x3 colorida no chão
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                setBlock(world, cx + dx, cy, spawnAz + dz, MAT_SPAWN_A);
                setBlock(world, cx + dx, cy, spawnBz + dz, MAT_SPAWN_B);
            }
        }
        // Centro do spawn é quartzo para o jogador pisar
        setBlock(world, cx, cy, spawnAz, MAT_CHAO);
        setBlock(world, cx, cy, spawnBz, MAT_CHAO);

        // ---- LOCATIONS DE SPAWN ----
        Location spawnA = new Location(world, cx + 0.5, cy + 1, spawnAz + 0.5, 180f, 0f); // olhando para sul
        Location spawnB = new Location(world, cx + 0.5, cy + 1, spawnBz + 0.5, 0f, 0f);   // olhando para norte

        player.sendMessage("§a✔ Arena construída com sucesso!");
        player.sendMessage("§7Tamanho: §f40x40 §7| Spawns definidos automaticamente.");
        player.sendMessage("§7Use §b/arena §7para acessar.");

        return new Location[]{spawnA, spawnB};
    }

    /**
     * Arquibancada simples de 3 degraus em volta da arena.
     */
    private void buildStands(World world, int cx, int cy, int cz) {
        int gap = 1; // distância entre a parede e a arquibancada

        for (int i = -(RAIO + gap + 2); i <= (RAIO + gap + 2); i++) {
            for (int row = 0; row < 3; row++) {
                int offset = RAIO + gap + 1 + row;
                int height = cy + row + 1;

                // Norte
                setBlock(world, cx + i, height, cz - offset, MAT_ARQMAT(row));
                // Sul
                setBlock(world, cx + i, height, cz + offset, MAT_ARQMAT(row));
                // Oeste
                setBlock(world, cx - offset, height, cz + i, MAT_ARQMAT(row));
                // Leste
                setBlock(world, cx + offset, height, cz + i, MAT_ARQMAT(row));
            }
        }
    }

    private Material MAT_ARQMAT(int row) {
        return switch (row) {
            case 0 -> Material.SMOOTH_STONE_SLAB;
            case 1 -> Material.POLISHED_ANDESITE;
            default -> Material.POLISHED_ANDESITE_SLAB;
        };
    }

    private void setBlock(World world, int x, int y, int z, Material mat) {
        Block block = world.getBlockAt(x, y, z);
        block.setType(mat, false);
    }
}
