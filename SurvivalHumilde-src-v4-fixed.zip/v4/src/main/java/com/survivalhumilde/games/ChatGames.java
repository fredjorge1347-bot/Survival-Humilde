package com.survivalhumilde.games;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.Random;

/**
 * Sistema de jogos no chat.
 * A cada N minutos lança um desafio de matemática ou de reação.
 * O primeiro a responder ganha moedas.
 */
public class ChatGames implements Listener {

    private final Main plugin;
    private final Random random = new Random();

    private BukkitTask gameTask;
    private BukkitTask timeoutTask;

    private boolean gameActive = false;
    private String correctAnswer = null;
    private GameType currentType;

    private final double reward;
    private final int intervalMinutes;
    private final int answerTimeout;

    private enum GameType { MATH, REACTION }

    // Palavras para o jogo de reação
    private static final String[] REACTION_WORDS = {
        "MINÉRIO", "DIAMANTE", "CAVERNA", "CREEPER", "SOBREVIVER",
        "CRAFTING", "FLECHA", "ESMERALDA", "NETHER", "BARRAGEM"
    };

    public ChatGames(Main plugin) {
        this.plugin = plugin;
        this.reward = plugin.getConfig().getDouble("chat-games.reward", 50.0);
        this.intervalMinutes = plugin.getConfig().getInt("chat-games.interval-minutes", 10);
        this.answerTimeout = plugin.getConfig().getInt("chat-games.answer-timeout", 30);
    }

    public void start() {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        scheduleNext();
    }

    public void stop() {
        HandlerList.unregisterAll(this);
        if (gameTask != null) gameTask.cancel();
        if (timeoutTask != null) timeoutTask.cancel();
    }

    private void scheduleNext() {
        long delay = intervalMinutes * 60L * 20L;
        // Pequena variação aleatória para parecer mais natural
        delay += random.nextInt(120) * 20L;

        gameTask = Bukkit.getScheduler().runTaskLater(plugin, this::launchGame, delay);
    }

    private void launchGame() {
        if (Bukkit.getOnlinePlayers().isEmpty()) {
            scheduleNext();
            return;
        }

        // Escolher tipo de jogo
        currentType = random.nextBoolean() ? GameType.MATH : GameType.REACTION;
        gameActive = true;

        if (currentType == GameType.MATH) {
            launchMathGame();
        } else {
            launchReactionGame();
        }

        // Timeout para expirar o desafio
        timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (gameActive) {
                gameActive = false;
                correctAnswer = null;
                broadcast(ChatColor.GRAY + "[ChatGame] Ninguem acertou! Resposta: " + ChatColor.YELLOW + getDisplayAnswer());
                scheduleNext();
            }
        }, answerTimeout * 20L);
    }

    private String lastDisplayAnswer = "";

    private String getDisplayAnswer() { return lastDisplayAnswer; }

    private void launchMathGame() {
        int a = random.nextInt(50) + 1;
        int b = random.nextInt(50) + 1;
        int op = random.nextInt(3); // 0=soma, 1=subtracao, 2=multiplicacao

        String question;
        int answer;

        switch (op) {
            case 0 -> { question = a + " + " + b; answer = a + b; }
            case 1 -> {
                // Garante resultado positivo
                if (a < b) { int tmp = a; a = b; b = tmp; }
                question = a + " - " + b;
                answer = a - b;
            }
            default -> {
                // Multiplica por número pequeno para não ser difícil demais
                b = random.nextInt(12) + 1;
                question = a + " x " + b;
                answer = a * b;
            }
        }

        correctAnswer = String.valueOf(answer);
        lastDisplayAnswer = correctAnswer;

        broadcast(ChatColor.GOLD + "======[ ChatGame ]======");
        broadcast(ChatColor.YELLOW + "Matematica! Quanto e: " + ChatColor.WHITE + question + ChatColor.YELLOW + " ?");
        broadcast(ChatColor.GREEN + "Premio: " + plugin.getEconomy().format(reward));
        broadcast(ChatColor.GRAY + "Voce tem " + answerTimeout + "s!");
    }

    private void launchReactionGame() {
        String word = REACTION_WORDS[random.nextInt(REACTION_WORDS.length)];
        correctAnswer = word;
        lastDisplayAnswer = word;

        broadcast(ChatColor.GOLD + "======[ ChatGame ]======");
        broadcast(ChatColor.AQUA + "Reacao! Digite no chat: " + ChatColor.WHITE + word);
        broadcast(ChatColor.GREEN + "Premio: " + plugin.getEconomy().format(reward));
        broadcast(ChatColor.GRAY + "Voce tem " + answerTimeout + "s!");
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        if (!gameActive || correctAnswer == null) return;

        String msg = event.getMessage().trim();

        if (currentType == GameType.MATH) {
            if (!msg.equals(correctAnswer)) return;
        } else {
            if (!msg.equalsIgnoreCase(correctAnswer)) return;
        }

        // Resposta correta!
        gameActive = false;
        correctAnswer = null;
        Player winner = event.getPlayer();

        if (timeoutTask != null) timeoutTask.cancel();

        double rew = reward;
        String formattedReward = plugin.getEconomy().format(rew);

        // Depositar na thread principal
        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.getEconomy().deposit(winner, rew);
            broadcast(ChatColor.GREEN + "[ChatGame] " + ChatColor.YELLOW + winner.getName()
                    + ChatColor.GREEN + " ganhou " + formattedReward + "!");
        });

        scheduleNext();
    }

    private void broadcast(String msg) {
        Bukkit.getScheduler().runTask(plugin, () -> Bukkit.broadcastMessage(msg));
    }
}
