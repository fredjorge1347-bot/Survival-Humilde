package com.survivalhumilde.economy;

import com.survivalhumilde.Main;
import org.bukkit.OfflinePlayer;

/**
 * Sistema de Economia interno do SurvivalHumilde.
 * Envolve o DataManager e expõe métodos limpos para uso interno.
 */
public class SurvivalEconomy {

    private final Main plugin;
    private final String currencyName;
    private final String currencyNamePlural;

    public SurvivalEconomy(Main plugin) {
        this.plugin = plugin;
        this.currencyName = plugin.getConfig().getString("economy.currency-name", "Moeda");
        this.currencyNamePlural = plugin.getConfig().getString("economy.currency-name-plural", "Moedas");
    }

    public String getCurrencyName() { return currencyName; }
    public String getCurrencyNamePlural() { return currencyNamePlural; }

    public boolean hasAccount(OfflinePlayer player) {
        return plugin.getDataManager().hasAccount(player.getUniqueId());
    }

    public double getBalance(OfflinePlayer player) {
        return plugin.getDataManager().getBalance(player.getUniqueId());
    }

    public boolean has(OfflinePlayer player, double amount) {
        return getBalance(player) >= amount;
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        return plugin.getDataManager().withdraw(player.getUniqueId(), amount);
    }

    public void deposit(OfflinePlayer player, double amount) {
        plugin.getDataManager().deposit(player.getUniqueId(), amount);
    }

    public void setBalance(OfflinePlayer player, double amount) {
        plugin.getDataManager().setBalance(player.getUniqueId(), amount);
    }

    /**
     * Formata o valor com nome de moeda adequado.
     */
    public String format(double amount) {
        String name = (amount == 1.0) ? currencyName : currencyNamePlural;
        // Formata sem casas decimais se for número inteiro
        if (amount == Math.floor(amount) && !Double.isInfinite(amount)) {
            return String.format("%.0f %s", amount, name);
        }
        return String.format("%.2f %s", amount, name);
    }
}
