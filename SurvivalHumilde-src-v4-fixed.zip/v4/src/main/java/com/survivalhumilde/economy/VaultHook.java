package com.survivalhumilde.economy;

import com.survivalhumilde.Main;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

import java.util.Collections;
import java.util.List;

public class VaultHook implements Economy {

    private final Main plugin;
    private final SurvivalEconomy eco;
    private boolean registered = false;

    public VaultHook(Main plugin, SurvivalEconomy eco) {
        this.plugin = plugin;
        this.eco = eco;
    }

    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) return false;
        plugin.getServer().getServicesManager().register(Economy.class, this, plugin, ServicePriority.High);
        registered = true;
        return true;
    }

    public void unregister() {
        if (registered) {
            plugin.getServer().getServicesManager().unregister(Economy.class, this);
            registered = false; // CORREÇÃO: resetar flag após desregistro
        }
    }

    @Override public boolean isEnabled() { return true; }
    @Override public String getName() { return "SurvivalHumilde"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) { return eco.format(amount); }
    @Override public String currencyNamePlural() { return eco.getCurrencyNamePlural(); }
    @Override public String currencyNameSingular() { return eco.getCurrencyName(); }

    @Override public boolean hasAccount(OfflinePlayer player) { return true; }
    @Override public boolean hasAccount(OfflinePlayer player, String worldName) { return true; }
    @Override public boolean createPlayerAccount(OfflinePlayer player) { return true; }
    @Override public boolean createPlayerAccount(OfflinePlayer player, String worldName) { return true; }

    @Override public double getBalance(OfflinePlayer player) { return eco.getBalance(player); }
    @Override public double getBalance(OfflinePlayer player, String world) { return eco.getBalance(player); }
    @Override public boolean has(OfflinePlayer player, double amount) { return eco.has(player, amount); }
    @Override public boolean has(OfflinePlayer player, String worldName, double amount) { return eco.has(player, amount); }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        // CORREÇÃO: também rejeitar amount == 0 para evitar operações sem efeito
        if (amount < 0) return fail(player, "Valor negativo.");
        if (amount == 0) return fail(player, "Valor não pode ser zero.");
        if (!eco.has(player, amount)) return fail(player, "Saldo insuficiente.");
        eco.withdraw(player, amount);
        return success(player, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdrawPlayer(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        // CORREÇÃO: também rejeitar amount == 0
        if (amount < 0) return fail(player, "Valor negativo.");
        if (amount == 0) return fail(player, "Valor não pode ser zero.");
        eco.deposit(player, amount);
        return success(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return depositPlayer(player, amount);
    }

    private static final EconomyResponse NO_BANK =
            new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem bancos.");

    @Override public EconomyResponse createBank(String name, OfflinePlayer player) { return NO_BANK; }
    @Override public EconomyResponse deleteBank(String name) { return NO_BANK; }
    @Override public EconomyResponse bankBalance(String name) { return NO_BANK; }
    @Override public EconomyResponse bankHas(String name, double amount) { return NO_BANK; }
    @Override public EconomyResponse bankWithdraw(String name, double amount) { return NO_BANK; }
    @Override public EconomyResponse bankDeposit(String name, double amount) { return NO_BANK; }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) { return NO_BANK; }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) { return NO_BANK; }
    @Override public List<String> getBanks() { return Collections.emptyList(); }

    // Overloads deprecated exigidos pela interface Vault 1.7
    // CORREÇÃO: resolver OfflinePlayer pelo nome para compatibilidade real com plugins legados
    @Override @Deprecated public boolean hasAccount(String playerName) { return true; }
    @Override @Deprecated public boolean hasAccount(String playerName, String worldName) { return true; }
    @Override @Deprecated public boolean createPlayerAccount(String playerName) { return true; }
    @Override @Deprecated public boolean createPlayerAccount(String playerName, String worldName) { return true; }

    @Override @Deprecated
    public double getBalance(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return eco.getBalance(player);
    }

    @Override @Deprecated
    public double getBalance(String playerName, String worldName) {
        return getBalance(playerName);
    }

    @Override @Deprecated
    public boolean has(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return eco.has(player, amount);
    }

    @Override @Deprecated
    public boolean has(String playerName, String worldName, double amount) {
        return has(playerName, amount);
    }

    @Override @Deprecated
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return withdrawPlayer(player, amount);
    }

    @Override @Deprecated
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return withdrawPlayer(playerName, amount);
    }

    @Override @Deprecated
    public EconomyResponse depositPlayer(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return depositPlayer(player, amount);
    }

    @Override @Deprecated
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return depositPlayer(playerName, amount);
    }

    @Override @Deprecated
    public EconomyResponse isBankOwner(String name, String playerName) { return NO_BANK; }

    @Override @Deprecated
    public EconomyResponse isBankMember(String name, String playerName) { return NO_BANK; }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private EconomyResponse success(OfflinePlayer player, double amount) {
        return new EconomyResponse(amount, eco.getBalance(player), EconomyResponse.ResponseType.SUCCESS, "");
    }

    private EconomyResponse fail(OfflinePlayer player, String msg) {
        return new EconomyResponse(0, eco.getBalance(player), EconomyResponse.ResponseType.FAILURE, msg);
    }
}
