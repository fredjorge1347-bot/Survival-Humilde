package com.survivalhumilde.listeners;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerListener implements Listener {

    private final Main plugin;

    public PlayerListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Garante que a conta existe (cria saldo inicial se necessário)
        double balance = plugin.getDataManager().getBalance(event.getPlayer().getUniqueId());

        // Mensagem de boas-vindas com saldo
        event.getPlayer().sendMessage(ChatColor.YELLOW + "Bem-vindo(a)! Saldo: "
                + ChatColor.GREEN + plugin.getEconomy().format(balance));
    }
}
