package com.survivalhumilde.listeners;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;

import java.util.Set;

/**
 * Auto-Lock: baús e barris são automaticamente travados ao serem colocados.
 * Apenas o dono pode abrir. Admins com permissão podem ignorar o lock.
 */
public class AutoLockListener implements Listener {

    private final Main plugin;

    // Blocos que serão travados automaticamente
    private static final Set<Material> LOCKABLE = Set.of(
            Material.CHEST,
            Material.TRAPPED_CHEST,
            Material.BARREL,
            Material.FURNACE,
            Material.BLAST_FURNACE,
            Material.SMOKER,
            Material.HOPPER,
            Material.DROPPER,
            Material.DISPENSER,
            Material.SHULKER_BOX,
            Material.WHITE_SHULKER_BOX, Material.ORANGE_SHULKER_BOX,
            Material.MAGENTA_SHULKER_BOX, Material.LIGHT_BLUE_SHULKER_BOX,
            Material.YELLOW_SHULKER_BOX, Material.LIME_SHULKER_BOX,
            Material.PINK_SHULKER_BOX, Material.GRAY_SHULKER_BOX,
            Material.LIGHT_GRAY_SHULKER_BOX, Material.CYAN_SHULKER_BOX,
            Material.PURPLE_SHULKER_BOX, Material.BLUE_SHULKER_BOX,
            Material.BROWN_SHULKER_BOX, Material.GREEN_SHULKER_BOX,
            Material.RED_SHULKER_BOX, Material.BLACK_SHULKER_BOX
    );

    public AutoLockListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Block block = event.getBlockPlaced();
        if (!LOCKABLE.contains(block.getType())) return;

        Player player = event.getPlayer();
        String blockKey = getBlockKey(block);

        FileConfiguration cfg = plugin.getDataManager().getLocksCfg();
        // Só registra se ainda não está travado
        if (!cfg.contains(blockKey)) {
            cfg.set(blockKey + ".owner", player.getUniqueId().toString());
            plugin.getDataManager().saveLocks();
            player.sendMessage(ChatColor.GREEN + "[Lock] Bloco travado automaticamente!");
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onBlockInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || !LOCKABLE.contains(block.getType())) return;

        String blockKey = getBlockKey(block);
        FileConfiguration cfg = plugin.getDataManager().getLocksCfg();

        if (!cfg.contains(blockKey)) return; // Não está travado

        String ownerStr = cfg.getString(blockKey + ".owner");
        if (ownerStr == null) return;

        Player player = event.getPlayer();

        // Admin pode bypassar
        if (player.hasPermission("survivalhumilde.admin")) return;

        if (!player.getUniqueId().toString().equals(ownerStr)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "[Lock] Este bloco pertence a outro jogador!");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!LOCKABLE.contains(block.getType())) return;

        String blockKey = getBlockKey(block);
        FileConfiguration cfg = plugin.getDataManager().getLocksCfg();

        if (!cfg.contains(blockKey)) return;

        String ownerStr = cfg.getString(blockKey + ".owner");
        Player player = event.getPlayer();

        // Admin pode quebrar qualquer bloco
        if (player.hasPermission("survivalhumilde.admin")) {
            cfg.set(blockKey, null);
            plugin.getDataManager().saveLocks();
            return;
        }

        if (ownerStr != null && !player.getUniqueId().toString().equals(ownerStr)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "[Lock] Voce nao pode quebrar o bloco de outro jogador!");
        } else {
            // Dono quebrou: remove o lock
            cfg.set(blockKey, null);
            plugin.getDataManager().saveLocks();
        }
    }

    /**
     * Chave única para o bloco baseada no mundo e coordenadas.
     */
    private String getBlockKey(Block block) {
        return block.getWorld().getName() + "_" + block.getX() + "_" + block.getY() + "_" + block.getZ();
    }
}
