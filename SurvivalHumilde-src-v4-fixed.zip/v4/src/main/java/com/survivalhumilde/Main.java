package com.survivalhumilde;

import com.survivalhumilde.arena.ArenaCommand;
import com.survivalhumilde.arena.ArenaListener;
import com.survivalhumilde.arena.ArenaManager;
import com.survivalhumilde.clans.ClanCommand;
import com.survivalhumilde.clans.ClanListener;
import com.survivalhumilde.clans.ClanManager;
import com.survivalhumilde.commands.*;
import com.survivalhumilde.economy.SurvivalEconomy;
import com.survivalhumilde.economy.VaultHook;
import com.survivalhumilde.games.ChatGames;
import com.survivalhumilde.listeners.AutoLockListener;
import com.survivalhumilde.listeners.PlayerListener;
import com.survivalhumilde.managers.DataManager;
import com.survivalhumilde.managers.HomeManager;
import com.survivalhumilde.managers.TpaManager;
import com.survivalhumilde.missions.MissionListener;
import com.survivalhumilde.missions.MissionManager;
import com.survivalhumilde.missions.NPCCommand;
import com.survivalhumilde.missions.NPCManager;
import com.survivalhumilde.shop.ShopGUI;
import com.survivalhumilde.shop.ShopListener;
import com.survivalhumilde.shop.ShopManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    private static Main instance;
    private SurvivalEconomy economy;
    private DataManager dataManager;
    private HomeManager homeManager;
    private TpaManager tpaManager;
    private ChatGames chatGames;
    private VaultHook vaultHook;
    private ShopManager shopManager;
    private ShopGUI shopGUI;
    private ClanManager clanManager;
    private MissionManager missionManager;
    private NPCManager npcManager;
    private ArenaManager arenaManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        dataManager  = new DataManager(this);
        homeManager  = new HomeManager(this);
        tpaManager   = new TpaManager(this);
        economy      = new SurvivalEconomy(this);
        shopManager  = new ShopManager();
        shopGUI      = new ShopGUI(this);
        vaultHook = new VaultHook(this, economy);
        if (!vaultHook.setup()) getLogger().warning("Vault nao encontrado!");
        else getLogger().info("Vault registrado com sucesso!");
        clanManager    = new ClanManager(this);
        missionManager = new MissionManager(this);
        npcManager     = new NPCManager(this);
        arenaManager   = new ArenaManager(this);
        getServer().getScheduler().runTaskLater(this, () -> npcManager.load(), 5L);
        getServer().getPluginManager().registerEvents(new AutoLockListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new ShopListener(this), this);
        getServer().getPluginManager().registerEvents(new ClanListener(this), this);
        getServer().getPluginManager().registerEvents(new MissionListener(this), this);
        getServer().getPluginManager().registerEvents(new ArenaListener(this), this);
        getCommand("money").setExecutor(new MoneyCommand(this));
        getCommand("pay").setExecutor(new PayCommand(this));
        getCommand("spawn").setExecutor(new SpawnCommand(this));
        getCommand("sethome").setExecutor(new SetHomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("tpa").setExecutor(new TpaCommand(this));
        getCommand("tpaccept").setExecutor(new TpAcceptCommand(this));
        getCommand("tpdeny").setExecutor(new TpDenyCommand(this));
        getCommand("rtp").setExecutor(new RtpCommand(this));
        getCommand("servico").setExecutor(new ServicoCommand(this));
        getCommand("setspawn").setExecutor(new SetSpawnCommand(this));
        getCommand("loja").setExecutor(new ShopCommand(this));
        getCommand("cla").setExecutor(new ClanCommand(this));
        getCommand("npcmission").setExecutor(new NPCCommand(this));
        ArenaCommand arenaCmd = new ArenaCommand(this);
        getCommand("arena").setExecutor(arenaCmd);
        getCommand("setarena").setExecutor(arenaCmd);
        getCommand("construirarena").setExecutor(arenaCmd);
        chatGames = new ChatGames(this);
        chatGames.start();
        getLogger().info("SurvivalHumilde v4 ativado! Clans + Missoes + Arena prontos.");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.saveAll();
        if (chatGames != null) chatGames.stop();
        if (vaultHook != null) vaultHook.unregister();
        if (clanManager != null) clanManager.save();
        if (missionManager != null) missionManager.save();
        if (npcManager != null) npcManager.despawnAll();
        getLogger().info("SurvivalHumilde desativado.");
    }

    public static Main getInstance() { return instance; }
    public SurvivalEconomy getEconomy() { return economy; }
    public DataManager getDataManager() { return dataManager; }
    public HomeManager getHomeManager() { return homeManager; }
    public TpaManager getTpaManager() { return tpaManager; }
    public ShopManager getShopManager() { return shopManager; }
    public ShopGUI getShopGUI() { return shopGUI; }
    public ClanManager getClanManager() { return clanManager; }
    public MissionManager getMissionManager() { return missionManager; }
    public NPCManager getNpcManager() { return npcManager; }
    public ArenaManager getArenaManager() { return arenaManager; }
}
