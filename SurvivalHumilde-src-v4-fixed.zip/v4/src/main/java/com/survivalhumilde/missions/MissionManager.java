package com.survivalhumilde.missions;

import com.survivalhumilde.Main;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MissionManager {

    private final Main plugin;
    private final List<Mission> missions = new ArrayList<>();
    private final Map<UUID, Map<String, Long>> completedAt = new HashMap<>();   // player -> missionId -> timestamp
    private final Map<UUID, Map<String, Integer>> progress = new HashMap<>();   // player -> missionId -> count
    private File dataFile;
    private FileConfiguration dataConfig;

    public MissionManager(Main plugin) {
        this.plugin = plugin;
        registerDefaultMissions();
        load();
    }

    private void registerDefaultMissions() {
        // ---- Minerador ----
        missions.add(new Mission("mine_coal", "Carvão Básico",
                "Colete 16 carvões e entregue ao Minerador.",
                Mission.Type.COLLECT, "COAL", 16, 80, 60));
        missions.add(new Mission("mine_iron", "Ferreiro Iniciante",
                "Colete 8 minérios de ferro.",
                Mission.Type.COLLECT, "RAW_IRON", 8, 150, 90));
        missions.add(new Mission("mine_gold", "Ouro Para o Rei",
                "Colete 4 minérios de ouro.",
                Mission.Type.COLLECT, "RAW_GOLD", 4, 200, 120));
        missions.add(new Mission("mine_diamond", "Caçador de Diamantes",
                "Colete 3 diamantes.",
                Mission.Type.COLLECT, "DIAMOND", 3, 500, 180));
        missions.add(new Mission("mine_emerald", "Tesouro Esmeralda",
                "Colete 2 esmeraldas.",
                Mission.Type.COLLECT, "EMERALD", 2, 400, 180));

        // ---- Lenhador ----
        missions.add(new Mission("wood_oak", "Madeira de Carvalho",
                "Colete 32 toras de carvalho.",
                Mission.Type.COLLECT, "OAK_LOG", 32, 100, 60));
        missions.add(new Mission("wood_birch", "Madeira de Bétula",
                "Colete 32 toras de bétula.",
                Mission.Type.COLLECT, "BIRCH_LOG", 32, 100, 60));
        missions.add(new Mission("wood_dark", "Madeira Escura",
                "Colete 16 toras de carvalho escuro.",
                Mission.Type.COLLECT, "DARK_OAK_LOG", 16, 200, 90));

        // ---- Pescador ----
        missions.add(new Mission("fish_basic", "Pescaria do Dia",
                "Pesque 5 peixes (qualquer tipo).",
                Mission.Type.COLLECT, "COD", 5, 120, 60));
        missions.add(new Mission("fish_salmon", "Salmão Fresco",
                "Traga 3 salmões ao Pescador.",
                Mission.Type.COLLECT, "SALMON", 3, 150, 90));

        // ---- Caçador ----
        missions.add(new Mission("hunt_zombie", "Exterminador de Zumbis",
                "Mate 10 zumbis para o Caçador.",
                Mission.Type.KILL_MOB, "ZOMBIE", 10, 200, 60));
        missions.add(new Mission("hunt_skeleton", "Ossos Partido",
                "Mate 10 esqueletos.",
                Mission.Type.KILL_MOB, "SKELETON", 10, 200, 60));
        missions.add(new Mission("hunt_spider", "Veneno de Aranha",
                "Mate 8 aranhas.",
                Mission.Type.KILL_MOB, "SPIDER", 8, 180, 60));
        missions.add(new Mission("hunt_creeper", "Abafador de Creepers",
                "Mate 5 creepers.",
                Mission.Type.KILL_MOB, "CREEPER", 5, 300, 120));
        missions.add(new Mission("hunt_enderman", "Ladrão de Olhos",
                "Mate 3 endermans.",
                Mission.Type.KILL_MOB, "ENDERMAN", 3, 500, 180));

        // ---- Fazendeiro ----
        missions.add(new Mission("farm_wheat", "Colheita do Trigo",
                "Colete 32 unidades de trigo.",
                Mission.Type.COLLECT, "WHEAT", 32, 90, 60));
        missions.add(new Mission("farm_carrot", "Cenouras Para Todos",
                "Colete 32 cenouras.",
                Mission.Type.COLLECT, "CARROT", 32, 90, 60));
        missions.add(new Mission("farm_potato", "Batatas Assadas",
                "Colete 32 batatas.",
                Mission.Type.COLLECT, "POTATO", 32, 90, 60));
        missions.add(new Mission("farm_sugar", "Mel e Cana",
                "Colete 16 canas-de-açúcar.",
                Mission.Type.COLLECT, "SUGAR_CANE", 16, 80, 60));
    }

    public List<Mission> getAllMissions() { return Collections.unmodifiableList(missions); }

    public Mission getMission(String id) {
        return missions.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }

    public List<Mission> getMissionsForNpc(String npcType) {
        List<Mission> list = new ArrayList<>();
        for (Mission m : missions) {
            if (m.getId().startsWith(npcType)) list.add(m);
        }
        return list;
    }

    // Progresso para missões de MOB
    public int getProgress(UUID player, String missionId) {
        return progress.getOrDefault(player, Collections.emptyMap()).getOrDefault(missionId, 0);
    }

    public void addProgress(UUID player, String missionId, int amount) {
        progress.computeIfAbsent(player, k -> new HashMap<>())
                .merge(missionId, amount, Integer::sum);
    }

    public boolean canComplete(UUID player, Mission mission) {
        return getProgress(player, mission.getId()) >= mission.getAmount();
    }

    public boolean isOnCooldown(UUID player, String missionId) {
        Mission m = getMission(missionId);
        if (m == null) return false;
        long last = completedAt.getOrDefault(player, Collections.emptyMap()).getOrDefault(missionId, 0L);
        long now = System.currentTimeMillis();
        return (now - last) < m.getCooldownMinutes() * 60_000L;
    }

    public long getRemainingCooldownMinutes(UUID player, String missionId) {
        Mission m = getMission(missionId);
        if (m == null) return 0;
        long last = completedAt.getOrDefault(player, Collections.emptyMap()).getOrDefault(missionId, 0L);
        long elapsed = System.currentTimeMillis() - last;
        long remaining = m.getCooldownMinutes() * 60_000L - elapsed;
        return Math.max(0, remaining / 60_000L);
    }

    public void completeMission(UUID player, String missionId) {
        completedAt.computeIfAbsent(player, k -> new HashMap<>())
                .put(missionId, System.currentTimeMillis());
        // Reset progresso de MOB
        progress.getOrDefault(player, new HashMap<>()).remove(missionId);
        save();
    }

    // ---- PERSISTÊNCIA ----

    @SuppressWarnings("unchecked")
    private void load() {
        dataFile = new File(plugin.getDataFolder(), "missions.yml");
        if (!dataFile.exists()) try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection section = dataConfig.getConfigurationSection("players");
        if (section == null) return;
        for (String uuidStr : section.getKeys(false)) {
            UUID uuid;
            try { uuid = UUID.fromString(uuidStr); } catch (Exception e) { continue; }
            ConfigurationSection playerSection = section.getConfigurationSection(uuidStr);
            if (playerSection == null) continue;

            // completed
            ConfigurationSection completed = playerSection.getConfigurationSection("completed");
            if (completed != null) {
                Map<String, Long> map = new HashMap<>();
                for (String mId : completed.getKeys(false)) {
                    map.put(mId, completed.getLong(mId));
                }
                completedAt.put(uuid, map);
            }
            // progress
            ConfigurationSection prog = playerSection.getConfigurationSection("progress");
            if (prog != null) {
                Map<String, Integer> map = new HashMap<>();
                for (String mId : prog.getKeys(false)) {
                    map.put(mId, prog.getInt(mId));
                }
                progress.put(uuid, map);
            }
        }
    }

    public void save() {
        dataConfig.set("players", null);
        for (UUID uuid : completedAt.keySet()) {
            String path = "players." + uuid.toString() + ".completed";
            Map<String, Long> map = completedAt.get(uuid);
            for (Map.Entry<String, Long> e : map.entrySet()) {
                dataConfig.set(path + "." + e.getKey(), e.getValue());
            }
        }
        for (UUID uuid : progress.keySet()) {
            String path = "players." + uuid.toString() + ".progress";
            Map<String, Integer> map = progress.get(uuid);
            for (Map.Entry<String, Integer> e : map.entrySet()) {
                dataConfig.set(path + "." + e.getKey(), e.getValue());
            }
        }
        try { dataConfig.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }
}
