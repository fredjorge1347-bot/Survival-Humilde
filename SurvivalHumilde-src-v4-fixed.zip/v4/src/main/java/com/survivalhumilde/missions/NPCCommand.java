package com.survivalhumilde.missions;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NPCCommand implements CommandExecutor {

    private final Main plugin;
    private final NPCManager npcManager;

    public NPCCommand(Main plugin) {
        this.plugin = plugin;
        this.npcManager = plugin.getNpcManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
        if (!player.hasPermission("survivalhumilde.admin")) {
            player.sendMessage(ChatColor.RED + "Sem permissão.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player); return true;
        }

        switch (args[0].toLowerCase()) {
            case "criar" -> {
                if (args.length < 3) { player.sendMessage(ChatColor.RED + "Uso: /npcmission criar <id> <TIPO>"); return true; }
                String id = args[1];
                MissionNPC.NpcType type;
                try { type = MissionNPC.NpcType.valueOf(args[2].toUpperCase()); }
                catch (Exception e) {
                    player.sendMessage(ChatColor.RED + "Tipos válidos: MINERADOR, LENHADOR, PESCADOR, CACADOR, FAZENDEIRO");
                    return true;
                }
                if (npcManager.spawnNpc(id, type, player.getLocation())) {
                    player.sendMessage(ChatColor.GREEN + "NPC '" + id + "' criado com sucesso!");
                } else {
                    player.sendMessage(ChatColor.RED + "Já existe um NPC com esse ID.");
                }
            }
            case "remover" -> {
                if (args.length < 2) { player.sendMessage(ChatColor.RED + "Uso: /npcmission remover <id>"); return true; }
                if (npcManager.removeNpc(args[1])) {
                    player.sendMessage(ChatColor.GREEN + "NPC '" + args[1] + "' removido.");
                } else {
                    player.sendMessage(ChatColor.RED + "NPC não encontrado.");
                }
            }
            case "lista" -> {
                player.sendMessage(ChatColor.GOLD + "NPCs ativos:");
                npcManager.getAllNpcs().forEach(npc ->
                        player.sendMessage(ChatColor.GRAY + " - " + npc.getId() + " (" + npc.getType().name() + ")"));
            }
            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "/npcmission criar <id> <TIPO>");
        player.sendMessage(ChatColor.GOLD + "/npcmission remover <id>");
        player.sendMessage(ChatColor.GOLD + "/npcmission lista");
        player.sendMessage(ChatColor.GRAY + "Tipos: MINERADOR, LENHADOR, PESCADOR, CACADOR, FAZENDEIRO");
    }
}
