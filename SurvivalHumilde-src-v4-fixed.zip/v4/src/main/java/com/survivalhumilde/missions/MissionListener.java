package com.survivalhumilde.missions;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class MissionListener implements Listener {

    private final Main plugin;
    private final MissionManager missionManager;
    private final NPCManager npcManager;
    private final MissionGUI gui;

    public MissionListener(Main plugin) {
        this.plugin = plugin;
        this.missionManager = plugin.getMissionManager();
        this.npcManager = plugin.getNpcManager();
        this.gui = new MissionGUI(plugin);
    }

    // Clicar com o botão direito no NPC (ArmorStand)
    @EventHandler
    public void onInteractNpc(PlayerInteractAtEntityEvent event) {
        Entity entity = event.getRightClicked();
        if (!(entity instanceof ArmorStand)) return;
        MissionNPC npc = npcManager.getNpcByEntity(entity.getUniqueId());
        if (npc == null) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        gui.open(player, npc);
    }

    // Impedir dano no NPC
    @EventHandler
    public void onDamageNpc(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof ArmorStand stand)) return;
        if (npcManager.getNpcByEntity(stand.getUniqueId()) != null) {
            event.setCancelled(true);
        }
    }

    // Clique no GUI de missões
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();

        // Verifica se é GUI de missão
        boolean isMissionGui = false;
        for (MissionNPC npc : npcManager.getAllNpcs()) {
            if (title.startsWith(npc.getDisplayName())) {
                isMissionGui = true;
                break;
            }
        }
        if (!isMissionGui) return;
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String name = clicked.getItemMeta().getDisplayName();
        if (name.startsWith(ChatColor.GRAY + "⏳")) return; // em cooldown

        // Encontrar qual missão foi clicada
        // Mapeia pela posição do slot para missão
        // Encontra o NPC do GUI
        MissionNPC targetNpc = null;
        for (MissionNPC npc : npcManager.getAllNpcs()) {
            if (title.startsWith(npc.getDisplayName())) {
                targetNpc = npc;
                break;
            }
        }
        if (targetNpc == null) return;

        List<Mission> missions = missionManager.getMissionsForNpc(targetNpc.getMissionPrefix());
        int slot = event.getSlot();
        if (slot < 0 || slot >= missions.size()) return;
        Mission mission = missions.get(slot);

        if (missionManager.isOnCooldown(player.getUniqueId(), mission.getId())) {
            player.sendMessage(ChatColor.RED + "Essa missão está em cooldown!");
            return;
        }

        if (mission.getType() == Mission.Type.COLLECT) {
            handleCollectMission(player, targetNpc, mission);
        } else {
            handleKillMission(player, mission);
        }
    }

    private void handleCollectMission(Player player, MissionNPC npc, Mission mission) {
        ItemStack required = mission.getRequiredItem();
        if (required == null) {
            player.sendMessage(ChatColor.RED + "Erro na missão. Contate um admin.");
            return;
        }
        int needed = mission.getAmount();
        int found = 0;

        // Conta quantos itens o jogador tem
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == required.getType()) {
                found += item.getAmount();
            }
        }

        if (found < needed) {
            player.sendMessage(ChatColor.RED + "Você precisa de " + needed + "x " + required.getType().name().toLowerCase().replace("_", " ") + "!");
            player.sendMessage(ChatColor.GRAY + "Você tem: " + found + "/" + needed);
            return;
        }

        // Remove os itens do inventário
        int toRemove = needed;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == required.getType()) {
                if (item.getAmount() <= toRemove) {
                    toRemove -= item.getAmount();
                    item.setAmount(0);
                } else {
                    item.setAmount(item.getAmount() - toRemove);
                    toRemove = 0;
                }
                if (toRemove <= 0) break;
            }
        }

        // Recompensa
        plugin.getEconomy().deposit(player.getUniqueId(), mission.getReward());
        missionManager.completeMission(player.getUniqueId(), mission.getId());
        player.closeInventory();
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        player.sendMessage(ChatColor.GREEN + "  ✔ Missão concluída: §b" + mission.getTitle());
        player.sendMessage(ChatColor.GREEN + "  Recompensa: §a+" + String.format("%.0f", mission.getReward()) + " moedas");
        player.sendMessage(ChatColor.GRAY + "  Cooldown: " + mission.getCooldownMinutes() + " minutos");
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    private void handleKillMission(Player player, Mission mission) {
        int progress = missionManager.getProgress(player.getUniqueId(), mission.getId());
        player.sendMessage(ChatColor.YELLOW + "📋 Missão: " + mission.getTitle());
        player.sendMessage(ChatColor.GRAY + mission.getDescription());
        player.sendMessage(ChatColor.WHITE + "Progresso: §b" + progress + "/" + mission.getAmount());
        player.sendMessage(ChatColor.GREEN + "Recompensa: §a" + String.format("%.0f", mission.getReward()) + " moedas");

        if (missionManager.canComplete(player.getUniqueId(), mission)) {
            plugin.getEconomy().deposit(player.getUniqueId(), mission.getReward());
            missionManager.completeMission(player.getUniqueId(), mission.getId());
            player.closeInventory();
            player.sendMessage(ChatColor.GREEN + "✔ Missão concluída! §a+" + String.format("%.0f", mission.getReward()) + " moedas");
        }
    }

    // Registra kills de mob para missões
    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (!(event.getEntity().getKiller() instanceof Player player)) return;
        String mobType = event.getEntityType().name();

        for (Mission m : missionManager.getAllMissions()) {
            if (m.getType() == Mission.Type.KILL_MOB
                    && m.getTarget().equalsIgnoreCase(mobType)
                    && !missionManager.isOnCooldown(player.getUniqueId(), m.getId())) {
                missionManager.addProgress(player.getUniqueId(), m.getId(), 1);
                int progress = missionManager.getProgress(player.getUniqueId(), m.getId());
                if (progress == m.getAmount()) {
                    player.sendMessage(ChatColor.GREEN + "✔ Meta atingida: §b" + m.getTitle() + " §7| Fale com o §cCaçador §7para resgatar!");
                } else if (progress % 2 == 0 || progress == 1) {
                    player.sendMessage(ChatColor.GRAY + "⚔ " + m.getTitle() + ": §b" + progress + "/" + m.getAmount());
                }
            }
        }
        missionManager.save();
    }
}
