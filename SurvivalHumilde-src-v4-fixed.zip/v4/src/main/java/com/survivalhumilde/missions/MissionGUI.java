package com.survivalhumilde.missions;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class MissionGUI {

    private final Main plugin;
    private final MissionManager missionManager;

    public MissionGUI(Main plugin) {
        this.plugin = plugin;
        this.missionManager = plugin.getMissionManager();
    }

    public void open(Player player, MissionNPC npc) {
        List<Mission> missions = missionManager.getMissionsForNpc(npc.getMissionPrefix());
        int size = Math.max(9, ((missions.size() / 9) + 1) * 9);
        size = Math.min(size, 54);

        Inventory inv = Bukkit.createInventory(null, size, npc.getDisplayName() + " §8- Missões");

        for (int i = 0; i < Math.min(missions.size(), size); i++) {
            Mission m = missions.get(i);
            inv.setItem(i, buildItem(player, m));
        }

        player.openInventory(inv);
    }

    private ItemStack buildItem(Player player, Mission mission) {
        boolean onCooldown = missionManager.isOnCooldown(player.getUniqueId(), mission.getId());
        int progress = missionManager.getProgress(player.getUniqueId(), mission.getId());

        Material mat;
        if (onCooldown) {
            mat = Material.CLOCK;
        } else if (mission.getType() == Mission.Type.COLLECT) {
            ItemStack req = mission.getRequiredItem();
            mat = (req != null) ? req.getType() : Material.CHEST;
        } else {
            mat = Material.IRON_SWORD;
        }

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        if (onCooldown) {
            meta.setDisplayName(ChatColor.GRAY + "⏳ " + mission.getTitle());
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.RED + "Em cooldown!");
            lore.add(ChatColor.GRAY + "Disponível em: §c" + missionManager.getRemainingCooldownMinutes(player.getUniqueId(), mission.getId()) + " min");
            meta.setLore(lore);
        } else {
            meta.setDisplayName(ChatColor.YELLOW + "📜 " + mission.getTitle());
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + mission.getDescription());
            lore.add("");
            if (mission.getType() == Mission.Type.COLLECT) {
                lore.add(ChatColor.WHITE + "Entregar: §b" + mission.getAmount() + "x " + formatMaterial(mission.getTarget()));
            } else {
                lore.add(ChatColor.WHITE + "Matar: §b" + mission.getAmount() + "x " + formatMob(mission.getTarget()));
                lore.add(ChatColor.WHITE + "Progresso: §b" + progress + "/" + mission.getAmount());
            }
            lore.add("");
            lore.add(ChatColor.GREEN + "Recompensa: §a" + String.format("%.0f", mission.getReward()) + " moedas");
            lore.add("");
            if (mission.getType() == Mission.Type.COLLECT) {
                lore.add(ChatColor.YELLOW + "» Clique para entregar os itens «");
            } else {
                lore.add(ChatColor.YELLOW + "» Aceitar / ver progresso «");
            }
            meta.setLore(lore);
        }

        item.setItemMeta(meta);
        return item;
    }

    private String formatMaterial(String mat) {
        return mat.replace("_", " ").toLowerCase();
    }

    private String formatMob(String mob) {
        return mob.replace("_", " ").toLowerCase();
    }
}
