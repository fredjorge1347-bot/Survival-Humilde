package com.survivalhumilde.missions;

import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;

import java.util.UUID;

public class MissionNPC {

    public enum NpcType { MINERADOR, LENHADOR, PESCADOR, CACADOR, FAZENDEIRO }

    private final String id;
    private final NpcType type;
    private final Location location;
    private UUID entityUUID;

    public MissionNPC(String id, NpcType type, Location location) {
        this.id = id;
        this.type = type;
        this.location = location;
    }

    public String getId() { return id; }
    public NpcType getType() { return type; }
    public Location getLocation() { return location; }
    public UUID getEntityUUID() { return entityUUID; }

    public String getMissionPrefix() {
        return switch (type) {
            case MINERADOR -> "mine";
            case LENHADOR  -> "wood";
            case PESCADOR  -> "fish";
            case CACADOR   -> "hunt";
            case FAZENDEIRO -> "farm";
        };
    }

    public String getDisplayName() {
        return switch (type) {
            case MINERADOR  -> "§6§lMinerador";
            case LENHADOR   -> "§a§lLenhador";
            case PESCADOR   -> "§b§lPescador";
            case CACADOR    -> "§c§lCaçador";
            case FAZENDEIRO -> "§e§lFazendeiro";
        };
    }

    public void spawn() {
        if (location.getWorld() == null) return;
        ArmorStand stand = (ArmorStand) location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
        stand.setCustomName(getDisplayName());
        stand.setCustomNameVisible(true);
        stand.setGravity(false);
        stand.setCanPickupItems(false);
        stand.setInvulnerable(true);
        stand.setVisible(true);
        entityUUID = stand.getUniqueId();
    }

    public void despawn() {
        if (entityUUID != null && location.getWorld() != null) {
            location.getWorld().getEntities().stream()
                    .filter(e -> e.getUniqueId().equals(entityUUID))
                    .findFirst()
                    .ifPresent(org.bukkit.entity.Entity::remove);
        }
    }
}
