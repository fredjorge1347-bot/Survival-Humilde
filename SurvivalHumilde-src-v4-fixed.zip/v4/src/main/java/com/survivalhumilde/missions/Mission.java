package com.survivalhumilde.missions;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class Mission {

    public enum Type { COLLECT, KILL_MOB, KILL_PLAYER }

    private final String id;
    private final String title;
    private final String description;
    private final Type type;
    private final String target;    // material name ou mob name
    private final int amount;
    private final double reward;
    private final int cooldownMinutes;

    public Mission(String id, String title, String description, Type type, String target, int amount, double reward, int cooldownMinutes) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.type = type;
        this.target = target;
        this.amount = amount;
        this.reward = reward;
        this.cooldownMinutes = cooldownMinutes;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Type getType() { return type; }
    public String getTarget() { return target; }
    public int getAmount() { return amount; }
    public double getReward() { return reward; }
    public int getCooldownMinutes() { return cooldownMinutes; }

    // Para missões COLLECT: retorna o ItemStack necessário
    public ItemStack getRequiredItem() {
        if (type != Type.COLLECT) return null;
        try {
            Material mat = Material.valueOf(target.toUpperCase());
            return new ItemStack(mat, amount);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
