package com.survivalhumilde.missions;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class NPCManager {

    private final Main plugin;
    private final Map<String, MissionNPC> npcs = new LinkedHashMap<>();   // id -> NPC
    private final Map<UUID, String> entityToNpc = new HashMap<>();         // entityUUID -> npcId
    private File dataFile;
    private FileConfiguration dataConfig;

    public NPCManager(Main plugin) {
        this.plugin = plugin;
    }

    public void load() {
        dataFile = new File(plugin.getDataFolder(), "npcs.yml");
        if (!dataFile.exists()) try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection section = dataConfig.getConfigurationSection("npcs");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;
            String worldName = s.getString("world");
            World world = Bukkit.getWorld(worldName != null ? worldName : "world");
            if (world == null) continue;
            double x = s.getDouble("x"), y = s.getDouble("y"), z = s.getDouble("z");
            float yaw = (float) s.getDouble("yaw");
            Location loc = new Location(world, x, y, z, yaw, 0);
            MissionNPC.NpcType type;
            try { type = MissionNPC.NpcType.valueOf(s.getString("type", "MINERADOR")); }
            catch (Exception e) { type = MissionNPC.NpcType.MINERADOR; }
            MissionNPC npc = new MissionNPC(id, type, loc);
            npc.spawn();
            npcs.put(id, npc);
            if (npc.getEntityUUID() != null) entityToNpc.put(npc.getEntityUUID(), id);
        }
    }

    public void despawnAll() {
        for (MissionNPC npc : npcs.values()) npc.despawn();
        npcs.clear();
        entityToNpc.clear();
    }

    public boolean spawnNpc(String id, MissionNPC.NpcType type, Location location) {
        if (npcs.containsKey(id)) return false;
        MissionNPC npc = new MissionNPC(id, type, location);
        npc.spawn();
        npcs.put(id, npc);
        if (npc.getEntityUUID() != null) entityToNpc.put(npc.getEntityUUID(), id);
        save();
        return true;
    }

    public boolean removeNpc(String id) {
        MissionNPC npc = npcs.remove(id);
        if (npc == null) return false;
        if (npc.getEntityUUID() != null) entityToNpc.remove(npc.getEntityUUID());
        npc.despawn();
        save();
        return true;
    }

    public MissionNPC getNpcByEntity(UUID entityUUID) {
        String id = entityToNpc.get(entityUUID);
        return id == null ? null : npcs.get(id);
    }

    public Collection<MissionNPC> getAllNpcs() { return npcs.values(); }

    public void save() {
        dataConfig.set("npcs", null);
        for (MissionNPC npc : npcs.values()) {
            String base = "npcs." + npc.getId() + ".";
            dataConfig.set(base + "type", npc.getType().name());
            Location loc = npc.getLocation();
            dataConfig.set(base + "world", loc.getWorld() != null ? loc.getWorld().getName() : "world");
            dataConfig.set(base + "x", loc.getX());
            dataConfig.set(base + "y", loc.getY());
            dataConfig.set(base + "z", loc.getZ());
            dataConfig.set(base + "yaw", (double) loc.getYaw());
        }
        try { dataConfig.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }
}
