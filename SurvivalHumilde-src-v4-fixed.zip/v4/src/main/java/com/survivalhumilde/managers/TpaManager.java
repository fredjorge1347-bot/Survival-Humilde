package com.survivalhumilde.managers;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TpaManager {

    private final Main plugin;
    // requester -> target
    private final Map<UUID, UUID> pendingRequests = new HashMap<>();
    // requester -> task de expiração
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<>();

    public TpaManager(Main plugin) {
        this.plugin = plugin;
    }

    public void sendRequest(Player requester, Player target) {
        UUID rId = requester.getUniqueId();
        UUID tId = target.getUniqueId();

        // Cancelar pedido anterior se existir
        cancelRequest(rId);

        pendingRequests.put(rId, tId);

        int timeoutSeconds = plugin.getConfig().getInt("teleport.tpa-timeout", 60);

        // Tarefa de expiração automática
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pendingRequests.containsKey(rId)) {
                pendingRequests.remove(rId);
                expiryTasks.remove(rId);

                Player r = Bukkit.getPlayer(rId);
                Player t = Bukkit.getPlayer(tId);

                if (r != null && r.isOnline())
                    r.sendMessage(org.bukkit.ChatColor.RED + "Seu pedido de TPA expirou.");
                if (t != null && t.isOnline())
                    t.sendMessage(org.bukkit.ChatColor.GRAY + "Pedido de TPA de " + r.getName() + " expirou.");
            }
        }, timeoutSeconds * 20L);

        expiryTasks.put(rId, task);
    }

    // Retorna o UUID do requester que enviou pedido para o target dado
    public UUID getPendingRequesterFor(UUID targetId) {
        for (Map.Entry<UUID, UUID> entry : pendingRequests.entrySet()) {
            if (entry.getValue().equals(targetId)) return entry.getKey();
        }
        return null;
    }

    public void cancelRequest(UUID requesterId) {
        pendingRequests.remove(requesterId);
        BukkitTask task = expiryTasks.remove(requesterId);
        if (task != null) task.cancel();
    }

    public boolean hasPendingRequest(UUID targetId) {
        return getPendingRequesterFor(targetId) != null;
    }
}
