package com.survivalhumilde.managers;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataManager {

    private final Main plugin;

    private File balanceFile, homesFile, locksFile, dataFile;
    private FileConfiguration balanceCfg, homesCfg, locksCfg, dataCfg;

    private final Map<UUID, Double> balances = new HashMap<>();

    public DataManager(Main plugin) {
        this.plugin = plugin;
        initFiles();
        loadBalances();
    }

    private void createIfNotExists(File file) {
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Nao foi possivel criar " + file.getName() + ": " + e.getMessage());
            }
        }
    }

    private void initFiles() {
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists()) dataFolder.mkdirs();

        balanceFile = new File(dataFolder, "balances.yml");
        homesFile   = new File(dataFolder, "homes.yml");
        locksFile   = new File(dataFolder, "locks.yml");
        dataFile    = new File(dataFolder, "data.yml");

        // CORREÇÃO: criar os arquivos fisicamente se não existirem
        createIfNotExists(balanceFile);
        createIfNotExists(homesFile);
        createIfNotExists(locksFile);
        createIfNotExists(dataFile);

        balanceCfg = YamlConfiguration.loadConfiguration(balanceFile);
        homesCfg   = YamlConfiguration.loadConfiguration(homesFile);
        locksCfg   = YamlConfiguration.loadConfiguration(locksFile);
        dataCfg    = YamlConfiguration.loadConfiguration(dataFile);
    }

    // ─── Economia ─────────────────────────────────────────────────────────────

    private void loadBalances() {
        balances.clear();
        for (String key : balanceCfg.getKeys(false)) {
            try {
                balances.put(UUID.fromString(key), balanceCfg.getDouble(key));
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public double getBalance(UUID uuid) {
        return balances.getOrDefault(uuid,
                plugin.getConfig().getDouble("economy.starting-balance", 100.0));
    }

    public void setBalance(UUID uuid, double amount) {
        balances.put(uuid, amount);
        balanceCfg.set(uuid.toString(), amount);
        saveAsync(balanceCfg, balanceFile);
    }

    public void deposit(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) + amount);
    }

    public boolean withdraw(UUID uuid, double amount) {
        double current = getBalance(uuid);
        if (current < amount) return false;
        setBalance(uuid, current - amount);
        return true;
    }

    public boolean hasAccount(UUID uuid) {
        return true;
    }

    // ─── Spawn ────────────────────────────────────────────────────────────────

    public Location getSpawn() {
        if (!dataCfg.contains("spawn.world")) {
            String worldName = plugin.getConfig().getString("spawn.world", "world");
            World w = Bukkit.getWorld(worldName);
            if (w == null) w = Bukkit.getWorlds().get(0);
            return new Location(w,
                    plugin.getConfig().getDouble("spawn.x", 0.5),
                    plugin.getConfig().getDouble("spawn.y", 64),
                    plugin.getConfig().getDouble("spawn.z", 0.5),
                    (float) plugin.getConfig().getDouble("spawn.yaw", 0),
                    (float) plugin.getConfig().getDouble("spawn.pitch", 0));
        }
        String worldName = dataCfg.getString("spawn.world");
        World w = Bukkit.getWorld(worldName);
        if (w == null) w = Bukkit.getWorlds().get(0);
        return new Location(w,
                dataCfg.getDouble("spawn.x"),
                dataCfg.getDouble("spawn.y"),
                dataCfg.getDouble("spawn.z"),
                (float) dataCfg.getDouble("spawn.yaw"),
                (float) dataCfg.getDouble("spawn.pitch"));
    }

    public void setSpawn(Location loc) {
        dataCfg.set("spawn.world", loc.getWorld().getName());
        dataCfg.set("spawn.x", loc.getX());
        dataCfg.set("spawn.y", loc.getY());
        dataCfg.set("spawn.z", loc.getZ());
        dataCfg.set("spawn.yaw", loc.getYaw());
        dataCfg.set("spawn.pitch", loc.getPitch());
        saveAsync(dataCfg, dataFile);
    }

    // ─── Homes ────────────────────────────────────────────────────────────────

    public FileConfiguration getHomesCfg() { return homesCfg; }

    public void saveHomes() {
        saveAsync(homesCfg, homesFile);
    }

    // ─── Locks ────────────────────────────────────────────────────────────────

    public FileConfiguration getLocksCfg() { return locksCfg; }

    public void saveLocks() {
        saveAsync(locksCfg, locksFile);
    }

    // ─── Geral ────────────────────────────────────────────────────────────────

    public void saveAll() {
        balances.forEach((uuid, bal) -> balanceCfg.set(uuid.toString(), bal));
        try {
            balanceCfg.save(balanceFile);
            homesCfg.save(homesFile);
            locksCfg.save(locksFile);
            dataCfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Erro ao salvar dados: " + e.getMessage());
        }
    }

    private void saveAsync(FileConfiguration cfg, File file) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                cfg.save(file);
            } catch (IOException e) {
                plugin.getLogger().warning("Erro ao salvar " + file.getName() + ": " + e.getMessage());
            }
        });
    }
}
