package com.survivalhumilde.managers;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.*;

public class HomeManager {

    private final Main plugin;
    private final int maxHomes;

    public HomeManager(Main plugin) {
        this.plugin = plugin;
        this.maxHomes = plugin.getConfig().getInt("homes.max-homes", 3);
    }

    private String key(UUID uuid) {
        return uuid.toString();
    }

    public Map<String, Location> getHomes(UUID uuid) {
        FileConfiguration cfg = plugin.getDataManager().getHomesCfg();
        String base = key(uuid);
        Map<String, Location> homes = new LinkedHashMap<>();

        if (!cfg.contains(base)) return homes;

        for (String name : cfg.getConfigurationSection(base).getKeys(false)) {
            Location loc = deserialize(cfg, base + "." + name);
            if (loc != null) homes.put(name, loc);
        }
        return homes;
    }

    public boolean setHome(UUID uuid, String name, Location loc) {
        Map<String, Location> homes = getHomes(uuid);
        if (!homes.containsKey(name) && homes.size() >= maxHomes) {
            return false; // Limite atingido
        }
        FileConfiguration cfg = plugin.getDataManager().getHomesCfg();
        String path = key(uuid) + "." + name.toLowerCase();
        serialize(cfg, path, loc);
        plugin.getDataManager().saveHomes();
        return true;
    }

    public Location getHome(UUID uuid, String name) {
        FileConfiguration cfg = plugin.getDataManager().getHomesCfg();
        String path = key(uuid) + "." + name.toLowerCase();
        if (!cfg.contains(path)) return null;
        return deserialize(cfg, path);
    }

    public boolean deleteHome(UUID uuid, String name) {
        FileConfiguration cfg = plugin.getDataManager().getHomesCfg();
        String path = key(uuid) + "." + name.toLowerCase();
        if (!cfg.contains(path)) return false;
        cfg.set(path, null);
        plugin.getDataManager().saveHomes();
        return true;
    }

    public int getMaxHomes() { return maxHomes; }

    // ─── Serialização de Location ───────────────────────────────────────────────

    private void serialize(FileConfiguration cfg, String path, Location loc) {
        cfg.set(path + ".world", loc.getWorld().getName());
        cfg.set(path + ".x", loc.getX());
        cfg.set(path + ".y", loc.getY());
        cfg.set(path + ".z", loc.getZ());
        cfg.set(path + ".yaw", loc.getYaw());
        cfg.set(path + ".pitch", loc.getPitch());
    }

    private Location deserialize(FileConfiguration cfg, String path) {
        String worldName = cfg.getString(path + ".world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world,
                cfg.getDouble(path + ".x"),
                cfg.getDouble(path + ".y"),
                cfg.getDouble(path + ".z"),
                (float) cfg.getDouble(path + ".yaw"),
                (float) cfg.getDouble(path + ".pitch"));
    }
}
