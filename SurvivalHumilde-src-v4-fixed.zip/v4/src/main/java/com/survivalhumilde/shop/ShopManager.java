package com.survivalhumilde.shop;

import org.bukkit.Material;

import java.util.*;

public class ShopManager {

    public static final String CAT_MINERIOS    = "Minerios";
    public static final String CAT_FERRAMENTAS = "Ferramentas";
    public static final String CAT_ARMADURAS   = "Armaduras";
    public static final String CAT_BLOCOS      = "Blocos";
    public static final String CAT_COMIDA      = "Comida";
    public static final String CAT_POCOES      = "Pocoes";

    private final List<ShopItem> items = new ArrayList<>();
    private final List<String> categories = new ArrayList<>();

    public ShopManager() {
        registerCategories();
        registerItems();
    }

    private void registerCategories() {
        categories.add(CAT_MINERIOS);
        categories.add(CAT_FERRAMENTAS);
        categories.add(CAT_ARMADURAS);
        categories.add(CAT_BLOCOS);
        categories.add(CAT_COMIDA);
        categories.add(CAT_POCOES);
    }

    private void registerItems() {

        // ─── Minerios ──────────────────────────────────────────────────────────
        // Comuns ficam acessíveis, raros exigem muito farm
        add(Material.COAL,               "Carvao",           15,     8,      CAT_MINERIOS);
        add(Material.IRON_INGOT,         "Ferro",            60,     30,     CAT_MINERIOS);
        add(Material.COPPER_INGOT,       "Cobre",            35,     15,     CAT_MINERIOS);
        add(Material.GOLD_INGOT,         "Ouro",             150,    70,     CAT_MINERIOS);
        add(Material.REDSTONE,           "Redstone",         25,     10,     CAT_MINERIOS);
        add(Material.LAPIS_LAZULI,       "Lapis",            40,     18,     CAT_MINERIOS);
        add(Material.DIAMOND,            "Diamante",         1500,   800,    CAT_MINERIOS);
        add(Material.EMERALD,            "Esmeralda",        1200,   600,    CAT_MINERIOS);
        add(Material.QUARTZ,             "Quartzo",          30,     12,     CAT_MINERIOS);
        add(Material.AMETHYST_SHARD,     "Ametista",         80,     35,     CAT_MINERIOS);
        add(Material.NETHERITE_INGOT,    "Netherite",        25000,  15000,  CAT_MINERIOS);
        add(Material.ANCIENT_DEBRIS,     "Escombro Antigo",  8000,   5000,   CAT_MINERIOS);

        // ─── Ferramentas ───────────────────────────────────────────────────────
        // Madeira/Pedra: acessível. Ferro: trabalhoso. Diamante: meta. Netherite: sonho.
        add(Material.WOODEN_PICKAXE,     "Picareta de Madeira",    80,     20,     CAT_FERRAMENTAS);
        add(Material.STONE_PICKAXE,      "Picareta de Pedra",      150,    40,     CAT_FERRAMENTAS);
        add(Material.IRON_PICKAXE,       "Picareta de Ferro",      800,    300,    CAT_FERRAMENTAS);
        add(Material.GOLDEN_PICKAXE,     "Picareta de Ouro",       600,    200,    CAT_FERRAMENTAS);
        add(Material.DIAMOND_PICKAXE,    "Picareta de Diamante",   8000,   4000,   CAT_FERRAMENTAS);
        add(Material.NETHERITE_PICKAXE,  "Picareta Netherite",     80000,  50000,  CAT_FERRAMENTAS);

        add(Material.IRON_AXE,           "Machado de Ferro",       700,    250,    CAT_FERRAMENTAS);
        add(Material.DIAMOND_AXE,        "Machado de Diamante",    7500,   3500,   CAT_FERRAMENTAS);
        add(Material.NETHERITE_AXE,      "Machado Netherite",      80000,  50000,  CAT_FERRAMENTAS);

        add(Material.IRON_SHOVEL,        "Pa de Ferro",            500,    150,    CAT_FERRAMENTAS);
        add(Material.DIAMOND_SHOVEL,     "Pa de Diamante",         6000,   3000,   CAT_FERRAMENTAS);

        add(Material.IRON_HOE,           "Enxada de Ferro",        400,    100,    CAT_FERRAMENTAS);
        add(Material.DIAMOND_HOE,        "Enxada de Diamante",     5000,   2000,   CAT_FERRAMENTAS);

        add(Material.BOW,                "Arco",                   300,    100,    CAT_FERRAMENTAS);
        add(Material.CROSSBOW,           "Besta",                  600,    200,    CAT_FERRAMENTAS);
        add(Material.ARROW,              "Flecha",                 5,      2,      CAT_FERRAMENTAS);
        add(Material.FISHING_ROD,        "Vara de Pesca",          200,    60,     CAT_FERRAMENTAS);
        add(Material.FLINT_AND_STEEL,    "Pederneira",             120,    40,     CAT_FERRAMENTAS);
        add(Material.SHEARS,             "Tesoura",                150,    50,     CAT_FERRAMENTAS);

        // ─── Armaduras ─────────────────────────────────────────────────────────
        add(Material.IRON_HELMET,        "Elmo de Ferro",          700,    250,    CAT_ARMADURAS);
        add(Material.IRON_CHESTPLATE,    "Peitoral de Ferro",      1200,   500,    CAT_ARMADURAS);
        add(Material.IRON_LEGGINGS,      "Calca de Ferro",         1000,   400,    CAT_ARMADURAS);
        add(Material.IRON_BOOTS,         "Botas de Ferro",         600,    200,    CAT_ARMADURAS);

        add(Material.DIAMOND_HELMET,     "Elmo de Diamante",       8000,   4000,   CAT_ARMADURAS);
        add(Material.DIAMOND_CHESTPLATE, "Peitoral de Diamante",   15000,  7500,   CAT_ARMADURAS);
        add(Material.DIAMOND_LEGGINGS,   "Calca de Diamante",      12000,  6000,   CAT_ARMADURAS);
        add(Material.DIAMOND_BOOTS,      "Botas de Diamante",      7000,   3500,   CAT_ARMADURAS);

        add(Material.NETHERITE_HELMET,    "Elmo Netherite",        80000,  55000,  CAT_ARMADURAS);
        add(Material.NETHERITE_CHESTPLATE,"Peitoral Netherite",    150000, 100000, CAT_ARMADURAS);
        add(Material.NETHERITE_LEGGINGS,  "Calca Netherite",       120000, 80000,  CAT_ARMADURAS);
        add(Material.NETHERITE_BOOTS,     "Botas Netherite",       70000,  48000,  CAT_ARMADURAS);

        add(Material.SHIELD,             "Escudo",                 500,    150,    CAT_ARMADURAS);
        add(Material.ELYTRA,             "Elytra",                 500000, 300000, CAT_ARMADURAS);

        // ─── Blocos ────────────────────────────────────────────────────────────
        add(Material.DIRT,               "Terra",                  2,      0,      CAT_BLOCOS);
        add(Material.GRASS_BLOCK,        "Grama",                  5,      1,      CAT_BLOCOS);
        add(Material.STONE,              "Pedra",                  5,      1,      CAT_BLOCOS);
        add(Material.COBBLESTONE,        "Paralelepipedo",         3,      1,      CAT_BLOCOS);
        add(Material.SAND,               "Areia",                  8,      3,      CAT_BLOCOS);
        add(Material.GRAVEL,             "Cascalho",               6,      2,      CAT_BLOCOS);
        add(Material.OAK_LOG,            "Tronco Carvalho",        15,     5,      CAT_BLOCOS);
        add(Material.BIRCH_LOG,          "Tronco Betula",          15,     5,      CAT_BLOCOS);
        add(Material.SPRUCE_LOG,         "Tronco Pinheiro",        15,     5,      CAT_BLOCOS);
        add(Material.JUNGLE_LOG,         "Tronco Selva",           15,     5,      CAT_BLOCOS);
        add(Material.OAK_PLANKS,         "Tabua Carvalho",         8,      2,      CAT_BLOCOS);
        add(Material.GLASS,              "Vidro",                  20,     7,      CAT_BLOCOS);
        add(Material.OBSIDIAN,           "Obsidiana",              120,    50,     CAT_BLOCOS);
        add(Material.CRYING_OBSIDIAN,    "Obsidiana Chorosa",      200,    80,     CAT_BLOCOS);
        add(Material.NETHERRACK,         "Netherrack",             8,      2,      CAT_BLOCOS);
        add(Material.SOUL_SAND,          "Areia da Alma",          35,     12,     CAT_BLOCOS);
        add(Material.GLOWSTONE,          "Pedra Brilhante",        80,     30,     CAT_BLOCOS);
        add(Material.END_STONE,          "Pedra do Fim",           60,     20,     CAT_BLOCOS);
        add(Material.PURPUR_BLOCK,       "Bloco Purpur",           100,    40,     CAT_BLOCOS);
        add(Material.BOOKSHELF,          "Estante",                150,    50,     CAT_BLOCOS);

        // ─── Comida ────────────────────────────────────────────────────────────
        add(Material.BREAD,              "Pao",                    25,     8,      CAT_COMIDA);
        add(Material.COOKED_BEEF,        "Bife Cozido",            40,     15,     CAT_COMIDA);
        add(Material.COOKED_CHICKEN,     "Frango Cozido",          35,     12,     CAT_COMIDA);
        add(Material.COOKED_PORKCHOP,    "Costeleta Cozida",       35,     12,     CAT_COMIDA);
        add(Material.COOKED_COD,        "Peixe Cozido",           25,     8,      CAT_COMIDA);
        add(Material.GOLDEN_APPLE,       "Maca Dourada",           500,    250,    CAT_COMIDA);
        add(Material.ENCHANTED_GOLDEN_APPLE,"Maca Encantada",      50000,  35000,  CAT_COMIDA);
        add(Material.CAKE,               "Bolo",                   200,    60,     CAT_COMIDA);
        add(Material.PUMPKIN_PIE,        "Torta de Abobora",       50,     15,     CAT_COMIDA);
        add(Material.COOKIE,             "Biscoito",               10,     3,      CAT_COMIDA);

        // ─── Pocoes ────────────────────────────────────────────────────────────
        add(Material.POTION,             "Pocao de Cura",          150,    50,     CAT_POCOES);
        add(Material.SPLASH_POTION,      "Pocao de Arremesso",     200,    70,     CAT_POCOES);
        add(Material.LINGERING_POTION,   "Pocao Persistente",      350,    120,    CAT_POCOES);
        add(Material.EXPERIENCE_BOTTLE,  "Frasco de XP",           100,    30,     CAT_POCOES);
        add(Material.BLAZE_ROD,          "Vara de Blaze",          250,    100,    CAT_POCOES);
        add(Material.GHAST_TEAR,         "Lagrima de Ghast",       500,    200,    CAT_POCOES);
        add(Material.MAGMA_CREAM,        "Creme de Magma",         120,    50,     CAT_POCOES);
        add(Material.SUGAR,              "Acucar",                 15,     5,      CAT_POCOES);
        add(Material.SPIDER_EYE,         "Olho de Aranha",         40,     15,     CAT_POCOES);
        add(Material.FERMENTED_SPIDER_EYE,"Olho Fermentado",       80,     30,     CAT_POCOES);
        add(Material.NETHER_WART,        "Verruga do Nether",      60,     25,     CAT_POCOES);
        add(Material.GOLDEN_CARROT,      "Cenoura Dourada",        150,    60,     CAT_POCOES);
        add(Material.GLISTERING_MELON_SLICE,"Melancia Brilhante",  100,    40,     CAT_POCOES);
        add(Material.PUFFERFISH,         "Baiacu",                 80,     30,     CAT_POCOES);
        add(Material.RABBIT_FOOT,        "Pata de Coelho",         120,    50,     CAT_POCOES);
    }

    private void add(Material mat, String name, double buy, double sell, String cat) {
        items.add(new ShopItem(mat, name, buy, sell, cat));
    }

    public List<ShopItem> getAll() { return Collections.unmodifiableList(items); }

    public List<ShopItem> getByCategory(String category) {
        List<ShopItem> result = new ArrayList<>();
        for (ShopItem item : items) {
            if (item.getCategory().equals(category)) result.add(item);
        }
        return result;
    }

    public ShopItem findByName(String name) {
        for (ShopItem item : items) {
            if (item.getDisplayName().equalsIgnoreCase(name) ||
                item.getMaterial().name().equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null;
    }

    public List<String> getCategories() { return Collections.unmodifiableList(categories); }
}
