package com.survivalhumilde.shop;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI da loja — minimalista para Mobile/Geyser.
 * Usa inventários de 54 slots (6 linhas).
 */
public class ShopGUI {

    private final Main plugin;

    // Títulos reconhecíveis para o listener
    public static final String TITLE_MAIN     = ChatColor.DARK_GREEN + "Loja";
    public static final String TITLE_PREFIX   = ChatColor.DARK_GREEN + "Loja: ";
    public static final String TITLE_BUY      = ChatColor.DARK_GREEN + "Comprar: ";
    public static final String TITLE_SELL     = ChatColor.DARK_GREEN + "Vender: ";

    public ShopGUI(Main plugin) {
        this.plugin = plugin;
    }

    // ─── Menu Principal (categorias) ───────────────────────────────────────────

    public void openMain(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_MAIN);

        List<String> categories = plugin.getShopManager().getCategories();

        // Ícones de categoria
        Material[] icons = {
            Material.DIAMOND,           // Minerios
            Material.DIAMOND_PICKAXE,   // Ferramentas
            Material.DIAMOND_CHESTPLATE,// Armaduras
            Material.GRASS_BLOCK,       // Blocos
            Material.COOKED_BEEF,       // Comida
            Material.POTION             // Pocoes
        };

        int[] slots = {10, 12, 14, 16, 28, 30};

        for (int i = 0; i < categories.size() && i < slots.length; i++) {
            ItemStack item = new ItemStack(icons[i]);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + categories.get(i));
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Clique para ver itens");
            meta.setLore(lore);
            item.setItemMeta(meta);
            inv.setItem(slots[i], item);
        }

        // Botão de fechar
        inv.setItem(49, makeItem(Material.BARRIER, ChatColor.RED + "Fechar", null));

        player.openInventory(inv);
    }

    // ─── Menu de Categoria ─────────────────────────────────────────────────────

    public void openCategory(Player player, String category, int page) {
        List<ShopItem> items = plugin.getShopManager().getByCategory(category);
        int totalPages = (int) Math.ceil(items.size() / 45.0);
        if (totalPages == 0) totalPages = 1;

        Inventory inv = Bukkit.createInventory(null, 54, TITLE_PREFIX + category);

        int start = page * 45;
        int end = Math.min(start + 45, items.size());

        for (int i = start; i < end; i++) {
            ShopItem si = items.get(i);
            ItemStack item = new ItemStack(si.getMaterial());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.YELLOW + si.getDisplayName());

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GREEN + "Comprar: " + plugin.getEconomy().format(si.getBuyPrice()));
            if (si.getSellPrice() > 0) {
                lore.add(ChatColor.GOLD + "Vender: " + plugin.getEconomy().format(si.getSellPrice()));
            }
            lore.add("");
            lore.add(ChatColor.GRAY + "Clique para comprar");
            lore.add(ChatColor.GRAY + "Shift+Clique para vender");
            meta.setLore(lore);
            item.setItemMeta(meta);
            inv.setItem(i - start, item);
        }

        // Navegação
        if (page > 0) {
            inv.setItem(45, makeItem(Material.ARROW, ChatColor.WHITE + "Anterior", null));
        }
        inv.setItem(49, makeItem(Material.NETHER_STAR, ChatColor.YELLOW + "Menu Principal", null));
        inv.setItem(53, makeItem(Material.BARRIER, ChatColor.RED + "Fechar", null));
        if (page < totalPages - 1) {
            inv.setItem(47, makeItem(Material.ARROW, ChatColor.WHITE + "Proximo", null));
        }

        player.openInventory(inv);
    }

    // ─── Confirmação de Compra ─────────────────────────────────────────────────

    public void openBuyConfirm(Player player, ShopItem si, int qty) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_BUY + si.getDisplayName());

        // Item sendo comprado
        ItemStack display = new ItemStack(si.getMaterial(), qty);
        ItemMeta meta = display.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + si.getDisplayName() + " x" + qty);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GREEN + "Total: " + plugin.getEconomy().format(si.getBuyPrice() * qty));
        meta.setLore(lore);
        display.setItemMeta(meta);
        inv.setItem(13, display);

        // Quantidade
        inv.setItem(9,  makeItem(Material.RED_CONCRETE,    ChatColor.RED + "-10",    null));
        inv.setItem(10, makeItem(Material.ORANGE_CONCRETE,  ChatColor.RED + "-1",     null));
        inv.setItem(16, makeItem(Material.LIME_CONCRETE,    ChatColor.GREEN + "+1",   null));
        inv.setItem(17, makeItem(Material.GREEN_CONCRETE,   ChatColor.GREEN + "+10",  null));

        // Confirmar / Cancelar
        inv.setItem(11, makeItem(Material.GREEN_WOOL, ChatColor.GREEN + "Confirmar Compra", List.of(
                ChatColor.GRAY + "Preco: " + plugin.getEconomy().format(si.getBuyPrice() * qty)
        )));
        inv.setItem(15, makeItem(Material.RED_WOOL, ChatColor.RED + "Cancelar", null));

        player.openInventory(inv);
    }

    // ─── Confirmação de Venda ──────────────────────────────────────────────────

    public void openSellConfirm(Player player, ShopItem si, int qty) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_SELL + si.getDisplayName());

        ItemStack display = new ItemStack(si.getMaterial(), qty);
        ItemMeta meta = display.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + si.getDisplayName() + " x" + qty);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GOLD + "Voce receberá: " + plugin.getEconomy().format(si.getSellPrice() * qty));
        meta.setLore(lore);
        display.setItemMeta(meta);
        inv.setItem(13, display);

        inv.setItem(9,  makeItem(Material.RED_CONCRETE,   ChatColor.RED + "-10",   null));
        inv.setItem(10, makeItem(Material.ORANGE_CONCRETE, ChatColor.RED + "-1",    null));
        inv.setItem(16, makeItem(Material.LIME_CONCRETE,   ChatColor.GREEN + "+1",  null));
        inv.setItem(17, makeItem(Material.GREEN_CONCRETE,  ChatColor.GREEN + "+10", null));

        inv.setItem(11, makeItem(Material.GREEN_WOOL, ChatColor.GREEN + "Confirmar Venda", List.of(
                ChatColor.GRAY + "Voce receberá: " + plugin.getEconomy().format(si.getSellPrice() * qty)
        )));
        inv.setItem(15, makeItem(Material.RED_WOOL, ChatColor.RED + "Cancelar", null));

        player.openInventory(inv);
    }

    // ─── Helper ────────────────────────────────────────────────────────────────

    private ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (lore != null) meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
