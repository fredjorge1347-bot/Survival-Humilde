package com.survivalhumilde.shop;

import com.survivalhumilde.Main;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShopListener implements Listener {

    private final Main plugin;

    // Estado de cada jogador na GUI de confirmação
    private final Map<UUID, ShopItem> pendingItem = new HashMap<>();
    private final Map<UUID, Integer>  pendingQty  = new HashMap<>();
    private final Map<UUID, Boolean>  pendingBuy  = new HashMap<>(); // true=compra, false=venda
    private final Map<UUID, String>   pendingCat  = new HashMap<>();
    private final Map<UUID, Integer>  pendingPage = new HashMap<>();

    public ShopListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = event.getView().getTitle();
        if (!title.startsWith(ChatColor.DARK_GREEN + "Loja")) return;

        event.setCancelled(true);

        if (event.getCurrentItem() == null ||
            event.getCurrentItem().getType() == Material.AIR) return;

        String itemName = event.getCurrentItem().hasItemMeta() ?
                event.getCurrentItem().getItemMeta().getDisplayName() : "";

        UUID uuid = player.getUniqueId();

        // ─── Menu Principal ─────────────────────────────────────────────────────
        if (title.equals(ShopGUI.TITLE_MAIN)) {
            if (itemName.equals(ChatColor.RED + "Fechar")) {
                player.closeInventory(); return;
            }
            String cat = ChatColor.stripColor(itemName);
            if (plugin.getShopManager().getCategories().contains(cat)) {
                pendingCat.put(uuid, cat);
                pendingPage.put(uuid, 0);
                plugin.getShopGUI().openCategory(player, cat, 0);
            }
            return;
        }

        // ─── Menu de Categoria ──────────────────────────────────────────────────
        if (title.startsWith(ShopGUI.TITLE_PREFIX)) {
            String cat = title.replace(ShopGUI.TITLE_PREFIX, "");

            if (itemName.equals(ChatColor.YELLOW + "Menu Principal")) {
                plugin.getShopGUI().openMain(player); return;
            }
            if (itemName.equals(ChatColor.RED + "Fechar")) {
                player.closeInventory(); return;
            }
            if (itemName.equals(ChatColor.WHITE + "Proximo")) {
                int page = pendingPage.getOrDefault(uuid, 0) + 1;
                pendingPage.put(uuid, page);
                plugin.getShopGUI().openCategory(player, cat, page); return;
            }
            if (itemName.equals(ChatColor.WHITE + "Anterior")) {
                int page = Math.max(0, pendingPage.getOrDefault(uuid, 0) - 1);
                pendingPage.put(uuid, page);
                plugin.getShopGUI().openCategory(player, cat, page); return;
            }

            // Clicou em um item
            String cleanName = ChatColor.stripColor(itemName);
            ShopItem si = plugin.getShopManager().findByName(cleanName);
            if (si == null) return;

            pendingItem.put(uuid, si);
            pendingQty.put(uuid, 1);

            boolean isSell = event.isShiftClick();
            pendingBuy.put(uuid, !isSell);

            if (isSell && si.getSellPrice() <= 0) {
                player.sendMessage(ChatColor.RED + "Este item nao pode ser vendido.");
                return;
            }

            if (isSell) {
                plugin.getShopGUI().openSellConfirm(player, si, 1);
            } else {
                plugin.getShopGUI().openBuyConfirm(player, si, 1);
            }
            return;
        }

        // ─── Confirmação de Compra ──────────────────────────────────────────────
        if (title.startsWith(ShopGUI.TITLE_BUY)) {
            ShopItem si = pendingItem.get(uuid);
            if (si == null) { player.closeInventory(); return; }
            int qty = pendingQty.getOrDefault(uuid, 1);

            if (itemName.equals(ChatColor.RED + "Cancelar") ||
                itemName.equals(ChatColor.YELLOW + "Menu Principal")) {
                plugin.getShopGUI().openMain(player); return;
            }
            if (itemName.startsWith(ChatColor.RED + "-")) {
                int sub = itemName.contains("10") ? 10 : 1;
                qty = Math.max(1, qty - sub);
                pendingQty.put(uuid, qty);
                plugin.getShopGUI().openBuyConfirm(player, si, qty); return;
            }
            if (itemName.startsWith(ChatColor.GREEN + "+")) {
                int add = itemName.contains("10") ? 10 : 1;
                qty = Math.min(64, qty + add);
                pendingQty.put(uuid, qty);
                plugin.getShopGUI().openBuyConfirm(player, si, qty); return;
            }
            if (itemName.equals(ChatColor.GREEN + "Confirmar Compra")) {
                executeBuy(player, si, qty);
                plugin.getShopGUI().openCategory(player,
                        pendingCat.getOrDefault(uuid, si.getCategory()),
                        pendingPage.getOrDefault(uuid, 0));
            }
            return;
        }

        // ─── Confirmação de Venda ───────────────────────────────────────────────
        if (title.startsWith(ShopGUI.TITLE_SELL)) {
            ShopItem si = pendingItem.get(uuid);
            if (si == null) { player.closeInventory(); return; }
            int qty = pendingQty.getOrDefault(uuid, 1);

            if (itemName.equals(ChatColor.RED + "Cancelar") ||
                itemName.equals(ChatColor.YELLOW + "Menu Principal")) {
                plugin.getShopGUI().openMain(player); return;
            }
            if (itemName.startsWith(ChatColor.RED + "-")) {
                int sub = itemName.contains("10") ? 10 : 1;
                qty = Math.max(1, qty - sub);
                pendingQty.put(uuid, qty);
                plugin.getShopGUI().openSellConfirm(player, si, qty); return;
            }
            if (itemName.startsWith(ChatColor.GREEN + "+")) {
                int add = itemName.contains("10") ? 10 : 1;
                qty = Math.min(64, qty + add);
                pendingQty.put(uuid, qty);
                plugin.getShopGUI().openSellConfirm(player, si, qty); return;
            }
            if (itemName.equals(ChatColor.GREEN + "Confirmar Venda")) {
                executeSell(player, si, qty);
                plugin.getShopGUI().openCategory(player,
                        pendingCat.getOrDefault(uuid, si.getCategory()),
                        pendingPage.getOrDefault(uuid, 0));
            }
        }
    }

    // ─── Lógica de Compra ──────────────────────────────────────────────────────

    private void executeBuy(Player player, ShopItem si, int qty) {
        double total = si.getBuyPrice() * qty;

        if (!plugin.getEconomy().has(player, total)) {
            player.sendMessage(ChatColor.RED + "Saldo insuficiente! Precisa de "
                    + plugin.getEconomy().format(total));
            return;
        }

        plugin.getEconomy().withdraw(player, total);

        ItemStack item = new ItemStack(si.getMaterial(), qty);
        HashMap<Integer, ItemStack> overflow = player.getInventory().addItem(item);

        if (!overflow.isEmpty()) {
            // Devolve o dinheiro proporcional aos itens que não couberam
            int notFit = overflow.values().stream().mapToInt(ItemStack::getAmount).sum();
            int fit = qty - notFit;
            if (fit > 0) {
                double refund = si.getBuyPrice() * notFit;
                plugin.getEconomy().deposit(player, refund);
                player.sendMessage(ChatColor.YELLOW + "Inventario cheio! "
                        + notFit + " item(ns) nao coube(ram). "
                        + plugin.getEconomy().format(refund) + " devolvidos.");
            } else {
                plugin.getEconomy().deposit(player, total);
                player.sendMessage(ChatColor.RED + "Inventario cheio!");
                return;
            }
        }

        player.sendMessage(ChatColor.GREEN + "Comprado " + qty + "x " + si.getDisplayName()
                + " por " + plugin.getEconomy().format(total) + "!");
        player.sendMessage(ChatColor.GRAY + "Saldo: " + plugin.getEconomy().format(
                plugin.getEconomy().getBalance(player)));
    }

    // ─── Lógica de Venda ───────────────────────────────────────────────────────

    private void executeSell(Player player, ShopItem si, int qty) {
        if (si.getSellPrice() <= 0) {
            player.sendMessage(ChatColor.RED + "Este item nao pode ser vendido.");
            return;
        }

        // Verificar se tem os itens no inventário
        int has = countItem(player, si.getMaterial());
        if (has < qty) {
            player.sendMessage(ChatColor.RED + "Voce nao tem " + qty + "x "
                    + si.getDisplayName() + "! Tem apenas " + has + ".");
            return;
        }

        // Remover itens
        removeItem(player, si.getMaterial(), qty);

        double total = si.getSellPrice() * qty;
        plugin.getEconomy().deposit(player, total);

        player.sendMessage(ChatColor.GREEN + "Vendido " + qty + "x " + si.getDisplayName()
                + " por " + plugin.getEconomy().format(total) + "!");
        player.sendMessage(ChatColor.GRAY + "Saldo: " + plugin.getEconomy().format(
                plugin.getEconomy().getBalance(player)));
    }

    private int countItem(Player player, Material mat) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == mat) count += item.getAmount();
        }
        return count;
    }

    private void removeItem(Player player, Material mat, int qty) {
        int remaining = qty;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == mat) {
                if (item.getAmount() <= remaining) {
                    remaining -= item.getAmount();
                    contents[i] = null;
                } else {
                    item.setAmount(item.getAmount() - remaining);
                    remaining = 0;
                }
            }
        }
        player.getInventory().setContents(contents);
    }
}
