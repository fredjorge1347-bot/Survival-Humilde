package com.survivalhumilde.clans;

import com.survivalhumilde.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class ClanListener implements Listener {

    private final Main plugin;
    private final ClanManager manager;

    public ClanListener(Main plugin) {
        this.plugin = plugin;
        this.manager = plugin.getClanManager();
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        Clan deadClan = manager.getClanOfPlayer(dead.getUniqueId());
        if (deadClan != null) deadClan.addDeath();

        if (dead.getKiller() instanceof Player killer) {
            Clan killerClan = manager.getClanOfPlayer(killer.getUniqueId());
            if (killerClan != null) killerClan.addKill();
            manager.save();
        }
    }
}
