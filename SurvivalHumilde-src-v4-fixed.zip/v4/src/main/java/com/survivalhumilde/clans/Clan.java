package com.survivalhumilde.clans;

import java.util.*;

public class Clan {

    private final String tag;
    private String name;
    private UUID leader;
    private final Set<UUID> members = new HashSet<>();
    private final Set<UUID> officers = new HashSet<>();
    private int kills = 0;
    private int deaths = 0;
    private String description = "";

    public Clan(String tag, String name, UUID leader) {
        this.tag = tag.toUpperCase();
        this.name = name;
        this.leader = leader;
        this.members.add(leader);
    }

    public String getTag() { return tag; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public UUID getLeader() { return leader; }
    public void setLeader(UUID leader) { this.leader = leader; }
    public Set<UUID> getMembers() { return members; }
    public Set<UUID> getOfficers() { return officers; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getKills() { return kills; }
    public void addKill() { kills++; }
    public int getDeaths() { return deaths; }
    public void addDeath() { deaths++; }
    public int getSize() { return members.size(); }

    public boolean isMember(UUID uuid) { return members.contains(uuid); }
    public boolean isOfficer(UUID uuid) { return officers.contains(uuid); }
    public boolean isLeader(UUID uuid) { return leader.equals(uuid); }

    public void addMember(UUID uuid) { members.add(uuid); }
    public void removeMember(UUID uuid) {
        members.remove(uuid);
        officers.remove(uuid);
    }
    public void promoteOfficer(UUID uuid) { if (members.contains(uuid)) officers.add(uuid); }
    public void demoteOfficer(UUID uuid) { officers.remove(uuid); }

    public Map<String, Object> serialize() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("tag", tag);
        map.put("name", name);
        map.put("leader", leader.toString());
        map.put("description", description);
        map.put("kills", kills);
        map.put("deaths", deaths);
        List<String> memberList = new ArrayList<>();
        for (UUID u : members) memberList.add(u.toString());
        map.put("members", memberList);
        List<String> officerList = new ArrayList<>();
        for (UUID u : officers) officerList.add(u.toString());
        map.put("officers", officerList);
        return map;
    }

    @SuppressWarnings("unchecked")
    public static Clan deserialize(Map<String, Object> map) {
        String tag = (String) map.get("tag");
        String name = (String) map.get("name");
        UUID leader = UUID.fromString((String) map.get("leader"));
        Clan clan = new Clan(tag, name, leader);
        clan.description = (String) map.getOrDefault("description", "");
        clan.kills = (int) map.getOrDefault("kills", 0);
        clan.deaths = (int) map.getOrDefault("deaths", 0);
        clan.members.clear();
        for (String s : (List<String>) map.getOrDefault("members", new ArrayList<>())) {
            clan.members.add(UUID.fromString(s));
        }
        for (String s : (List<String>) map.getOrDefault("officers", new ArrayList<>())) {
            clan.officers.add(UUID.fromString(s));
        }
        return clan;
    }
}
