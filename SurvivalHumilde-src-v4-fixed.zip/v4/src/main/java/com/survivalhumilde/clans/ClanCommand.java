package com.survivalhumilde.clans;

import com.survivalhumilde.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class ClanCommand implements CommandExecutor {

    private final Main plugin;
    private final ClanManager manager;

    public ClanCommand(Main plugin) {
        this.plugin = plugin;
        this.manager = plugin.getClanManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "criar" -> cmdCriar(player, args);
            case "info" -> cmdInfo(player, args);
            case "convidar", "invite" -> cmdConvidar(player, args);
            case "aceitar", "accept" -> cmdAceitar(player, args);
            case "sair", "leave" -> cmdSair(player);
            case "disbandear", "disband" -> cmdDisband(player);
            case "expulsar", "kick" -> cmdExpulsar(player, args);
            case "promover", "promote" -> cmdPromover(player, args);
            case "rebaixar", "demote" -> cmdRebaixar(player, args);
            case "desc" -> cmdDesc(player, args);
            case "top" -> cmdTop(player);
            case "chat", "c" -> cmdChat(player, args);
            default -> sendHelp(player);
        }
        return true;
    }

    private void cmdCriar(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(C.ERR + "Uso: /cla criar <TAG> <Nome>");
            return;
        }
        String tag = args[1].toUpperCase();
        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        if (!tag.matches("[A-Za-z0-9]{2,5}")) {
            player.sendMessage(C.ERR + "Tag inválida! Use 2-5 letras/números.");
            return;
        }
        if (manager.isInClan(player.getUniqueId())) {
            player.sendMessage(C.ERR + "Você já está em um clã!");
            return;
        }
        if (manager.clanExists(tag)) {
            player.sendMessage(C.ERR + "Já existe um clã com essa tag!");
            return;
        }
        // Custo de criação
        double custo = plugin.getConfig().getDouble("clans.custo-criacao", 500);
        if (!plugin.getEconomy().has(player.getUniqueId(), custo)) {
            player.sendMessage(C.ERR + "Você precisa de " + C.fmt(custo) + " para criar um clã!");
            return;
        }
        plugin.getEconomy().withdraw(player.getUniqueId(), custo);
        manager.createClan(tag, name, player.getUniqueId());
        player.sendMessage(C.OK + "Clã §b[" + tag + "] §a" + name + " §acriado! Custo: §c" + C.fmt(custo));
    }

    private void cmdInfo(Player player, String[] args) {
        Clan clan;
        if (args.length >= 2) {
            clan = manager.getClan(args[1]);
        } else {
            clan = manager.getClanOfPlayer(player.getUniqueId());
        }
        if (clan == null) {
            player.sendMessage(C.ERR + "Clã não encontrado.");
            return;
        }
        player.sendMessage(C.LINE);
        player.sendMessage(C.GOLD + "  ⚔ Clã [" + clan.getTag() + "] " + clan.getName());
        player.sendMessage(C.GOLD + "  Líder: §f" + Bukkit.getOfflinePlayer(clan.getLeader()).getName());
        player.sendMessage(C.GOLD + "  Membros: §f" + clan.getSize());
        player.sendMessage(C.GOLD + "  K/D: §f" + clan.getKills() + "/" + clan.getDeaths());
        if (!clan.getDescription().isEmpty())
            player.sendMessage(C.GOLD + "  Desc: §f" + clan.getDescription());
        player.sendMessage(C.LINE);
    }

    private void cmdConvidar(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla convidar <jogador>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null) { player.sendMessage(C.ERR + "Você não está em um clã."); return; }
        if (!clan.isLeader(player.getUniqueId()) && !clan.isOfficer(player.getUniqueId())) {
            player.sendMessage(C.ERR + "Apenas líderes e oficiais podem convidar."); return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { player.sendMessage(C.ERR + "Jogador não encontrado."); return; }
        if (manager.isInClan(target.getUniqueId())) { player.sendMessage(C.ERR + target.getName() + " já está em um clã."); return; }
        manager.addInvite(target.getUniqueId(), clan.getTag());
        player.sendMessage(C.OK + "Convite enviado para §b" + target.getName());
        target.sendMessage(C.INFO + "§b" + player.getName() + " §7te convidou para o clã §b[" + clan.getTag() + "] §b" + clan.getName());
        target.sendMessage(C.INFO + "Use §b/cla aceitar " + clan.getTag() + " §7para entrar.");
    }

    private void cmdAceitar(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla aceitar <TAG>"); return; }
        if (!manager.hasInvite(player.getUniqueId(), args[1])) {
            player.sendMessage(C.ERR + "Você não tem convite para esse clã."); return;
        }
        manager.removeInvite(player.getUniqueId(), args[1]);
        if (!manager.joinClan(player.getUniqueId(), args[1])) {
            player.sendMessage(C.ERR + "Não foi possível entrar no clã."); return;
        }
        Clan clan = manager.getClan(args[1]);
        player.sendMessage(C.OK + "Você entrou no clã §b[" + clan.getTag() + "] §a" + clan.getName() + "!");
        broadcastClan(clan, C.INFO + "§b" + player.getName() + " §7entrou no clã!");
    }

    private void cmdSair(Player player) {
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null) { player.sendMessage(C.ERR + "Você não está em um clã."); return; }
        if (clan.isLeader(player.getUniqueId())) {
            player.sendMessage(C.ERR + "Líderes devem usar /cla disbandear para dissolver o clã.");
            return;
        }
        manager.leaveClan(player.getUniqueId());
        player.sendMessage(C.OK + "Você saiu do clã §b[" + clan.getTag() + "].");
        broadcastClan(clan, C.INFO + "§c" + player.getName() + " §7saiu do clã.");
    }

    private void cmdDisband(Player player) {
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null) { player.sendMessage(C.ERR + "Você não está em um clã."); return; }
        if (!clan.isLeader(player.getUniqueId())) { player.sendMessage(C.ERR + "Apenas o líder pode dissolver o clã."); return; }
        broadcastClan(clan, C.ERR + "O clã §b[" + clan.getTag() + "] §cfoi dissolvido pelo líder.");
        manager.disbandClan(clan.getTag());
    }

    private void cmdExpulsar(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla expulsar <jogador>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null || (!clan.isLeader(player.getUniqueId()) && !clan.isOfficer(player.getUniqueId()))) {
            player.sendMessage(C.ERR + "Sem permissão."); return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { player.sendMessage(C.ERR + "Jogador offline ou inválido."); return; }
        if (!clan.isMember(target.getUniqueId())) { player.sendMessage(C.ERR + target.getName() + " não está no clã."); return; }
        if (clan.isLeader(target.getUniqueId())) { player.sendMessage(C.ERR + "Não pode expulsar o líder."); return; }
        clan.removeMember(target.getUniqueId());
        manager.save();
        target.sendMessage(C.ERR + "Você foi expulso do clã §b[" + clan.getTag() + "].");
        player.sendMessage(C.OK + target.getName() + " foi expulso.");
    }

    private void cmdPromover(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla promover <jogador>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null || !clan.isLeader(player.getUniqueId())) { player.sendMessage(C.ERR + "Apenas o líder pode promover."); return; }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null || !clan.isMember(target.getUniqueId())) { player.sendMessage(C.ERR + "Membro inválido."); return; }
        clan.promoteOfficer(target.getUniqueId());
        manager.save();
        player.sendMessage(C.OK + target.getName() + " é agora Oficial do clã.");
        target.sendMessage(C.INFO + "Você foi promovido a §6Oficial §7do clã §b[" + clan.getTag() + "]!");
    }

    private void cmdRebaixar(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla rebaixar <jogador>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null || !clan.isLeader(player.getUniqueId())) { player.sendMessage(C.ERR + "Sem permissão."); return; }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null || !clan.isMember(target.getUniqueId())) { player.sendMessage(C.ERR + "Membro inválido."); return; }
        clan.demoteOfficer(target.getUniqueId());
        manager.save();
        player.sendMessage(C.OK + target.getName() + " foi rebaixado.");
    }

    private void cmdDesc(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla desc <descrição>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null || !clan.isLeader(player.getUniqueId())) { player.sendMessage(C.ERR + "Apenas líderes."); return; }
        String desc = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        clan.setDescription(desc);
        manager.save();
        player.sendMessage(C.OK + "Descrição atualizada.");
    }

    private void cmdTop(Player player) {
        player.sendMessage(C.LINE);
        player.sendMessage(C.GOLD + "  🏆 Top 5 Clãs (por Kills)");
        manager.getAllClans().stream()
                .sorted((a, b) -> b.getKills() - a.getKills())
                .limit(5)
                .forEach(c -> player.sendMessage(C.GOLD + "  [" + c.getTag() + "] §f" + c.getName() + " §7- §cK:§f" + c.getKills()));
        player.sendMessage(C.LINE);
    }

    private void cmdChat(Player player, String[] args) {
        if (args.length < 2) { player.sendMessage(C.ERR + "Uso: /cla chat <mensagem>"); return; }
        Clan clan = manager.getClanOfPlayer(player.getUniqueId());
        if (clan == null) { player.sendMessage(C.ERR + "Você não está em um clã."); return; }
        String msg = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        broadcastClan(clan, "§6[CLÃ] §b[" + clan.getTag() + "] §f" + player.getName() + ": §7" + msg);
    }

    private void broadcastClan(Clan clan, String message) {
        for (UUID uuid : clan.getMembers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(message);
        }
    }

    private void sendHelp(Player player) {
        player.sendMessage(C.LINE);
        player.sendMessage(C.GOLD + "  ⚔ Comandos de Clã");
        player.sendMessage(C.GOLD + "  /cla criar <TAG> <Nome> §7- Criar clã");
        player.sendMessage(C.GOLD + "  /cla info [TAG] §7- Ver info do clã");
        player.sendMessage(C.GOLD + "  /cla convidar <jogador> §7- Convidar");
        player.sendMessage(C.GOLD + "  /cla aceitar <TAG> §7- Aceitar convite");
        player.sendMessage(C.GOLD + "  /cla sair §7- Sair do clã");
        player.sendMessage(C.GOLD + "  /cla chat <msg> §7- Chat do clã");
        player.sendMessage(C.GOLD + "  /cla top §7- Ranking de clãs");
        player.sendMessage(C.GOLD + "  /cla disbandear §7- Dissolver clã");
        player.sendMessage(C.LINE);
    }

    // Classe de utilidade para cores
    static class C {
        static final String OK   = ChatColor.GREEN + "" + ChatColor.BOLD + "✔ " + ChatColor.GREEN;
        static final String ERR  = ChatColor.RED + "" + ChatColor.BOLD + "✖ " + ChatColor.RED;
        static final String INFO = ChatColor.AQUA + "" + ChatColor.BOLD + "ℹ " + ChatColor.AQUA;
        static final String GOLD = ChatColor.GOLD.toString();
        static final String LINE = ChatColor.DARK_GRAY + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
        static String fmt(double v) { return String.format("%.0f", v) + " moedas"; }
    }
}
