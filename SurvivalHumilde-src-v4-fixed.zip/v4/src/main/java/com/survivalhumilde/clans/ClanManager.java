package com.survivalhumilde.clans;

import com.survivalhumilde.Main;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ClanManager {

    private final Main plugin;
    private final Map<String, Clan> clansByTag = new HashMap<>();       // tag -> clan
    private final Map<UUID, String> playerClan = new HashMap<>();       // player -> tag
    private final Set<String> pendingInvites = new HashSet<>();          // "playerUUID:clanTag"
    private File dataFile;
    private FileConfiguration dataConfig;

    public ClanManager(Main plugin) {
        this.plugin = plugin;
        load();
    }

    // ---- CRUD ----

    public boolean clanExists(String tag) {
        return clansByTag.containsKey(tag.toUpperCase());
    }

    public Clan getClan(String tag) {
        return clansByTag.get(tag.toUpperCase());
    }

    public Clan getClanOfPlayer(UUID uuid) {
        String tag = playerClan.get(uuid);
        return tag == null ? null : clansByTag.get(tag);
    }

    public boolean isInClan(UUID uuid) {
        return playerClan.containsKey(uuid);
    }

    public Collection<Clan> getAllClans() {
        return clansByTag.values();
    }

    public boolean createClan(String tag, String name, UUID leader) {
        if (tag.length() < 2 || tag.length() > 5) return false;
        if (clanExists(tag)) return false;
        if (isInClan(leader)) return false;
        Clan clan = new Clan(tag, name, leader);
        clansByTag.put(tag.toUpperCase(), clan);
        playerClan.put(leader, tag.toUpperCase());
        save();
        return true;
    }

    public boolean disbandClan(String tag) {
        Clan clan = getClan(tag);
        if (clan == null) return false;
        for (UUID m : clan.getMembers()) {
            playerClan.remove(m);
        }
        clansByTag.remove(tag.toUpperCase());
        save();
        return true;
    }

    public boolean joinClan(UUID player, String tag) {
        Clan clan = getClan(tag);
        if (clan == null) return false;
        if (isInClan(player)) return false;
        clan.addMember(player);
        playerClan.put(player, tag.toUpperCase());
        save();
        return true;
    }

    public boolean leaveClan(UUID player) {
        Clan clan = getClanOfPlayer(player);
        if (clan == null) return false;
        if (clan.isLeader(player)) return false; // Líder deve disbandear
        clan.removeMember(player);
        playerClan.remove(player);
        save();
        return true;
    }

    // ---- CONVITES ----

    public void addInvite(UUID player, String tag) {
        pendingInvites.add(player + ":" + tag.toUpperCase());
    }

    public boolean hasInvite(UUID player, String tag) {
        return pendingInvites.contains(player + ":" + tag.toUpperCase());
    }

    public void removeInvite(UUID player, String tag) {
        pendingInvites.remove(player + ":" + tag.toUpperCase());
    }

    // ---- PERSISTÊNCIA ----

    private void load() {
        dataFile = new File(plugin.getDataFolder(), "clans.yml");
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection section = dataConfig.getConfigurationSection("clans");
        if (section == null) return;
        for (String tag : section.getKeys(false)) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) section.get(tag);
            if (map != null) {
                Clan clan = Clan.deserialize(map);
                clansByTag.put(tag.toUpperCase(), clan);
                for (UUID m : clan.getMembers()) {
                    playerClan.put(m, tag.toUpperCase());
                }
            }
        }
    }

    public void save() {
        dataConfig.set("clans", null);
        for (Map.Entry<String, Clan> entry : clansByTag.entrySet()) {
            dataConfig.set("clans." + entry.getKey(), entry.getValue().serialize());
        }
        try { dataConfig.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }
}
