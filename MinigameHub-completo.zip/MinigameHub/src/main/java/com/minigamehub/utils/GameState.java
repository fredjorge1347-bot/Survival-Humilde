package com.minigamehub.utils;

public enum GameState {
    WAITING,      // Aguardando jogadores
    COUNTDOWN,    // Contagem regressiva
    IN_GAME,      // Em jogo
    ENDING,       // Finalizando (mostrando vencedor)
    RESETTING     // Resetando o mapa
}
