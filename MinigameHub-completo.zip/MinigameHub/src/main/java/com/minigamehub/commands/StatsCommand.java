package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class StatsCommand implements CommandExecutor {
    private final MinigameHub plugin;
    public StatsCommand(MinigameHub plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player target;
        if (args.length > 0) {
            target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ChatUtils.color("&cJogador não encontrado: " + args[0]));
                return true;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            sender.sendMessage("Especifique um jogador: /stats <jogador>");
            return true;
        }

        sender.sendMessage(ChatUtils.color("&6&l━━━━━ Estatísticas: &e" + target.getName() + " &6&l━━━━━"));
        sender.sendMessage(ChatUtils.color("&7"));
        for (String gameId : new String[]{"oneblock", "bedwars", "skywars"}) {
            String gameName = plugin.getConfig().getString("minigames." + gameId + ".display-name", gameId);
            int wins = plugin.getStatsManager().getWins(target, gameId);
            int games = plugin.getStatsManager().getGames(target, gameId);
            double ratio = games > 0 ? (double) wins / games * 100 : 0;
            sender.sendMessage(ChatUtils.color(
                ChatUtils.color(gameName) + "&7: &a" + wins + " vitórias &7| &f" + games + " partidas &7| &e" + String.format("%.0f", ratio) + "% W/R"
            ));
        }
        sender.sendMessage(ChatUtils.color("&7"));
        sender.sendMessage(ChatUtils.color("&7Total: &a" + plugin.getStatsManager().getTotalWins(target)
                + " vitórias &7em &f" + plugin.getStatsManager().getTotalGames(target) + " partidas"));
        sender.sendMessage(ChatUtils.color("&6&l━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        return true;
    }
}
