package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetMinigameCommand implements CommandExecutor {
    private final MinigameHub plugin;
    public SetMinigameCommand(MinigameHub plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("minigamehub.admin")) {
            sender.sendMessage(ChatUtils.color("&cSem permissão!"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(ChatUtils.color("&cUso: /setminigame <oneblock|bedwars|skywars>"));
            return true;
        }
        String gameId = args[0].toLowerCase();
        if (plugin.getGameManager().getGame(gameId) == null) {
            sender.sendMessage(ChatUtils.color("&cMinigame não encontrado: " + gameId));
            return true;
        }
        sender.sendMessage(ChatUtils.color("&aMinigame &e" + gameId + " &aselecionado! Use /startgame para iniciar manualmente."));
        return true;
    }
}
