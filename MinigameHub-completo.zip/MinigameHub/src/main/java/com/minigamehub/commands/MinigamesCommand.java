package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class MinigamesCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public MinigamesCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatUtils.color("&cApenas jogadores!"));
            return true;
        }
        openMinigameMenu((Player) sender);
        return true;
    }

    public void openMinigameMenu(Player player) {
        // 54 slots = 6 linhas — suficiente para todos os 8 minigames
        Inventory inv = plugin.getServer().createInventory(null, 54,
                ChatUtils.color("&6&l✦ Minigames ✦"));

        // Linha 1 — Minigames originais
        inv.setItem(10, createMenuItem(Material.GRASS_BLOCK, "&b&lOne Block",
                "&7Quebre o bloco mágico e sobreviva!",
                plugin.getGameManager().getGame("oneblock")));

        inv.setItem(13, createMenuItem(Material.RED_BED, "&c&lBed Wars",
                "&7Destrua a cama inimiga e elimine todos!",
                plugin.getGameManager().getGame("bedwars")));

        inv.setItem(16, createMenuItem(Material.FEATHER, "&e&lSky Wars",
                "&7Lute nas ilhas do céu! Último sobrevivente vence!",
                plugin.getGameManager().getGame("skywars")));

        // Linha 2 — Novos minigames (Murder Mystery, Hide & Seek, Prop Hunt)
        inv.setItem(28, createMenuItem(Material.IRON_SWORD, "&c&lMurder Mystery",
                "&7Assassino, detetive e inocentes. Descubra quem é o assassino!",
                plugin.getGameManager().getGame("murdermystery")));

        inv.setItem(31, createMenuItem(Material.SLIME_BALL, "&a&lEsconde-esconde",
                "&7Transforme-se em bloco e se esconda do caçador!",
                plugin.getGameManager().getGame("hideandseek")));

        inv.setItem(34, createMenuItem(Material.ENDER_EYE, "&b&lProp Hunt",
                "&7Disfarce-se de objeto e fuja dos caçadores!",
                plugin.getGameManager().getGame("prophunt")));

        // Linha 3 — Prison Escape, Guess The Build
        inv.setItem(39, createMenuItem(Material.IRON_BARS, "&7&lPrison Escape",
                "&7Prisioneiros fogem enquanto guardas patrulham!",
                plugin.getGameManager().getGame("prisonescape")));

        inv.setItem(42, createMenuItem(Material.BRICKS, "&6&lGuess The Build",
                "&7Adivinhe o que os outros estão construindo!",
                plugin.getGameManager().getGame("guessthebuild")));

        // Botão de estatísticas
        ItemStack stats = new ItemStack(Material.BOOK);
        ItemMeta statsMeta = stats.getItemMeta();
        if (statsMeta != null) {
            statsMeta.setDisplayName(ChatUtils.color("&a&lSuas Estatísticas"));
            List<String> lore = new ArrayList<>();
            lore.add(ChatUtils.color("&7Vitórias totais: &a" + plugin.getStatsManager().getTotalWins(player)));
            lore.add(ChatUtils.color("&7Partidas totais: &f" + plugin.getStatsManager().getTotalGames(player)));
            lore.add("");
            lore.add(ChatUtils.color("&8Use /stats para detalhes"));
            statsMeta.setLore(lore);
            stats.setItemMeta(statsMeta);
        }
        inv.setItem(49, stats);

        // Decoração de borda
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) { glassMeta.setDisplayName(" "); glass.setItemMeta(glassMeta); }
        for (int i = 0; i < 54; i++) {
            if (inv.getItem(i) == null) inv.setItem(i, glass);
        }

        player.openInventory(inv);
    }

    private ItemStack createMenuItem(Material mat, String name, String desc, MiniGame game) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(ChatUtils.color(name));
        List<String> lore = new ArrayList<>();
        lore.add(ChatUtils.color("&7" + desc.replaceAll("&[a-f0-9]", "")));
        lore.add("");

        if (game != null) {
            String stateStr;
            switch (game.getState()) {
                case WAITING:   stateStr = "&aAguardando jogadores"; break;
                case COUNTDOWN: stateStr = "&eIniciando em breve..."; break;
                case IN_GAME:   stateStr = "&cEm andamento";         break;
                default:        stateStr = "&8Indisponível";          break;
            }
            lore.add(ChatUtils.color("&7Status: " + stateStr));
            lore.add(ChatUtils.color("&7Jogadores: &f" + game.getPlayers().size() + "&7/&f" + game.getMaxPlayers()));
            lore.add(ChatUtils.color("&7Mínimo: &f" + game.getMinPlayers() + " jogadores"));
            lore.add("");
            lore.add(ChatUtils.color("&e▶ Clique para entrar!"));
        } else {
            lore.add(ChatUtils.color("&cMinigame desativado"));
        }

        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
