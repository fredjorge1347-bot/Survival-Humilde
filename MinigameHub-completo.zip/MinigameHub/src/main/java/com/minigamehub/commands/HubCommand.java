package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class HubCommand implements CommandExecutor {
    private final MinigameHub plugin;
    public HubCommand(MinigameHub plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatUtils.color("&cApenas jogadores!"));
            return true;
        }
        Player player = (Player) sender;
        plugin.getGameManager().leaveGame(player);
        plugin.getLobbyManager().sendToHub(player);
        return true;
    }
}
