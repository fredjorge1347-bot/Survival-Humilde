package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.command.*;

public class StartGameCommand implements CommandExecutor {
    private final MinigameHub plugin;
    public StartGameCommand(MinigameHub plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("minigamehub.admin")) {
            sender.sendMessage(ChatUtils.color("&cSem permissão!"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(ChatUtils.color("&cUso: /startgame <oneblock|bedwars|skywars>"));
            return true;
        }
        String gameId = args[0].toLowerCase();
        if (plugin.getGameManager().forceStart(gameId)) {
            sender.sendMessage(ChatUtils.color("&aJogo &e" + gameId + " &ainiciadomanualmente!"));
        } else {
            sender.sendMessage(ChatUtils.color("&cNão foi possível iniciar. Verifique se há jogadores na fila."));
        }
        return true;
    }
}
