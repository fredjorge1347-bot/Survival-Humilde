package com.minigamehub.commands;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetHubCommand implements CommandExecutor {
    private final MinigameHub plugin;
    public SetHubCommand(MinigameHub plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("Apenas jogadores!"); return true; }
        if (!sender.hasPermission("minigamehub.admin")) {
            ChatUtils.sendMessage((Player) sender, "&cSem permissão!");
            return true;
        }
        Player player = (Player) sender;
        plugin.getLobbyManager().setHubSpawn(player.getLocation());
        ChatUtils.sendMessage(player, "&aSpawn do hub definido na sua posição atual!");
        return true;
    }
}
