package com.minigamehub.managers;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class LobbyManager {

    private final MinigameHub plugin;
    private Location hubSpawn;

    public LobbyManager(MinigameHub plugin) {
        this.plugin = plugin;
        loadHubSpawn();
    }

    private void loadHubSpawn() {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("hub.spawn");
        if (sec == null) {
            hubSpawn = null;
            return;
        }
        String worldName = sec.getString("world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);

        hubSpawn = new Location(world,
                sec.getDouble("x", 0.5),
                sec.getDouble("y", 64),
                sec.getDouble("z", 0.5),
                (float) sec.getDouble("yaw", 0),
                (float) sec.getDouble("pitch", 0));
    }

    public void sendToHub(Player player) {
        if (hubSpawn == null) loadHubSpawn();

        Location spawn = hubSpawn != null ? hubSpawn : player.getWorld().getSpawnLocation();
        player.teleport(spawn);
        player.setGameMode(GameMode.ADVENTURE);
        player.getInventory().clear();
        player.setHealth(20);
        player.setFoodLevel(20);
        player.setExp(0);
        player.setLevel(0);

        // Remover efeitos de poção
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

        ChatUtils.sendMessage(player, plugin.getConfig().getString("messages.prefix", "&8[&6Hub&8] ")
                + "&aVocê voltou ao lobby!");
        plugin.getScoreboardManager().showLobbyScoreboard(player);
    }

    public void applyLobbySettings(Player player) {
        player.setGameMode(GameMode.ADVENTURE);
        player.setAllowFlight(false);
        player.setFlying(false);
    }

    public void setHubSpawn(Location location) {
        this.hubSpawn = location;
        plugin.getConfig().set("hub.spawn.world", location.getWorld().getName());
        plugin.getConfig().set("hub.spawn.x", location.getX());
        plugin.getConfig().set("hub.spawn.y", location.getY());
        plugin.getConfig().set("hub.spawn.z", location.getZ());
        plugin.getConfig().set("hub.spawn.yaw", location.getYaw());
        plugin.getConfig().set("hub.spawn.pitch", location.getPitch());
        plugin.saveConfig();
    }

    public Location getHubSpawn() { return hubSpawn; }

    public boolean isInHub(Player player) {
        if (hubSpawn == null) return false;
        return player.getWorld().equals(hubSpawn.getWorld())
                && !plugin.getGameManager().isInGame(player);
    }
}
