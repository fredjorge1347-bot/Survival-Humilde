package com.minigamehub.managers;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.minigames.bedwars.BedWarsGame;
import com.minigamehub.minigames.guessthebuild.GuessBuildGame;
import com.minigamehub.minigames.hideandseek.HideAndSeekGame;
import com.minigamehub.minigames.murdermystery.MurderMysteryGame;
import com.minigamehub.minigames.oneblock.OneBlockGame;
import com.minigamehub.minigames.prisonescape.PrisonEscapeGame;
import com.minigamehub.minigames.prophunt.PropHuntGame;
import com.minigamehub.minigames.skywars.SkyWarsGame;
import com.minigamehub.utils.GameState;
import org.bukkit.entity.Player;

import java.util.*;

public class GameManager {

    private final MinigameHub plugin;
    private final Map<String, MiniGame> games = new LinkedHashMap<>();

    public GameManager(MinigameHub plugin) {
        this.plugin = plugin;
        registerGames();
    }

    private void registerGames() {
        if (plugin.getConfig().getBoolean("minigames.oneblock.enabled", true)) {
            games.put("oneblock", new OneBlockGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.bedwars.enabled", true)) {
            games.put("bedwars", new BedWarsGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.skywars.enabled", true)) {
            games.put("skywars", new SkyWarsGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.murdermystery.enabled", true)) {
            games.put("murdermystery", new MurderMysteryGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.hideandseek.enabled", true)) {
            games.put("hideandseek", new HideAndSeekGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.prophunt.enabled", true)) {
            games.put("prophunt", new PropHuntGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.prisonescape.enabled", true)) {
            games.put("prisonescape", new PrisonEscapeGame(plugin));
        }
        if (plugin.getConfig().getBoolean("minigames.guessthebuild.enabled", true)) {
            games.put("guessthebuild", new GuessBuildGame(plugin));
        }
        plugin.getLogger().info("Minigames carregados: " + games.keySet());
    }

    public boolean joinGame(Player player, String gameId) {
        MiniGame current = getGameByPlayer(player);
        if (current != null) {
            current.removePlayer(player);
        }
        MiniGame game = games.get(gameId.toLowerCase());
        if (game == null) return false;
        if (!game.isEnabled()) return false;
        return game.addPlayer(player);
    }

    public void leaveGame(Player player) {
        MiniGame game = getGameByPlayer(player);
        if (game != null) {
            game.removePlayer(player);
        }
    }

    public MiniGame getGameByPlayer(Player player) {
        for (MiniGame game : games.values()) {
            if (game.getPlayers().contains(player)) return game;
        }
        return null;
    }

    public boolean isInGame(Player player) {
        return getGameByPlayer(player) != null;
    }

    public MiniGame getGame(String id) {
        return games.get(id.toLowerCase());
    }

    public Collection<MiniGame> getAllGames() {
        return Collections.unmodifiableCollection(games.values());
    }

    public void shutdownAll() {
        for (MiniGame game : games.values()) {
            game.shutdown();
        }
    }

    public Map<String, Object> getGameStatus(String gameId) {
        MiniGame game = games.get(gameId);
        if (game == null) return null;
        Map<String, Object> status = new LinkedHashMap<>();
        status.put("name", game.getDisplayName());
        status.put("state", game.getState().name());
        status.put("players", game.getPlayers().size());
        status.put("maxPlayers", game.getMaxPlayers());
        return status;
    }

    public boolean forceStart(String gameId) {
        MiniGame game = games.get(gameId.toLowerCase());
        if (game == null) return false;
        if (game.getState() == GameState.WAITING || game.getState() == GameState.COUNTDOWN) {
            if (!game.getPlayers().isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
