package com.minigamehub.managers;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.List;

public class ScoreboardManager {

    private final MinigameHub plugin;

    public ScoreboardManager(MinigameHub plugin) {
        this.plugin = plugin;
        // Atualizar scoreboards a cada 2 segundos
        Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 40L, 40L);
    }

    public void showLobbyScoreboard(Player player) {
        org.bukkit.scoreboard.ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;

        Scoreboard board = manager.getNewScoreboard();
        Objective obj = board.registerNewObjective("hub", Criteria.DUMMY,
                ChatUtils.color("&6&lMINIGAME HUB"));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        int score = 14;
        obj.getScore(ChatUtils.color("&8─────────────")).setScore(score--);
        obj.getScore(ChatUtils.color("&eJogadores: &f" + Bukkit.getOnlinePlayers().size())).setScore(score--);
        obj.getScore(ChatUtils.color(" ")).setScore(score--);

        // Status dos minigames
        for (MiniGame game : plugin.getGameManager().getAllGames()) {
            String state = getStateDisplay(game);
            obj.getScore(ChatUtils.color(game.getDisplayName() + " " + state)).setScore(score--);
        }

        obj.getScore(ChatUtils.color("  ")).setScore(score--);
        obj.getScore(ChatUtils.color("&7Vitórias: &a" + plugin.getStatsManager().getTotalWins(player))).setScore(score--);
        obj.getScore(ChatUtils.color("&7Partidas: &f" + plugin.getStatsManager().getTotalGames(player))).setScore(score--);
        obj.getScore(ChatUtils.color("&8─────────────")).setScore(score--);
        obj.getScore(ChatUtils.color("&b/minigames &7para jogar")).setScore(score--);

        player.setScoreboard(board);
    }

    public void showGameScoreboard(Player player, MiniGame game) {
        org.bukkit.scoreboard.ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;

        Scoreboard board = manager.getNewScoreboard();
        Objective obj = board.registerNewObjective("game", Criteria.DUMMY,
                ChatUtils.color(game.getScoreboardTitle()));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        int score = 14;
        obj.getScore(ChatUtils.color("&8─────────────")).setScore(score--);
        List<String> lines = game.getScoreboardLines(player);
        for (String line : lines) {
            obj.getScore(ChatUtils.color(line)).setScore(score--);
            if (score < 0) break;
        }
        obj.getScore(ChatUtils.color("&8─────────────")).setScore(Math.max(score, 0));

        player.setScoreboard(board);
    }

    private void updateAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            MiniGame game = plugin.getGameManager().getGameByPlayer(player);
            if (game != null) {
                showGameScoreboard(player, game);
            } else if (plugin.getLobbyManager().isInHub(player)) {
                showLobbyScoreboard(player);
            }
        }
    }

    private String getStateDisplay(MiniGame game) {
        switch (game.getState()) {
            case WAITING: return "&7[" + game.getPlayers().size() + "/" + game.getMaxPlayers() + "]";
            case COUNTDOWN: return "&e[Iniciando...]";
            case IN_GAME: return "&c[Em jogo]";
            case ENDING: return "&6[Finalizando]";
            default: return "&8[Off]";
        }
    }
}
