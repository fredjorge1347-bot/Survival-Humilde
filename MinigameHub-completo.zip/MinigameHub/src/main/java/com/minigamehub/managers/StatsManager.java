package com.minigamehub.managers;

import com.minigamehub.main.MinigameHub;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StatsManager {

    private final MinigameHub plugin;
    private File statsFile;
    private FileConfiguration statsConfig;

    // Cache de stats em memória
    private final Map<UUID, Map<String, Integer>> winsCache = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> gamesCache = new HashMap<>();

    public StatsManager(MinigameHub plugin) {
        this.plugin = plugin;
        setupFile();
        loadAll();
    }

    private void setupFile() {
        statsFile = new File(plugin.getDataFolder(), "stats.yml");
        if (!statsFile.exists()) {
            statsFile.getParentFile().mkdirs();
            try { statsFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        statsConfig = YamlConfiguration.loadConfiguration(statsFile);
    }

    private void loadAll() {
        for (String uuidStr : statsConfig.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                Map<String, Integer> wins = new HashMap<>();
                Map<String, Integer> games = new HashMap<>();

                for (String game : new String[]{"oneblock", "bedwars", "skywars"}) {
                    wins.put(game, statsConfig.getInt(uuidStr + "." + game + ".wins", 0));
                    games.put(game, statsConfig.getInt(uuidStr + "." + game + ".games", 0));
                }
                winsCache.put(uuid, wins);
                gamesCache.put(uuid, games);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveAll() {
        for (Map.Entry<UUID, Map<String, Integer>> entry : winsCache.entrySet()) {
            String uuid = entry.getKey().toString();
            for (Map.Entry<String, Integer> win : entry.getValue().entrySet()) {
                statsConfig.set(uuid + "." + win.getKey() + ".wins", win.getValue());
            }
        }
        for (Map.Entry<UUID, Map<String, Integer>> entry : gamesCache.entrySet()) {
            String uuid = entry.getKey().toString();
            for (Map.Entry<String, Integer> game : entry.getValue().entrySet()) {
                statsConfig.set(uuid + "." + game.getKey() + ".games", game.getValue());
            }
        }
        try { statsConfig.save(statsFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public void addWin(Player player, String gameId) {
        UUID uuid = player.getUniqueId();
        winsCache.computeIfAbsent(uuid, k -> new HashMap<>())
                .merge(gameId, 1, Integer::sum);
    }

    public void addGame(Player player, String gameId) {
        UUID uuid = player.getUniqueId();
        gamesCache.computeIfAbsent(uuid, k -> new HashMap<>())
                .merge(gameId, 1, Integer::sum);
    }

    public int getWins(Player player, String gameId) {
        return winsCache.getOrDefault(player.getUniqueId(), new HashMap<>())
                .getOrDefault(gameId, 0);
    }

    public int getGames(Player player, String gameId) {
        return gamesCache.getOrDefault(player.getUniqueId(), new HashMap<>())
                .getOrDefault(gameId, 0);
    }

    public int getTotalWins(Player player) {
        return winsCache.getOrDefault(player.getUniqueId(), new HashMap<>())
                .values().stream().mapToInt(Integer::intValue).sum();
    }

    public int getTotalGames(Player player) {
        return gamesCache.getOrDefault(player.getUniqueId(), new HashMap<>())
                .values().stream().mapToInt(Integer::intValue).sum();
    }
}
