package com.minigamehub.main;

import com.minigamehub.commands.*;
import com.minigamehub.listeners.*;
import com.minigamehub.managers.*;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.plugin.java.JavaPlugin;

public class MinigameHub extends JavaPlugin {

    private static MinigameHub instance;
    private GameManager gameManager;
    private LobbyManager lobbyManager;
    private StatsManager statsManager;
    private ScoreboardManager scoreboardManager;

    @Override
    public void onEnable() {
        instance = this;

        // Salvar config padrão
        saveDefaultConfig();

        // Inicializar managers
        this.statsManager = new StatsManager(this);
        this.lobbyManager = new LobbyManager(this);
        this.gameManager = new GameManager(this);
        this.scoreboardManager = new ScoreboardManager(this);

        // Registrar comandos
        registerCommands();

        // Registrar listeners
        registerListeners();

        getLogger().info(ChatUtils.color("&a&l========================================"));
        getLogger().info(ChatUtils.color("&6&l  MinigameHub &av1.0.0 carregado!"));
        getLogger().info(ChatUtils.color("&a  Minigames: OneBlock, BedWars, SkyWars"));
        getLogger().info(ChatUtils.color("&a&l========================================"));
    }

    @Override
    public void onDisable() {
        // Encerrar todos os jogos ativos
        if (gameManager != null) {
            gameManager.shutdownAll();
        }
        // Salvar estatísticas
        if (statsManager != null) {
            statsManager.saveAll();
        }
        getLogger().info("MinigameHub desativado. Até logo!");
    }

    private void registerCommands() {
        getCommand("hub").setExecutor(new HubCommand(this));
        getCommand("minigames").setExecutor(new MinigamesCommand(this));
        getCommand("sethub").setExecutor(new SetHubCommand(this));
        getCommand("setminigame").setExecutor(new SetMinigameCommand(this));
        getCommand("startgame").setExecutor(new StartGameCommand(this));
        getCommand("stats").setExecutor(new StatsCommand(this));
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        getServer().getPluginManager().registerEvents(new LobbyListener(this), this);
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
    }

    public static MinigameHub getInstance() { return instance; }
    public GameManager getGameManager() { return gameManager; }
    public LobbyManager getLobbyManager() { return lobbyManager; }
    public StatsManager getStatsManager() { return statsManager; }
    public ScoreboardManager getScoreboardManager() { return scoreboardManager; }
}
