package com.minigamehub.listeners;

import com.minigamehub.main.MinigameHub;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.Player;

public class PlayerQuitListener implements Listener {
    private final MinigameHub plugin;
    public PlayerQuitListener(MinigameHub plugin) { this.plugin = plugin; }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        event.setQuitMessage(null);
        // Sair do jogo se estiver em um
        plugin.getGameManager().leaveGame(player);
        // Salvar stats
        plugin.getStatsManager().saveAll();
    }
}
