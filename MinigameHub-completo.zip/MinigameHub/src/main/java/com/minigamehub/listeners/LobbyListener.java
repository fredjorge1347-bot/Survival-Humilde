package com.minigamehub.listeners;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.GameMode;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.Player;

public class LobbyListener implements Listener {
    private final MinigameHub plugin;
    public LobbyListener(MinigameHub plugin) { this.plugin = plugin; }

    // No lobby: sem dano PvP
    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player victim = (Player) event.getEntity();
        if (plugin.getLobbyManager().isInHub(victim) && !plugin.getGameManager().isInGame(victim)) {
            event.setCancelled(true);
        }
    }

    // No lobby: sem queda de itens
    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (plugin.getLobbyManager().isInHub(player) && !plugin.getGameManager().isInGame(player)) {
            event.setCancelled(true);
        }
    }

    // No lobby: sem quebrar blocos
    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.ADVENTURE) {
            if (!plugin.getGameManager().isInGame(player)) {
                event.setCancelled(true);
            }
        }
    }

    // No lobby: sem colocar blocos
    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.ADVENTURE) {
            if (!plugin.getGameManager().isInGame(player)) {
                event.setCancelled(true);
            }
        }
    }

    // Sem fome no lobby
    @EventHandler
    public void onFoodLevel(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        if (plugin.getLobbyManager().isInHub(player) && !plugin.getGameManager().isInGame(player)) {
            event.setCancelled(true);
        }
    }

    // Item de bússola no lobby — abre menu de minigames ao clicar
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (plugin.getLobbyManager().isInHub(player) && !plugin.getGameManager().isInGame(player)) {
            if (player.getInventory().getItemInMainHand().getType() == org.bukkit.Material.COMPASS) {
                event.setCancelled(true);
                plugin.getServer().dispatchCommand(player, "minigames");
            }
        }
    }
}
