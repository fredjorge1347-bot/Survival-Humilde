package com.minigamehub.listeners;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.Player;

public class PlayerJoinListener implements Listener {
    private final MinigameHub plugin;
    public PlayerJoinListener(MinigameHub plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        event.setJoinMessage(ChatUtils.color("&a+ &7" + player.getName() + " &aentrou no servidor!"));

        // Teleportar ao hub e configurar lobby
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getLobbyManager().sendToHub(player);
            String welcomeMsg = plugin.getConfig().getString("hub.welcome-message", "&aBoasvindas!");
            String title = plugin.getConfig().getString("hub.title", "&6HUB");
            String subtitle = plugin.getConfig().getString("hub.subtitle", "");
            ChatUtils.sendMessage(player, welcomeMsg);
            ChatUtils.sendTitle(player, title, subtitle, 10, 60, 10);
        }, 5L);
    }
}
