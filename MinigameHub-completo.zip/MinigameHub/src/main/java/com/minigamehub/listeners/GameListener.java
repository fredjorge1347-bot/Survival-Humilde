package com.minigamehub.listeners;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.Player;

public class GameListener implements Listener {
    private final MinigameHub plugin;
    public GameListener(MinigameHub plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        MiniGame game = plugin.getGameManager().getGameByPlayer(player);
        if (game != null) {
            game.onPlayerDeath(player);
        }
    }
}
