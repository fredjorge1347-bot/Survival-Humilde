package com.minigamehub.listeners;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.ItemStack;

public class MenuListener implements Listener {
    private final MinigameHub plugin;
    public MenuListener(MinigameHub plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String title = event.getView().getTitle();
        if (!title.equals(ChatUtils.color("&6&l✦ Minigames ✦"))) return;

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        if (clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;
        if (clicked.getType() == Material.BOOK) return;

        String gameId = null;
        switch (clicked.getType()) {
            // Minigames originais
            case GRASS_BLOCK: gameId = "oneblock";       break;
            case RED_BED:     gameId = "bedwars";        break;
            case FEATHER:     gameId = "skywars";        break;
            // Novos minigames
            case IRON_SWORD:  gameId = "murdermystery";  break;
            case SLIME_BALL:  gameId = "hideandseek";    break;
            case ENDER_EYE:   gameId = "prophunt";       break;
            case IRON_BARS:   gameId = "prisonescape";   break;
            case BRICKS:      gameId = "guessthebuild";  break;
        }

        if (gameId != null) {
            player.closeInventory();
            boolean joined = plugin.getGameManager().joinGame(player, gameId);
            if (!joined) {
                ChatUtils.sendMessage(player, "&cNão foi possível entrar neste minigame.");
            }
        }
    }
}
