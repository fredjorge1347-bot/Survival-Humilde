package com.minigamehub.minigames.guessthebuild;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Guess The Build — Um construtor recebe um tema secreto e constrói.
 * Os outros jogadores tentam adivinhar o que está sendo construído digitando no chat.
 * Vence quem acumular mais pontos ao longo de várias rodadas.
 */
public class GuessBuildGame extends MiniGame implements Listener {

    // Temas disponíveis (PT-BR)
    private static final List<String> THEMES = Arrays.asList(
        "cachorro", "gato", "casa", "arvore", "carro", "barco", "aviao", "foguete",
        "castelo", "espada", "arco-iris", "montanha", "praia", "cachoeira", "vulcao",
        "pizza", "sorvete", "bolo", "hamburguer", "maçã", "banana", "morango",
        "dragon", "creeper", "zumbi", "esqueleto", "enderman", "golem", "slime",
        "diamante", "ouro", "esmeralda", "cristal", "torcha",
        "chapeu", "oculos", "relogio", "chave", "telefone", "computador",
        "sol", "lua", "estrela", "nuvem", "chuva", "neve", "raio",
        "peixe", "tubarao", "baleia", "polvo", "caranguejo", "cavalo", "vaca",
        "leao", "elefante", "girafa", "macaco", "pinguim", "aguia", "cobra",
        "cogumelo", "flor", "rosa", "girassol", "bambu", "fern",
        "ponte", "torre", "farol", "predio", "tenda", "iglu",
        "bicicleta", "moto", "trem", "navio", "submarino", "helicoptero"
    );

    // Estado de rodada
    private int currentRound = 1;
    private static final int MAX_ROUNDS = 5;
    private static final int BUILD_SECONDS = 90;    // Tempo para construir
    private static final int GUESS_SECONDS = 30;    // Tempo extra para adivinhar após construir

    private UUID currentBuilderUUID;
    private String currentTheme;
    private final List<UUID> builderOrder = new ArrayList<>();
    private int builderIndex = 0;

    private final Map<UUID, Integer> points = new HashMap<>();
    private final Set<UUID> guessedThisRound = new HashSet<>();

    private BukkitTask roundTask;
    private int roundTimeLeft;
    private boolean buildPhase = true; // true = construindo, false = adivinhando

    // Plot de construção por jogador (simples: área de 15x15)
    private final Map<UUID, Location> buildPlots = new HashMap<>();
    private static final int PLOT_SIZE = 15;
    private static final int PLOT_HEIGHT = 10;

    // Items
    private static final ItemStack BUILD_KIT_WOOL;

    static {
        BUILD_KIT_WOOL = new ItemStack(Material.WHITE_WOOL, 64);
        ItemMeta m = BUILD_KIT_WOOL.getItemMeta();
        if (m != null) {
            m.setDisplayName(ChatUtils.color("&f&lKit de Construção"));
            BUILD_KIT_WOOL.setItemMeta(m);
        }
    }

    public GuessBuildGame(MinigameHub plugin) {
        super(plugin, "guessthebuild");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        World world = getOrCreateWorld();
        setupPlots(world);

        // Ordem aleatória de construtores
        builderOrder.addAll(players.stream().map(Player::getUniqueId).collect(java.util.stream.Collectors.toList()));
        Collections.shuffle(builderOrder);

        // Inicializar pontos
        for (Player p : players) {
            points.put(p.getUniqueId(), 0);
        }

        for (Player p : players) {
            p.setGameMode(GameMode.ADVENTURE);
            ChatUtils.sendMessage(p, "&6&lBem-vindo ao Guess The Build! &7" + MAX_ROUNDS + " rodadas, " +
                BUILD_SECONDS + "s por tema.");
            ChatUtils.sendMessage(p, "&7Adivinhe o que está sendo construído digitando no chat!");
        }

        startNextRound();
    }

    private void setupPlots(World world) {
        int plotSpacing = PLOT_SIZE + 5;
        int playerCount = players.size();

        for (int i = 0; i < playerCount; i++) {
            int row = i / 4;
            int col = i % 4;
            int ox = col * plotSpacing;
            int oz = row * plotSpacing;
            int oy = 64;

            // Piso do plot
            for (int x = 0; x < PLOT_SIZE; x++) {
                for (int z = 0; z < PLOT_SIZE; z++) {
                    world.getBlockAt(ox + x, oy - 1, oz + z).setType(Material.WHITE_CONCRETE);
                    // Limpar área acima
                    for (int y = oy; y < oy + PLOT_HEIGHT; y++) {
                        world.getBlockAt(ox + x, y, oz + z).setType(Material.AIR);
                    }
                }
            }
            // Bordas do plot
            for (int x = -1; x <= PLOT_SIZE; x++) {
                world.getBlockAt(ox + x, oy - 1, oz - 1).setType(Material.GRAY_CONCRETE);
                world.getBlockAt(ox + x, oy - 1, oz + PLOT_SIZE).setType(Material.GRAY_CONCRETE);
            }
            for (int z = -1; z <= PLOT_SIZE; z++) {
                world.getBlockAt(ox - 1, oy - 1, oz + z).setType(Material.GRAY_CONCRETE);
                world.getBlockAt(ox + PLOT_SIZE, oy - 1, oz + z).setType(Material.GRAY_CONCRETE);
            }

            buildPlots.put(players.get(i).getUniqueId(), new Location(world, ox + PLOT_SIZE / 2.0, oy, oz + PLOT_SIZE / 2.0));
        }
    }

    private void startNextRound() {
        if (builderIndex >= builderOrder.size()) {
            // Completou uma volta — próxima rodada
            currentRound++;
            builderIndex = 0;
            Collections.shuffle(builderOrder);

            if (currentRound > MAX_ROUNDS) {
                finishGame();
                return;
            }
        }

        currentBuilderUUID = builderOrder.get(builderIndex);
        builderIndex++;
        guessedThisRound.clear();
        buildPhase = true;

        Player builder = Bukkit.getPlayer(currentBuilderUUID);
        String theme = THEMES.get(new Random().nextInt(THEMES.size()));
        currentTheme = theme.toLowerCase().trim();

        // Teleportar construtor ao seu plot
        Location plot = buildPlots.get(currentBuilderUUID);
        if (builder != null && plot != null) {
            builder.teleport(plot);
            builder.setGameMode(GameMode.CREATIVE);
            builder.getInventory().clear();
            giveBuilderKit(builder);
            ChatUtils.sendTitle(builder, "&6&lCONSTRUA:", "&e" + currentTheme.toUpperCase(), 10, 60, 10);
            ChatUtils.sendMessage(builder, "&6&l[TEMA SECRETO] &e" + currentTheme.toUpperCase() +
                " &6— Você tem &e" + BUILD_SECONDS + "s &6para construir!");
        }

        // Outros ficam no modo espectador do construtor
        for (Player p : players) {
            if (p.getUniqueId().equals(currentBuilderUUID)) continue;
            p.setGameMode(GameMode.ADVENTURE);
            Location spectateFrom = plot != null ? plot.clone().add(0, 5, -10) : p.getLocation();
            p.teleport(spectateFrom);
            ChatUtils.sendTitle(p, "&7&lRODADA " + currentRound, "&e" + (builder != null ? builder.getName() : "?") + " está construindo...", 10, 60, 10);
            ChatUtils.sendMessage(p, "&7&oAdivinhe o que " + (builder != null ? builder.getName() : "?") +
                " está construindo! Digite no chat.");
        }

        broadcastToPlayers(ChatUtils.color("&6&l▶ RODADA &e" + currentRound + "&6/&e" + MAX_ROUNDS +
            " &6— Construtor: &e" + (builder != null ? builder.getName() : "?")));

        startRoundTimer();
    }

    private void giveBuilderKit(Player builder) {
        Material[] woolColors = {
            Material.WHITE_WOOL, Material.ORANGE_WOOL, Material.MAGENTA_WOOL,
            Material.LIGHT_BLUE_WOOL, Material.YELLOW_WOOL, Material.LIME_WOOL,
            Material.PINK_WOOL, Material.GRAY_WOOL, Material.LIGHT_GRAY_WOOL,
            Material.CYAN_WOOL, Material.PURPLE_WOOL, Material.BLUE_WOOL,
            Material.BROWN_WOOL, Material.GREEN_WOOL, Material.RED_WOOL, Material.BLACK_WOOL
        };
        Material[] otherBlocks = {
            Material.OAK_PLANKS, Material.STONE, Material.GLASS, Material.BRICKS,
            Material.SAND, Material.GRAVEL, Material.DIRT, Material.GRASS_BLOCK,
            Material.OAK_LOG, Material.COBBLESTONE, Material.IRON_BLOCK, Material.GOLD_BLOCK
        };

        int slot = 0;
        for (Material wool : woolColors) {
            if (slot >= 9) break;
            builder.getInventory().setItem(slot++, new ItemStack(wool, 64));
        }
        slot = 9;
        for (Material block : otherBlocks) {
            if (slot >= 18) break;
            builder.getInventory().setItem(slot++, new ItemStack(block, 64));
        }
    }

    private void startRoundTimer() {
        roundTimeLeft = BUILD_SECONDS;

        roundTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { roundTask.cancel(); return; }

            if (roundTimeLeft <= 0) {
                roundTask.cancel();
                endRound(false);
                return;
            }

            // Avisos de tempo
            if (roundTimeLeft == 60 || roundTimeLeft == 30 || roundTimeLeft <= 10) {
                broadcastToPlayers(ChatUtils.color("&eRestam &c" + roundTimeLeft + "s &epara adivinhar!"));
            }

            // Dica a cada 30 segundos: revelar primeira letra
            if (roundTimeLeft == BUILD_SECONDS - 30) {
                String hint = currentTheme.charAt(0) + "_".repeat(currentTheme.length() - 1);
                for (Player p : players) {
                    if (!p.getUniqueId().equals(currentBuilderUUID)) {
                        ChatUtils.sendMessage(p, "&7&oDica: &f" + hint + " &7(" + currentTheme.length() + " letras)");
                    }
                }
            }
            // Segunda dica: revelar metade
            if (roundTimeLeft == 20) {
                StringBuilder hint = new StringBuilder();
                for (int i = 0; i < currentTheme.length(); i++) {
                    hint.append(i % 2 == 0 ? currentTheme.charAt(i) : '_');
                }
                for (Player p : players) {
                    if (!p.getUniqueId().equals(currentBuilderUUID)) {
                        ChatUtils.sendMessage(p, "&7&oÚltima dica: &f" + hint);
                    }
                }
            }

            roundTimeLeft--;
        }, 0L, 20L);
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (state != GameState.IN_GAME) return;
        if (!players.contains(player)) return;
        if (player.getUniqueId().equals(currentBuilderUUID)) return; // Construtor não adivinha
        if (guessedThisRound.contains(player.getUniqueId())) return; // Já acertou

        String msg = event.getMessage().toLowerCase().trim();

        // Verificar se acertou
        if (msg.equals(currentTheme) || msg.equalsIgnoreCase(currentTheme)) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask(plugin, () -> correctGuess(player));
            return;
        }

        // Checar resposta parcialmente correta
        if (currentTheme.length() > 4 &&
                (currentTheme.startsWith(msg) || msg.startsWith(currentTheme.substring(0, currentTheme.length() - 1)))) {
            Bukkit.getScheduler().runTask(plugin, () ->
                ChatUtils.sendMessage(player, "&e&oQuase lá! Sua resposta está muito próxima..."));
        }
    }

    private void correctGuess(Player guesser) {
        guessedThisRound.add(guesser.getUniqueId());

        // Pontos baseados na velocidade: mais pontos por adivinhar rápido
        int timeBonus = Math.max(0, roundTimeLeft);
        int pts = 100 + timeBonus;
        int position = guessedThisRound.size();
        if (position == 1) {
            pts += 200; // Primeiro a adivinhar
            ChatUtils.sendMessage(guesser, "&6&l★ PRIMEIRO A ADIVINHAR! &e+" + pts + " pontos!");
        } else {
            ChatUtils.sendMessage(guesser, "&a&lCORRETO! &e+" + pts + " pontos!");
        }

        points.merge(guesser.getUniqueId(), pts, Integer::sum);

        // Construtor também ganha pontos por cada adivinhador
        points.merge(currentBuilderUUID, 50, Integer::sum);

        // Efeito de acerto
        guesser.playSound(guesser.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        guesser.getWorld().spawnParticle(Particle.FIREWORK, guesser.getLocation(), 20, 0.5, 0.5, 0.5, 0.1);

        String masked = "&a" + currentTheme.toUpperCase();
        for (Player p : players) {
            if (!p.getUniqueId().equals(currentBuilderUUID)) {
                ChatUtils.sendMessage(p, "&e" + guesser.getName() + " &aacertou: &f" + masked + "!");
            }
        }

        // Se todos adivinharam, avançar rodada
        long notGuessed = players.stream()
            .filter(p -> !p.getUniqueId().equals(currentBuilderUUID))
            .filter(p -> !guessedThisRound.contains(p.getUniqueId()))
            .count();

        if (notGuessed == 0) {
            broadcastToPlayers(ChatUtils.color("&a&lTodos adivinharam! Próxima rodada..."));
            if (roundTask != null) roundTask.cancel();
            Bukkit.getScheduler().runTaskLater(plugin, this::startNextRound, 60L);
        }
    }

    private void endRound(boolean timeUp) {
        if (timeUp || !guessedThisRound.isEmpty()) {
            broadcastToPlayers(ChatUtils.color("&7Tempo esgotado! O tema era: &e&l" + currentTheme.toUpperCase()));
        }
        // Exibir placar rápido
        broadcastToPlayers(ChatUtils.color("&6--- Placar Parcial ---"));
        points.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .limit(5)
            .forEach(e -> {
                Player p = Bukkit.getPlayer(e.getKey());
                String name = p != null ? p.getName() : "?";
                broadcastToPlayers(ChatUtils.color("&e" + name + ": &f" + e.getValue() + " pts"));
            });

        Bukkit.getScheduler().runTaskLater(plugin, this::startNextRound, 80L);
    }

    private void finishGame() {
        // Encontrar vencedor por pontos
        UUID winnerUid = points.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey).orElse(null);

        Player winner = winnerUid != null ? Bukkit.getPlayer(winnerUid) : null;

        broadcastToPlayers(ChatUtils.color("&6&l========== FIM DO JOGO =========="));
        broadcastToPlayers(ChatUtils.color("&ePlacar Final:"));
        points.entrySet().stream()
            .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
            .forEach(e -> {
                Player p = Bukkit.getPlayer(e.getKey());
                String name = p != null ? p.getName() : "?";
                broadcastToPlayers(ChatUtils.color("  &f" + name + ": &e" + e.getValue() + " &7pontos"));
            });

        endGame(winner);
    }

    @Override
    public void onEnd(Player winner) {
        if (roundTask != null) roundTask.cancel();
        points.clear(); guessedThisRound.clear();
        buildPlots.clear(); builderOrder.clear();
        currentBuilderUUID = null; currentTheme = null;
        builderIndex = 0; currentRound = 1; buildPhase = true;
        for (Player p : players) p.setGameMode(GameMode.ADVENTURE);
    }

    @Override
    public void onPlayerDeath(Player player) { /* sem morte */ }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&6&lBem-vindo ao Guess The Build!");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uid = player.getUniqueId();
        builderOrder.remove(uid);
        points.remove(uid);
        if (state == GameState.IN_GAME && uid.equals(currentBuilderUUID)) {
            broadcastToPlayers(ChatUtils.color("&cO construtor saiu! Próxima rodada..."));
            if (roundTask != null) roundTask.cancel();
            Bukkit.getScheduler().runTaskLater(plugin, this::startNextRound, 40L);
        }
    }

    @Override
    protected Player getLeadingPlayer() {
        return points.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(e -> Bukkit.getPlayer(e.getKey()))
            .filter(Objects::nonNull)
            .orElse(players.isEmpty() ? null : players.get(0));
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return world != null ? world.getSpawnLocation() : player.getLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&6&lGuess The Build"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        UUID uid = player.getUniqueId();
        boolean isBuilder = uid.equals(currentBuilderUUID);

        lines.add("&7Rodada: &e" + currentRound + "&7/&e" + MAX_ROUNDS);
        lines.add("&7Papel: " + (isBuilder ? "&6Construtor" : "&aAdivinhador"));
        if (isBuilder && currentTheme != null) {
            lines.add("&7Tema: &e" + currentTheme.toUpperCase());
        }
        lines.add("&7Seus pontos: &f" + points.getOrDefault(uid, 0));
        lines.add("&7Tempo: &c" + roundTimeLeft + "s");
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.guessthebuild.world", "minigame_guessthebuild");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            creator.generatorSettings("{\"layers\":[{\"block\":\"air\",\"height\":1}],\"biome\":\"plains\"}");
            world = creator.createWorld();
            if (world != null) {
                world.setDifficulty(Difficulty.PEACEFUL);
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.SHOW_DEATH_MESSAGES, false);
                world.setGameRule(GameRule.KEEP_INVENTORY, true);
                world.setGameRule(GameRule.DO_FIRE_TICK, false);
            }
        }
        return world;
    }
}
