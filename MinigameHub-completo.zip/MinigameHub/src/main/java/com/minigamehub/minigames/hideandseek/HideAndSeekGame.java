package com.minigamehub.minigames.hideandseek;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Hide and Seek (Esconde-esconde) — Fugitivos se transformam em blocos e se escondem.
 * O caçador tenta encontrá-los. Último escondido vence.
 */
public class HideAndSeekGame extends MiniGame implements Listener {

    private UUID seekerUUID;
    private final Set<UUID> hiders = new HashSet<>();
    private final Set<UUID> found = new HashSet<>();
    private final Map<UUID, Material> disguise = new HashMap<>(); // bloco atual de cada fugitivo

    // Itens
    private static final ItemStack SEEKER_STICK;
    private static final ItemStack HIDER_COMPASS;
    private static final ItemStack TRANSFORM_ITEM;

    // Blocos disponíveis para disfarce
    private static final Material[] DISGUISE_BLOCKS = {
        Material.STONE, Material.OAK_LOG, Material.SAND, Material.GRAVEL,
        Material.DIRT, Material.OAK_PLANKS, Material.COBBLESTONE,
        Material.BOOKSHELF, Material.COAL_ORE, Material.IRON_ORE,
        Material.CRAFTING_TABLE, Material.FURNACE, Material.BARREL
    };

    private BukkitTask countdownBlindTask; // cegueira do caçador no início
    private static final int HIDE_SECONDS = 30; // tempo para se esconder
    private final Random random = new Random();

    static {
        SEEKER_STICK = new ItemStack(Material.BLAZE_ROD);
        ItemMeta sm = SEEKER_STICK.getItemMeta();
        if (sm != null) {
            sm.setDisplayName(ChatUtils.color("&c&lBastão do Caçador"));
            sm.setLore(Collections.singletonList(ChatUtils.color("&7Clique para revelar blocos falsos próximos!")));
            SEEKER_STICK.setItemMeta(sm);
        }

        HIDER_COMPASS = new ItemStack(Material.COMPASS);
        ItemMeta cm = HIDER_COMPASS.getItemMeta();
        if (cm != null) {
            cm.setDisplayName(ChatUtils.color("&a&lBússola da Fuga"));
            cm.setLore(Collections.singletonList(ChatUtils.color("&7Aponta para longe do caçador!")));
            HIDER_COMPASS.setItemMeta(cm);
        }

        TRANSFORM_ITEM = new ItemStack(Material.SLIME_BALL);
        ItemMeta tm = TRANSFORM_ITEM.getItemMeta();
        if (tm != null) {
            tm.setDisplayName(ChatUtils.color("&b&lGoma de Transformação"));
            tm.setLore(Arrays.asList(
                ChatUtils.color("&7Clique com botão direito para se transformar"),
                ChatUtils.color("&7em um bloco aleatório!")
            ));
            TRANSFORM_ITEM.setItemMeta(tm);
        }
    }

    public HideAndSeekGame(MinigameHub plugin) {
        super(plugin, "hideandseek");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        assignRoles();
        giveItems();
        startHidePhase();
    }

    private void assignRoles() {
        List<Player> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);

        Player seeker = shuffled.get(0);
        seekerUUID = seeker.getUniqueId();

        for (int i = 1; i < shuffled.size(); i++) {
            hiders.add(shuffled.get(i).getUniqueId());
        }

        ChatUtils.sendTitle(seeker, "&c&lCAÇADOR", "&7Aguarde " + HIDE_SECONDS + "s e encontre todos!", 10, 60, 10);
        ChatUtils.sendMessage(seeker, "&c&l[CAÇADOR] &cVocê vai caçar os fugitivos! Aguarde " + HIDE_SECONDS + " segundos.");

        for (UUID uid : hiders) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                ChatUtils.sendTitle(p, "&a&lFUGITIVO", "&7Esconda-se antes que o caçador apareça!", 10, 60, 10);
                ChatUtils.sendMessage(p, "&a&l[FUGITIVO] &aEsconda-se! Use a goma para se disfarçar de bloco!");
            }
        }

        broadcastToPlayers(ChatUtils.color("&e" + seeker.getName() + " &7é o caçador! Fugitivos: &a" + hiders.size()));
    }

    private void giveItems() {
        Player seeker = Bukkit.getPlayer(seekerUUID);
        if (seeker != null) {
            seeker.getInventory().clear();
            seeker.getInventory().addItem(SEEKER_STICK.clone());
            seeker.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.BLINDNESS, HIDE_SECONDS * 20, 1));
            seeker.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOWNESS, HIDE_SECONDS * 20, 10));
            ChatUtils.sendMessage(seeker, "&8Você está às cegas por " + HIDE_SECONDS + " segundos...");
        }

        for (UUID uid : hiders) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.getInventory().clear();
                p.getInventory().addItem(TRANSFORM_ITEM.clone());
                p.getInventory().addItem(HIDER_COMPASS.clone());
            }
        }
    }

    private void startHidePhase() {
        final int[] timer = {HIDE_SECONDS};
        countdownBlindTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { countdownBlindTask.cancel(); return; }
            if (timer[0] <= 0) {
                countdownBlindTask.cancel();
                releaseSeeker();
                return;
            }
            if (timer[0] <= 10 || timer[0] % 10 == 0) {
                for (UUID uid : hiders) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p != null) ChatUtils.sendMessage(p, "&eO caçador é liberado em &c" + timer[0] + "s&e! Esconda-se!");
                }
            }
            timer[0]--;
        }, 0L, 20L);
    }

    private void releaseSeeker() {
        Player seeker = Bukkit.getPlayer(seekerUUID);
        if (seeker != null) {
            seeker.removePotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);
            seeker.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS);
            ChatUtils.sendTitle(seeker, "&c&lVÁ CAÇAR!", "&7Encontre os fugitivos disfarçados!", 10, 40, 10);
            seeker.playSound(seeker.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
        }
        broadcastToPlayers(ChatUtils.color("&c&l⚠ O CAÇADOR FOI LIBERADO! &7Fugitivos, fiquem quietos!"));
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        UUID uid = player.getUniqueId();
        ItemStack hand = player.getInventory().getItemInMainHand();

        // Fugitivo usa goma para se transformar
        if (hiders.contains(uid) && !found.contains(uid)) {
            if (hand.getType() == Material.SLIME_BALL) {
                if (event.getAction().name().contains("RIGHT")) {
                    transformToRandomBlock(player);
                    event.setCancelled(true);
                }
            }
        }

        // Caçador usa bastão para revelar blocos próximos
        if (uid.equals(seekerUUID) && hand.getType() == Material.BLAZE_ROD) {
            if (event.getAction().name().contains("RIGHT")) {
                revealNearbyHiders(player);
                event.setCancelled(true);
            }
        }
    }

    private void transformToRandomBlock(Player player) {
        Material block = DISGUISE_BLOCKS[random.nextInt(DISGUISE_BLOCKS.length)];
        disguise.put(player.getUniqueId(), block);

        // Alterar skin visualmente com particle de nuvem
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
        player.playSound(player.getLocation(), Sound.BLOCK_SAND_PLACE, 1f, 1f);

        String blockName = block.name().replace("_", " ").toLowerCase();
        ChatUtils.sendMessage(player, "&b&lTransformado! &7Você agora parece um &e" + blockName + "&7!");
        ChatUtils.sendMessage(player, "&8Fique parado para não ser revelado!");
    }

    private void revealNearbyHiders(Player seeker) {
        int radius = 5;
        Location seekerLoc = seeker.getLocation();
        boolean found = false;

        for (UUID uid : hiders) {
            if (this.found.contains(uid)) continue;
            Player hider = Bukkit.getPlayer(uid);
            if (hider == null) continue;
            if (hider.getLocation().distance(seekerLoc) <= radius) {
                // Revelar com partículas
                hider.getWorld().spawnParticle(Particle.FLAME, hider.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.05);
                broadcastToPlayers(ChatUtils.color("&c&l✦ &e" + hider.getName() + " &7foi revelado pelo bastão!"));
                eliminateHider(hider);
                found = true;
            }
        }
        if (!found) {
            ChatUtils.sendMessage(seeker, "&7Nenhum fugitivo a &e" + radius + " blocos&7...");
        }
        // Cooldown de 30s visível
        ChatUtils.sendMessage(seeker, "&8(Bastão tem cooldown de 30 segundos)");
        seeker.setCooldown(Material.BLAZE_ROD, 600);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (state != GameState.IN_GAME) return;
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();

        if (!players.contains(attacker) || !players.contains(victim)) return;

        // Caçador toca em fugitivo
        if (attacker.getUniqueId().equals(seekerUUID) && hiders.contains(victim.getUniqueId())) {
            event.setCancelled(true);
            eliminateHider(victim);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!hiders.contains(player.getUniqueId())) return;
        if (found.contains(player.getUniqueId())) return;

        // Se mover sendo disfarçado, revelar ao caçador
        if (disguise.containsKey(player.getUniqueId())) {
            Location from = event.getFrom();
            Location to = event.getTo();
            if (to != null && (Math.abs(from.getX() - to.getX()) > 0.1 || Math.abs(from.getZ() - to.getZ()) > 0.1)) {
                Player seeker = Bukkit.getPlayer(seekerUUID);
                if (seeker != null) {
                    ChatUtils.sendMessage(seeker, "&e⚠ Um bloco se moveu próximo a " + formatLocation(player.getLocation()) + "!");
                }
            }
        }

        // Atualizar bússola dos fugitivos
        if (!player.getUniqueId().equals(seekerUUID)) {
            Player seeker = Bukkit.getPlayer(seekerUUID);
            if (seeker != null) {
                // Compass não precisa de target no 1.20, mas podemos indicar direção via mensagem opcional
            }
        }
    }

    private String formatLocation(Location loc) {
        return "(" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ() + ")";
    }

    private void eliminateHider(Player hider) {
        UUID uid = hider.getUniqueId();
        found.add(uid);
        disguise.remove(uid);

        broadcastToPlayers(ChatUtils.color("&c" + hider.getName() + " &7foi encontrado! &7Restam: &e" +
            (hiders.size() - found.size()) + " &7fugitivos."));
        hider.playSound(hider.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        ChatUtils.sendTitle(hider, "&c&lENCONTRADO!", "&7Você foi pego pelo caçador!", 10, 40, 10);
        hider.setGameMode(GameMode.SPECTATOR);

        checkHiderWin();
    }

    private void checkHiderWin() {
        long aliveHiders = hiders.stream().filter(uid -> !found.contains(uid)).count();
        if (aliveHiders == 0) {
            Player seeker = Bukkit.getPlayer(seekerUUID);
            broadcastToPlayers(ChatUtils.color("&c&l✦ O CAÇADOR ENCONTROU TODOS! ✦"));
            endGame(seeker);
        } else if (aliveHiders == 1 && state == GameState.IN_GAME) {
            UUID lastUid = hiders.stream().filter(uid -> !found.contains(uid)).findFirst().orElse(null);
            if (lastUid != null) {
                Player last = Bukkit.getPlayer(lastUid);
                broadcastToPlayers(ChatUtils.color("&a&lApenas 1 fugitivo restante: &e" + (last != null ? last.getName() : "?")));
            }
        }
    }

    @Override
    protected void endGame(Player winner) {
        // Revelar posições ao fim
        for (UUID uid : hiders) {
            if (!found.contains(uid)) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    broadcastToPlayers(ChatUtils.color("&a" + p.getName() + " &7sobreviveu escondido em " + formatLocation(p.getLocation()) + "!"));
                }
            }
        }
        super.endGame(winner);
    }

    @Override
    public void onEnd(Player winner) {
        if (countdownBlindTask != null) countdownBlindTask.cancel();
        seekerUUID = null;
        hiders.clear();
        found.clear();
        disguise.clear();
        // Restaurar gamemodes
        for (Player p : players) {
            p.setGameMode(GameMode.ADVENTURE);
        }
    }

    @Override
    public void onPlayerDeath(Player player) {
        if (hiders.contains(player.getUniqueId())) {
            eliminateHider(player);
        }
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&a&lBem-vindo ao Esconde-esconde! &7Aguardando início...");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uid = player.getUniqueId();
        found.add(uid);
        hiders.remove(uid);
        disguise.remove(uid);
        if (state == GameState.IN_GAME) {
            if (uid.equals(seekerUUID)) {
                broadcastToPlayers(ChatUtils.color("&aO caçador saiu! Fugitivos vencem!"));
                Player winner = hiders.stream().filter(h -> !found.contains(h))
                    .map(Bukkit::getPlayer).filter(Objects::nonNull).findFirst().orElse(null);
                endGame(winner);
            } else {
                checkHiderWin();
            }
        }
    }

    @Override
    protected Player getLeadingPlayer() {
        // Caçador é o "líder" se encontrou mais fugitivos
        return Bukkit.getPlayer(seekerUUID);
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return world != null ? world.getSpawnLocation() : player.getLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&a&lEsconde-esconde"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        UUID uid = player.getUniqueId();
        boolean isSeeker = uid.equals(seekerUUID);
        lines.add("&7Papel: " + (isSeeker ? "&cCaçador" : "&aFugitivo"));
        lines.add("&7Fugitivos restantes: &f" + (hiders.size() - found.size()));
        if (!isSeeker && disguise.containsKey(uid)) {
            lines.add("&7Disfarce: &e" + disguise.get(uid).name().replace("_", " ").toLowerCase());
        }
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.hideandseek.world", "minigame_hideandseek");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.NORMAL);
            world = creator.createWorld();
            if (world != null) {
                world.setDifficulty(Difficulty.PEACEFUL);
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.NATURAL_REGENERATION, true);
                world.setGameRule(GameRule.SHOW_DEATH_MESSAGES, false);
            }
        }
        return world;
    }
}
