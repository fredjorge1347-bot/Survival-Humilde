package com.minigamehub.minigames.prisonescape;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Prison Escape — Prisioneiros tentam escapar da prisão enquanto guardas impedem.
 * - Prisioneiros coletam ferramentas e tentam chegar à zona de fuga.
 * - Guardas usam bastões para capturar prisioneiros.
 * - Prisioneiro capturado volta à cela; se todos escaparem, prisioneiros vencem.
 */
public class PrisonEscapeGame extends MiniGame implements Listener {

    private final Set<UUID> guards = new HashSet<>();
    private final Set<UUID> prisoners = new HashSet<>();
    private final Set<UUID> escaped = new HashSet<>();
    private final Set<UUID> captured = new HashSet<>();
    private final Map<UUID, Integer> captureCount = new HashMap<>();
    private final Map<UUID, Location> prisonCells = new HashMap<>();

    // Zona de fuga (configurável; aqui usamos Z > 50 como exemplo)
    private static final int ESCAPE_ZONE_Z = 50;
    private static final int ESCAPE_ZONE_RADIUS = 10;
    private Location escapeZoneCenter;

    // Tools para prisioneiros
    private static final ItemStack PICKAXE_ITEM;
    private static final ItemStack ROPE_ITEM; // Corda (escada) para subir muros
    private static final ItemStack DISTRACTION_ITEM; // Item de distração

    // Tool para guardas
    private static final ItemStack GUARD_BATON;
    private static final ItemStack GUARD_WHISTLE; // Sussurro: detecta prisioneiros próximos

    private BukkitTask escapeCheckTask;
    private static final int PREP_SECONDS = 15; // Prisioneiros se preparam antes dos guardas patrulharem
    private BukkitTask prepTask;
    private boolean prepPhase = true;

    static {
        PICKAXE_ITEM = new ItemStack(Material.STONE_PICKAXE);
        ItemMeta pm = PICKAXE_ITEM.getItemMeta();
        if (pm != null) {
            pm.setDisplayName(ChatUtils.color("&7&lPicareta da Fuga"));
            pm.setLore(Arrays.asList(
                ChatUtils.color("&7Quebre as grades da prisão!"),
                ChatUtils.color("&8(Use em blocos de pedra/ferro)")
            ));
            PICKAXE_ITEM.setItemMeta(pm);
        }

        ROPE_ITEM = new ItemStack(Material.LADDER, 8);
        ItemMeta rm = ROPE_ITEM.getItemMeta();
        if (rm != null) {
            rm.setDisplayName(ChatUtils.color("&a&lCorda de Fuga"));
            rm.setLore(Collections.singletonList(ChatUtils.color("&7Suba o muro da prisão!")));
            ROPE_ITEM.setItemMeta(rm);
        }

        DISTRACTION_ITEM = new ItemStack(Material.SNOWBALL, 3);
        ItemMeta dm = DISTRACTION_ITEM.getItemMeta();
        if (dm != null) {
            dm.setDisplayName(ChatUtils.color("&e&lItem de Distração"));
            dm.setLore(Arrays.asList(
                ChatUtils.color("&7Arremesse para distrair guardas!"),
                ChatUtils.color("&7Faz barulho no ponto de impacto.")
            ));
            DISTRACTION_ITEM.setItemMeta(dm);
        }

        GUARD_BATON = new ItemStack(Material.STICK);
        ItemMeta bm = GUARD_BATON.getItemMeta();
        if (bm != null) {
            bm.setDisplayName(ChatUtils.color("&c&lCassetete do Guarda"));
            bm.setLore(Collections.singletonList(ChatUtils.color("&7Bata em prisioneiros para capturá-los!")));
            GUARD_BATON.setItemMeta(bm);
        }

        GUARD_WHISTLE = new ItemStack(Material.IRON_NUGGET);
        ItemMeta wm = GUARD_WHISTLE.getItemMeta();
        if (wm != null) {
            wm.setDisplayName(ChatUtils.color("&b&lApito de Guarda"));
            wm.setLore(Arrays.asList(
                ChatUtils.color("&7Clique para detectar prisioneiros próximos!"),
                ChatUtils.color("&7Cooldown: &c20 segundos")
            ));
            GUARD_WHISTLE.setItemMeta(wm);
        }
    }

    private final Map<UUID, Long> whistleCooldown = new HashMap<>();

    public PrisonEscapeGame(MinigameHub plugin) {
        super(plugin, "prisonescape");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        World world = getOrCreateWorld();
        escapeZoneCenter = new Location(world, 0, 64, ESCAPE_ZONE_Z);
        buildPrison(world);
        assignRoles();
        giveItems();
        startPrepPhase();
        startEscapeChecker();
    }

    private void buildPrison(World world) {
        // Construir uma prisão básica: celas de pedra com saída bloqueada
        int ox = 0, oy = 64, oz = 0;

        // Piso
        for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 5; z++) {
                world.getBlockAt(ox + x, oy - 1, oz + z).setType(Material.STONE_BRICKS);
            }
        }
        // Paredes
        for (int y = oy; y <= oy + 5; y++) {
            for (int x = -15; x <= 15; x++) {
                world.getBlockAt(ox + x, y, oz - 15).setType(Material.STONE_BRICKS);
                world.getBlockAt(ox + x, y, oz + 5).setType(y < oy + 3 ? Material.IRON_BARS : Material.STONE_BRICKS);
            }
            for (int z = -15; z <= 5; z++) {
                world.getBlockAt(ox - 15, y, oz + z).setType(Material.STONE_BRICKS);
                world.getBlockAt(ox + 15, y, oz + z).setType(Material.STONE_BRICKS);
            }
        }
        // Teto parcial
        for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 5; z++) {
                world.getBlockAt(ox + x, oy + 5, oz + z).setType(Material.STONE_BRICKS);
            }
        }
        // Celas individuais (3 celas horizontais)
        for (int cell = 0; cell < 3; cell++) {
            int cx = ox - 8 + (cell * 8);
            for (int z = oz - 14; z <= oz - 8; z++) {
                world.getBlockAt(cx + 3, oy, z).setType(Material.IRON_BARS);
                world.getBlockAt(cx + 3, oy + 1, z).setType(Material.IRON_BARS);
            }
        }
        // Zona de fuga marcada com blocos de esmeralda
        for (int x = -5; x <= 5; x++) {
            for (int z = -5; z <= 5; z++) {
                world.getBlockAt(ox + x, oy - 1, ESCAPE_ZONE_Z + z).setType(Material.EMERALD_BLOCK);
            }
        }
        // Placa indicativa
        world.getBlockAt(ox, oy, ESCAPE_ZONE_Z - 6).setType(Material.OAK_SIGN);
    }

    private void assignRoles() {
        List<Player> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);

        // 25% guardas
        int guardCount = Math.max(1, players.size() / 4);

        for (int i = 0; i < guardCount; i++) {
            guards.add(shuffled.get(i).getUniqueId());
        }
        for (int i = guardCount; i < shuffled.size(); i++) {
            prisoners.add(shuffled.get(i).getUniqueId());
        }

        // Distribuir celas
        World world = getOrCreateWorld();
        int cellIdx = 0;
        for (UUID uid : prisoners) {
            int cx = -8 + (cellIdx % 3) * 8;
            Location cellLoc = new Location(world, cx + 0.5, 65, -10.5);
            prisonCells.put(uid, cellLoc);
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.teleport(cellLoc);
                ChatUtils.sendTitle(p, "&c&lPRISIONEIRO", "&7Escape antes que os guardas te capturem!", 10, 60, 10);
                ChatUtils.sendMessage(p, "&c&l[PRISIONEIRO] &cEscape da prisão! Chegue à zona verde (esmeralda)!");
            }
            cellIdx++;
        }

        for (UUID uid : guards) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.teleport(new Location(world, 0.5, 65, 0.5));
                ChatUtils.sendTitle(p, "&b&lGUARDA", "&7Impeça os prisioneiros de escaparem!", 10, 60, 10);
                ChatUtils.sendMessage(p, "&b&l[GUARDA] &bImpessa as fugas! Capture prisioneiros com o cassetete!");
            }
        }

        broadcastToPlayers(ChatUtils.color("&e" + guardCount + " guarda(s) vs &c" + prisoners.size() + " prisioneiro(s)!"));
        broadcastToPlayers(ChatUtils.color("&7Prisioneiros: cheguem à &a&lZONA VERDE &7para escapar!"));
    }

    private void giveItems() {
        for (UUID uid : prisoners) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.getInventory().clear();
                p.getInventory().addItem(PICKAXE_ITEM.clone());
                p.getInventory().addItem(ROPE_ITEM.clone());
                p.getInventory().addItem(DISTRACTION_ITEM.clone());
            }
        }
        for (UUID uid : guards) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.getInventory().clear();
                p.getInventory().addItem(GUARD_BATON.clone());
                p.getInventory().addItem(GUARD_WHISTLE.clone());
                p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
            }
        }
    }

    private void startPrepPhase() {
        broadcastToPlayers(ChatUtils.color("&e&lFASE DE PREPARAÇÃO! &7" + PREP_SECONDS + "s para se preparar antes dos guardas patrulharem."));

        // Guardar guardas no lugar durante prep
        for (UUID uid : guards) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SLOWNESS, PREP_SECONDS * 20, 10, false, false));
            }
        }

        final int[] timer = {PREP_SECONDS};
        prepTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { prepTask.cancel(); return; }
            if (timer[0] <= 0) {
                prepTask.cancel();
                prepPhase = false;
                for (UUID uid : guards) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p != null) {
                        p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS);
                        ChatUtils.sendTitle(p, "&c&lPATROLHE!", "&7Capture os prisioneiros!", 10, 40, 10);
                        p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
                    }
                }
                broadcastToPlayers(ChatUtils.color("&c&l⚠ GUARDAS EM PATRULHA! &7Prisioneiros, boa sorte!"));
                return;
            }
            if (timer[0] <= 5 || timer[0] % 5 == 0) {
                for (UUID uid : prisoners) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p != null) ChatUtils.sendMessage(p, "&eGuardas patrulham em &c" + timer[0] + "s&e!");
                }
            }
            timer[0]--;
        }, 0L, 20L);
    }

    private void startEscapeChecker() {
        escapeCheckTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { escapeCheckTask.cancel(); return; }
            for (UUID uid : prisoners) {
                if (escaped.contains(uid) || captured.contains(uid)) continue;
                Player p = Bukkit.getPlayer(uid);
                if (p == null) continue;
                // Verificar se está na zona de fuga
                if (escapeZoneCenter != null && p.getLocation().distance(escapeZoneCenter) <= ESCAPE_ZONE_RADIUS
                        && p.getLocation().getBlockY() >= 63) {
                    escapePrisoner(p);
                }
            }
            checkWinCondition();
        }, 20L, 10L);
    }

    private void escapePrisoner(Player prisoner) {
        escaped.add(prisoner.getUniqueId());
        prisoner.getInventory().clear();

        broadcastToPlayers(ChatUtils.color("&a&l✦ &e" + prisoner.getName() + " &aESCAPOU! &7(" +
            escaped.size() + "/" + prisoners.size() + " fugiram)"));
        ChatUtils.sendTitle(prisoner, "&a&lESCAPEI!", "&7Você cruzou a zona de fuga!", 10, 60, 10);
        prisoner.setGameMode(GameMode.SPECTATOR);
        prisoner.getWorld().spawnParticle(Particle.FIREWORK, prisoner.getLocation(), 30, 1, 1, 1, 0.1);
        prisoner.playSound(prisoner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (state != GameState.IN_GAME) return;
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();
        if (!players.contains(attacker) || !players.contains(victim)) return;

        event.setCancelled(true); // Sem dano real

        // Guarda captura prisioneiro
        if (guards.contains(attacker.getUniqueId()) && prisoners.contains(victim.getUniqueId())
                && !escaped.contains(victim.getUniqueId()) && !captured.contains(victim.getUniqueId())) {
            capturePrisoner(victim, attacker);
        }
    }

    private void capturePrisoner(Player prisoner, Player guard) {
        int captures = captureCount.getOrDefault(guard.getUniqueId(), 0) + 1;
        captureCount.put(guard.getUniqueId(), captures);

        // Volta para a cela
        Location cell = prisonCells.get(prisoner.getUniqueId());
        if (cell != null) prisoner.teleport(cell);

        // Retirar itens de fuga (só deixa 1 de cada)
        prisoner.getInventory().clear();
        prisoner.getInventory().addItem(ROPE_ITEM.clone());

        broadcastToPlayers(ChatUtils.color("&c" + guard.getName() + " &7capturou &e" + prisoner.getName() +
            "! &7(captura #" + captures + " do guarda)"));
        ChatUtils.sendTitle(prisoner, "&c&lCAPTURADO!", "&7De volta à cela! Tente novamente.", 10, 40, 10);

        guard.playSound(guard.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        prisoner.playSound(prisoner.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        UUID uid = player.getUniqueId();
        ItemStack hand = player.getInventory().getItemInMainHand();

        // Guarda usa apito para detectar
        if (guards.contains(uid) && hand.getType() == Material.IRON_NUGGET) {
            if (event.getAction().name().contains("RIGHT")) {
                long now = System.currentTimeMillis();
                long last = whistleCooldown.getOrDefault(uid, 0L);
                if (now - last < 20_000) {
                    ChatUtils.sendMessage(player, "&cApito recarregando: &e" + ((20_000 - (now - last)) / 1000 + 1) + "s");
                } else {
                    whistleCooldown.put(uid, now);
                    useWhistle(player);
                }
                event.setCancelled(true);
            }
        }
    }

    private void useWhistle(Player guard) {
        int detected = 0;
        for (UUID uid : prisoners) {
            if (escaped.contains(uid) || captured.contains(uid)) continue;
            Player p = Bukkit.getPlayer(uid);
            if (p == null) continue;
            double dist = guard.getLocation().distance(p.getLocation());
            if (dist <= 20) {
                int distInt = (int) dist;
                ChatUtils.sendMessage(guard, "&e⚡ Apito: &c" + p.getName() + " &7a &e" + distInt + " blocos&7!");
                detected++;
            }
        }
        if (detected == 0) {
            ChatUtils.sendMessage(guard, "&7Apito: nenhum prisioneiro a &e20 blocos&7.");
        }
        guard.playSound(guard.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 2f);
    }

    @Override
    protected void checkWinCondition() {
        long activePrisoners = prisoners.stream()
            .filter(uid -> !escaped.contains(uid) && !captured.contains(uid))
            .count();

        // Todos escaparam — prisioneiros vencem
        if (escaped.size() >= prisoners.size()) {
            broadcastToPlayers(ChatUtils.color("&a&l✦ OS PRISIONEIROS ESCAPARAM! ✦ &7Fugitivos vitoriosos!"));
            Player winner = escaped.stream().map(Bukkit::getPlayer).filter(Objects::nonNull).findFirst().orElse(null);
            endGame(winner);
        }
        // Nenhum prisioneiro pode mais escapar — guardas vencem
        else if (activePrisoners == 0 && escaped.size() < prisoners.size()) {
            broadcastToPlayers(ChatUtils.color("&b&l✦ OS GUARDAS VENCERAM! ✦ &7Nenhum prisioneiro escapou!"));
            Player winner = guards.stream().map(Bukkit::getPlayer).filter(Objects::nonNull).findFirst().orElse(null);
            endGame(winner);
        }
    }

    @Override
    public void onEnd(Player winner) {
        if (escapeCheckTask != null) escapeCheckTask.cancel();
        if (prepTask != null) prepTask.cancel();
        guards.clear(); prisoners.clear(); escaped.clear();
        captured.clear(); captureCount.clear(); prisonCells.clear();
        whistleCooldown.clear();
        prepPhase = true;
        for (Player p : players) {
            p.setGameMode(GameMode.ADVENTURE);
            p.removePotionEffect(org.bukkit.potion.PotionEffectType.SPEED);
        }
    }

    @Override
    public void onPlayerDeath(Player player) {
        if (prisoners.contains(player.getUniqueId())) {
            Location cell = prisonCells.get(player.getUniqueId());
            if (cell != null) Bukkit.getScheduler().runTaskLater(plugin, () -> player.teleport(cell), 5L);
        }
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&c&lBem-vindo ao Prison Escape! &7Aguardando início...");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uid = player.getUniqueId();
        prisoners.remove(uid); guards.remove(uid);
        escaped.remove(uid); captured.remove(uid);
        if (state == GameState.IN_GAME) checkWinCondition();
    }

    @Override
    protected Player getLeadingPlayer() {
        // Prisioneiro com mais tentativas de fuga (ou guardas com mais capturas)
        return captureCount.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(e -> Bukkit.getPlayer(e.getKey()))
            .filter(Objects::nonNull)
            .orElse(players.isEmpty() ? null : players.get(0));
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return world != null ? world.getSpawnLocation() : player.getLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&c&lPrison Escape"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        UUID uid = player.getUniqueId();
        boolean isGuard = guards.contains(uid);
        lines.add("&7Papel: " + (isGuard ? "&bGuarda" : "&cPrisioneiro"));
        lines.add("&7Fugiram: &a" + escaped.size() + "&7/&c" + prisoners.size());
        if (isGuard) {
            lines.add("&7Suas capturas: &e" + captureCount.getOrDefault(uid, 0));
        } else if (!escaped.contains(uid)) {
            lines.add("&7Status: " + (captured.contains(uid) ? "&cNa cela" : "&aLivre"));
        }
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.prisonescape.world", "minigame_prisonescape");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            world = creator.createWorld();
            if (world != null) {
                world.setDifficulty(Difficulty.PEACEFUL);
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.SHOW_DEATH_MESSAGES, false);
                world.setGameRule(GameRule.KEEP_INVENTORY, true);
            }
        }
        return world;
    }
}
