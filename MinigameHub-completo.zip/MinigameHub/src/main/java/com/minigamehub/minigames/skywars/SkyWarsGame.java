package com.minigamehub.minigames.skywars;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * SkyWars — ilhas no céu com baús de loot. Último sobrevivente vence.
 * Cada jogador começa em uma ilha separada com um baú de itens.
 */
public class SkyWarsGame extends MiniGame implements Listener {

    // Loot predefinido para os baús (3 níveis de raridade)
    private static final ItemStack[][] CHEST_LOOT = {
        // Comum
        { new ItemStack(Material.STONE_SWORD), new ItemStack(Material.LEATHER_CHESTPLATE),
          new ItemStack(Material.BREAD, 8), new ItemStack(Material.OAK_PLANKS, 16),
          new ItemStack(Material.STONE_PICKAXE), new ItemStack(Material.ARROW, 16) },
        // Raro
        { new ItemStack(Material.IRON_SWORD), new ItemStack(Material.IRON_CHESTPLATE),
          new ItemStack(Material.IRON_BOOTS), new ItemStack(Material.BOW),
          new ItemStack(Material.GOLDEN_APPLE, 3), new ItemStack(Material.ARROW, 32) },
        // Épico (centro)
        { new ItemStack(Material.DIAMOND_SWORD), new ItemStack(Material.DIAMOND_CHESTPLATE),
          new ItemStack(Material.DIAMOND_HELMET), new ItemStack(Material.DIAMOND_LEGGINGS),
          new ItemStack(Material.DIAMOND_BOOTS), new ItemStack(Material.GOLDEN_APPLE, 5),
          new ItemStack(Material.ENDER_PEARL, 3), new ItemStack(Material.TNT, 4) }
    };

    private final Map<UUID, Location> playerSpawns = new HashMap<>();
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Set<UUID> eliminated = new HashSet<>();
    private final Random random = new Random();
    private BukkitTask borderTask;
    private int borderRadius = 200;

    public SkyWarsGame(MinigameHub plugin) {
        super(plugin, "skywars");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        World world = getOrCreateWorld();
        buildIslands(world);
        spawnPlayers(world);
        buildCenterIsland(world);
        startBorderShrink(world);

        for (Player p : players) {
            p.setGameMode(GameMode.SURVIVAL);
            kills.put(p.getUniqueId(), 0);
            ChatUtils.sendMessage(p, "&e&lBem-vindo ao &fSky Wars&e!");
            ChatUtils.sendMessage(p, "&7Abra o baú na sua ilha e lute! Último sobrevivente vence!");
            ChatUtils.sendMessage(p, "&7&oA borda está se fechando...");
            ChatUtils.sendTitle(p, "&e&lSKY WARS", "&7Lute para sobreviver!", 10, 40, 10);
        }
    }

    private void buildIslands(World world) {
        int playerCount = players.size();
        int radius = 60; // Distância de cada ilha do centro

        for (int i = 0; i < playerCount; i++) {
            double angle = (2 * Math.PI / playerCount) * i;
            int x = (int) (radius * Math.cos(angle));
            int z = (int) (radius * Math.sin(angle));
            int y = 100;

            Location center = new Location(world, x, y, z);
            buildSkyIsland(center, world);

            // Baú com loot comum
            Location chestLoc = new Location(world, x, y + 1, z);
            placeChestWithLoot(chestLoc, 0);

            Location spawnLoc = new Location(world, x + 0.5, y + 2, z + 0.5);
            playerSpawns.put(players.get(i).getUniqueId(), spawnLoc);
        }
    }

    private void buildSkyIsland(Location center, World world) {
        int cx = center.getBlockX(), cy = center.getBlockY(), cz = center.getBlockZ();
        // Ilha circular de gramado
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                if (x * x + z * z <= 16) {
                    world.getBlockAt(cx + x, cy, cz + z).setType(Material.GRASS_BLOCK);
                    world.getBlockAt(cx + x, cy - 1, cz + z).setType(Material.DIRT);
                    world.getBlockAt(cx + x, cy - 2, cz + z).setType(Material.STONE);
                }
            }
        }
        // Plataforma de lança
        world.getBlockAt(cx, cy + 1, cz).setType(Material.OAK_PLANKS);
    }

    private void buildCenterIsland(World world) {
        // Ilha central maior com loot épico
        int cx = 0, cy = 100, cz = 0;
        for (int x = -8; x <= 8; x++) {
            for (int z = -8; z <= 8; z++) {
                if (x * x + z * z <= 64) {
                    world.getBlockAt(cx + x, cy, cz + z).setType(Material.GRASS_BLOCK);
                    world.getBlockAt(cx + x, cy - 1, cz + z).setType(Material.DIRT);
                    world.getBlockAt(cx + x, cy - 2, cz + z).setType(Material.STONE);
                }
            }
        }
        // Vários baús épicos no centro
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (Math.abs(i) + Math.abs(j) == 1) {
                    placeChestWithLoot(new Location(world, cx + i, cy + 1, cz + j), 2);
                }
            }
        }
        // Baú raro ao redor
        for (int angle = 0; angle < 360; angle += 90) {
            int bx = (int)(3 * Math.cos(Math.toRadians(angle)));
            int bz = (int)(3 * Math.sin(Math.toRadians(angle)));
            placeChestWithLoot(new Location(world, cx + bx, cy + 1, cz + bz), 1);
        }
    }

    private void placeChestWithLoot(Location loc, int tier) {
        loc.getBlock().setType(Material.CHEST);
        org.bukkit.block.Chest chest = (org.bukkit.block.Chest) loc.getBlock().getState();
        ItemStack[] lootPool = CHEST_LOOT[Math.min(tier, CHEST_LOOT.length - 1)];

        // Colocar alguns itens aleatórios
        int itemCount = random.nextInt(3) + (tier + 1) * 2;
        Set<Integer> slots = new HashSet<>();
        for (int i = 0; i < Math.min(itemCount, lootPool.length); i++) {
            int slot;
            do { slot = random.nextInt(27); } while (slots.contains(slot));
            slots.add(slot);
            ItemStack item = lootPool[random.nextInt(lootPool.length)].clone();
            chest.getInventory().setItem(slot, item);
        }
    }

    private void spawnPlayers(World world) {
        for (Player p : players) {
            Location spawn = playerSpawns.get(p.getUniqueId());
            if (spawn != null) {
                p.teleport(spawn);
                p.setHealth(20);
                p.setFoodLevel(20);
                p.getInventory().clear();
            }
        }
    }

    private void startBorderShrink(World world) {
        // A cada 60 segundos, a borda diminui
        borderTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { borderTask.cancel(); return; }
            if (borderRadius > 30) {
                borderRadius -= 20;
                broadcastToPlayers(ChatUtils.color("&c⚠ A borda diminuiu! Raio: &e" + borderRadius + " blocos"));
                // Empurrar jogadores fora da borda
                for (Player p : players) {
                    if (p.getLocation().distance(new Location(world, 0, p.getLocation().getY(), 0)) > borderRadius) {
                        p.damage(4.0);
                        ChatUtils.sendMessage(p, "&c&lVocê está fora da borda! Tome dano!");
                    }
                }
            }
        }, 1200L, 1200L); // Diminui a cada 60 segundos
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!players.contains(victim)) return;

        event.setDeathMessage(null);
        eliminated.add(victim.getUniqueId());

        Player killer = victim.getKiller();
        if (killer != null && players.contains(killer)) {
            kills.merge(killer.getUniqueId(), 1, Integer::sum);
            broadcastToPlayers(ChatUtils.color("&c" + victim.getName() + " &7foi eliminado por &e" + killer.getName()
                + " &7| Sobreviventes: &f" + (players.size() - eliminated.size())));
        } else {
            broadcastToPlayers(ChatUtils.color("&c" + victim.getName() + " &7caiu do mapa!"
                + " &7| Sobreviventes: &f" + (players.size() - eliminated.size())));
        }

        // Remover jogador após mostrar mensagem
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            removePlayer(victim);
        }, 60L);
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!players.contains(player)) return;
        // No SkyWars não há respawn — redirecionar para hub
        plugin.getLobbyManager().sendToHub(player);
    }

    @Override
    public void onPlayerDeath(Player player) { /* handled by event */ }

    @Override
    protected void checkWinCondition() {
        long alive = players.stream().filter(p -> !eliminated.contains(p.getUniqueId())).count();
        if (alive <= 1) {
            Player winner = players.stream()
                .filter(p -> !eliminated.contains(p.getUniqueId()))
                .findFirst().orElse(null);
            endGame(winner);
        }
    }

    @Override
    public void onEnd(Player winner) {
        if (borderTask != null) borderTask.cancel();
        playerSpawns.clear();
        kills.clear();
        eliminated.clear();
        borderRadius = 200;
        // Limpar ilhas
        cleanupIslands(getOrCreateWorld());
    }

    private void cleanupIslands(World world) {
        // Limpar área das ilhas
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (int x = -100; x <= 100; x += 5) {
                for (int z = -100; z <= 100; z += 5) {
                    for (int y = 90; y <= 120; y++) {
                        world.getBlockAt(x, y, z).setType(Material.AIR);
                    }
                }
            }
        }, 200L);
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&e&lBem-vindo ao Sky Wars!");
    }

    @Override
    public void onPlayerLeave(Player player) {
        playerSpawns.remove(player.getUniqueId());
        kills.remove(player.getUniqueId());
        if (state == GameState.IN_GAME) {
            eliminated.add(player.getUniqueId());
            checkWinCondition();
        }
    }

    @Override
    protected Player getLeadingPlayer() {
        return kills.entrySet().stream()
            .filter(e -> !eliminated.contains(e.getKey()))
            .max(Map.Entry.comparingByValue())
            .map(e -> Bukkit.getPlayer(e.getKey()))
            .filter(Objects::nonNull)
            .orElse(players.stream()
                .filter(p -> !eliminated.contains(p.getUniqueId()))
                .findFirst().orElse(null));
    }

    @Override
    public Location getSpawnLocation(Player player) {
        return playerSpawns.getOrDefault(player.getUniqueId(), getOrCreateWorld().getSpawnLocation());
    }

    @Override
    public String getScoreboardTitle() { return "&e&lSky Wars"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        long aliveCount = players.stream().filter(p -> !eliminated.contains(p.getUniqueId())).count();
        lines.add("&7Sobreviventes: &f" + aliveCount);
        lines.add("&7Eliminados: &c" + eliminated.size());
        lines.add("&7Seus kills: &e" + kills.getOrDefault(player.getUniqueId(), 0));
        lines.add("&7Borda: &f" + borderRadius + " blocos");
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.skywars.world", "minigame_skywars");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            creator.generatorSettings("{\"layers\":[{\"block\":\"air\",\"height\":1}],\"biome\":\"sky\"}");
            world = creator.createWorld();
            if (world != null) {
                world.setSpawnFlags(false, false);
                world.setDifficulty(Difficulty.NORMAL);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.FALL_DAMAGE, true);
            }
        }
        return world;
    }
}
