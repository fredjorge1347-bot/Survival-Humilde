package com.minigamehub.minigames.prophunt;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Prop Hunt — Fugitivos se disfarçam de objetos/blocos com mais variedade.
 * Similar ao Hide and Seek, mas com um menu de escolha de disfarce e habilidades extras.
 * - Fugitivos podem escolher seu disfarce (em vez de aleatório).
 * - Caçadores têm radar pulsante que pisca quando próximos de fugitivos.
 */
public class PropHuntGame extends MiniGame implements Listener {

    private final Set<UUID> hunters = new HashSet<>();
    private final Set<UUID> props = new HashSet<>();
    private final Set<UUID> found = new HashSet<>();
    private final Map<UUID, Material> chosenProp = new HashMap<>();
    private final Map<UUID, Long> lastTauntTime = new HashMap<>();

    private BukkitTask radarTask;
    private BukkitTask blindTask;
    private static final int HIDE_SECONDS = 40;
    private static final int TAUNT_COOLDOWN_MS = 10_000; // 10 segundos

    // Todos os props disponíveis (muito mais variedade que o H&S)
    private static final Material[] ALL_PROPS = {
        // Blocos naturais
        Material.STONE, Material.DIRT, Material.SAND, Material.GRAVEL,
        Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG,
        Material.OAK_LEAVES, Material.GRASS_BLOCK, Material.CLAY,
        Material.MOSSY_COBBLESTONE, Material.COBBLESTONE,
        // Blocos de construção
        Material.OAK_PLANKS, Material.SPRUCE_PLANKS, Material.BOOKSHELF,
        Material.BRICKS, Material.STONE_BRICKS, Material.SMOOTH_STONE,
        // Containers e utensílios
        Material.CRAFTING_TABLE, Material.FURNACE, Material.BARREL,
        Material.CHEST, Material.TRAPPED_CHEST, Material.COMPOSTER,
        Material.CAULDRON, Material.LECTERN, Material.LOOM,
        // Flores e plantas
        Material.FLOWER_POT, Material.CACTUS, Material.PUMPKIN,
        Material.MELON, Material.HAY_BLOCK,
        // Minérios e metais
        Material.COAL_ORE, Material.IRON_ORE, Material.GOLD_ORE,
        Material.IRON_BLOCK, Material.GOLD_BLOCK,
        // Miscelânea
        Material.TNT, Material.SPONGE, Material.BEEHIVE,
        Material.NOTE_BLOCK, Material.JUKEBOX
    };

    private static final ItemStack HUNTER_GUN;     // Arco de caça
    private static final ItemStack PROP_SELECTOR;  // Menu de seleção de disfarce
    private static final ItemStack TAUNT_ITEM;     // Som provocação (risco/recompensa)

    static {
        HUNTER_GUN = new ItemStack(Material.BOW);
        ItemMeta hm = HUNTER_GUN.getItemMeta();
        if (hm != null) {
            hm.setDisplayName(ChatUtils.color("&c&lArco de Caça"));
            hm.setLore(Arrays.asList(
                ChatUtils.color("&7Atire nos props para eliminá-los!"),
                ChatUtils.color("&8(Cuidado: acertar o bloco errado não adianta)")
            ));
            HUNTER_GUN.setItemMeta(hm);
        }

        PROP_SELECTOR = new ItemStack(Material.ENDER_EYE);
        ItemMeta pm = PROP_SELECTOR.getItemMeta();
        if (pm != null) {
            pm.setDisplayName(ChatUtils.color("&b&lSeletor de Disfarce"));
            pm.setLore(Arrays.asList(
                ChatUtils.color("&7Clique com botão direito para se disfarçar"),
                ChatUtils.color("&7de um objeto aleatório!"),
                ChatUtils.color("&8(Cooldown de 5s entre transformações)")
            ));
            PROP_SELECTOR.setItemMeta(pm);
        }

        TAUNT_ITEM = new ItemStack(Material.NOTE_BLOCK);
        ItemMeta tm = TAUNT_ITEM.getItemMeta();
        if (tm != null) {
            tm.setDisplayName(ChatUtils.color("&e&lProvocação"));
            tm.setLore(Arrays.asList(
                ChatUtils.color("&7Emite um som para provocar o caçador!"),
                ChatUtils.color("&7Cooldown: &c10 segundos"),
                ChatUtils.color("&8(Risco: pode revelar sua posição!)")
            ));
            TAUNT_ITEM.setItemMeta(tm);
        }
    }

    private final Map<UUID, Long> transformCooldown = new HashMap<>();
    private final Random random = new Random();

    public PropHuntGame(MinigameHub plugin) {
        super(plugin, "prophunt");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        assignRoles();
        giveItems();
        startHidePhase();
        startRadar();
    }

    private void assignRoles() {
        List<Player> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);

        // 25% caçadores, 75% props (mínimo 1 caçador)
        int hunterCount = Math.max(1, players.size() / 4);

        for (int i = 0; i < hunterCount; i++) {
            hunters.add(shuffled.get(i).getUniqueId());
        }
        for (int i = hunterCount; i < shuffled.size(); i++) {
            props.add(shuffled.get(i).getUniqueId());
        }

        for (UUID uid : hunters) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                ChatUtils.sendTitle(p, "&c&lCAÇADOR", "&7Caçe os props! Você tem " + HIDE_SECONDS + "s de espera.", 10, 60, 10);
                ChatUtils.sendMessage(p, "&c&l[CAÇADOR] &cVocê vai caçar os props! Aguarde a contagem.");
            }
        }
        for (UUID uid : props) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                ChatUtils.sendTitle(p, "&b&lPROP", "&7Escolha um disfarce e se esconda!", 10, 60, 10);
                ChatUtils.sendMessage(p, "&b&l[PROP] &bEscolha seu disfarce e se esconda! Use a provocação com cuidado.");
            }
        }
        broadcastToPlayers(ChatUtils.color("&e" + hunterCount + " caçador(es) vs &b" + props.size() + " props! Que comece o Prop Hunt!"));
    }

    private void giveItems() {
        for (UUID uid : hunters) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.getInventory().clear();
                p.getInventory().addItem(HUNTER_GUN.clone());
                p.getInventory().addItem(new ItemStack(Material.ARROW, 64));
                p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.BLINDNESS, HIDE_SECONDS * 20, 1));
                p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SLOWNESS, HIDE_SECONDS * 20, 10));
            }
        }
        for (UUID uid : props) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.getInventory().clear();
                p.getInventory().addItem(PROP_SELECTOR.clone());
                p.getInventory().addItem(TAUNT_ITEM.clone());
                // Transformar em prop aleatório no início
                transformProp(p);
            }
        }
    }

    private void startHidePhase() {
        final int[] timer = {HIDE_SECONDS};
        blindTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { blindTask.cancel(); return; }
            if (timer[0] <= 0) {
                blindTask.cancel();
                releaseHunters();
                return;
            }
            if (timer[0] <= 10 || timer[0] % 10 == 0) {
                for (UUID uid : props) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p != null) ChatUtils.sendMessage(p, "&eCaçadores liberados em &c" + timer[0] + "s&e!");
                }
            }
            timer[0]--;
        }, 0L, 20L);
    }

    private void releaseHunters() {
        for (UUID uid : hunters) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS);
                ChatUtils.sendTitle(p, "&c&lCAÇE OS PROPS!", "&7Encontre e elimine todos os disfarçados!", 10, 40, 10);
                p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
            }
        }
        broadcastToPlayers(ChatUtils.color("&c&l⚠ OS CAÇADORES FORAM LIBERADOS! &7Props, fiquem quietos!"));
    }

    private void startRadar() {
        // Radar pulsa a cada 3 segundos e avisa caçadores quando perto de props
        radarTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { radarTask.cancel(); return; }
            for (UUID hunterUid : hunters) {
                Player hunter = Bukkit.getPlayer(hunterUid);
                if (hunter == null) continue;
                int closest = Integer.MAX_VALUE;
                for (UUID propUid : props) {
                    if (found.contains(propUid)) continue;
                    Player prop = Bukkit.getPlayer(propUid);
                    if (prop == null) continue;
                    int dist = (int) hunter.getLocation().distance(prop.getLocation());
                    if (dist < closest) closest = dist;
                }
                if (closest <= 5) {
                    ChatUtils.sendMessage(hunter, "&c⚡ RADAR: &fProp &cmuitíssimo próximo! (&e" + closest + " blocos&c)");
                    hunter.playSound(hunter.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 2f);
                } else if (closest <= 15) {
                    ChatUtils.sendMessage(hunter, "&e⚡ RADAR: &fProp &epróximo! (&e" + closest + " blocos&e)");
                    hunter.playSound(hunter.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 1.5f);
                } else if (closest <= 30) {
                    ChatUtils.sendMessage(hunter, "&7⚡ RADAR: &fProp &7por perto... (&7" + closest + " blocos&7)");
                    hunter.playSound(hunter.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.3f, 1f);
                }
            }
        }, 60L, 60L); // A cada 3 segundos
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        UUID uid = player.getUniqueId();
        ItemStack hand = player.getInventory().getItemInMainHand();

        if (props.contains(uid) && !found.contains(uid)) {
            if (hand.getType() == Material.ENDER_EYE && event.getAction().name().contains("RIGHT")) {
                // Transformar (com cooldown de 5s)
                long now = System.currentTimeMillis();
                long last = transformCooldown.getOrDefault(uid, 0L);
                if (now - last < 5000) {
                    ChatUtils.sendMessage(player, "&cAguarde &e" + ((5000 - (now - last)) / 1000 + 1) + "s &cpara se transformar novamente!");
                } else {
                    transformCooldown.put(uid, now);
                    transformProp(player);
                }
                event.setCancelled(true);
            } else if (hand.getType() == Material.NOTE_BLOCK && event.getAction().name().contains("RIGHT")) {
                // Provocação (cooldown de 10s)
                long now = System.currentTimeMillis();
                long last = lastTauntTime.getOrDefault(uid, 0L);
                if (now - last < TAUNT_COOLDOWN_MS) {
                    ChatUtils.sendMessage(player, "&cAguarde &e" + ((TAUNT_COOLDOWN_MS - (now - last)) / 1000 + 1) + "s &cpara provocar novamente!");
                } else {
                    lastTauntTime.put(uid, now);
                    doTaunt(player);
                }
                event.setCancelled(true);
            }
        }
    }

    private void transformProp(Player player) {
        Material mat = ALL_PROPS[random.nextInt(ALL_PROPS.length)];
        chosenProp.put(player.getUniqueId(), mat);

        player.getWorld().spawnParticle(Particle.WITCH, player.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.05);
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 1f);

        String propName = mat.name().replace("_", " ").toLowerCase();
        ChatUtils.sendMessage(player, "&b&lTransformado! &7Agora você é: &e" + propName);
    }

    private void doTaunt(Player player) {
        // Som audível por todos na área (50 blocos)
        Sound[] tauntSounds = {
            Sound.ENTITY_CAT_AMBIENT, Sound.ENTITY_PIG_AMBIENT,
            Sound.ENTITY_COW_AMBIENT, Sound.ENTITY_SHEEP_AMBIENT,
            Sound.ENTITY_CHICKEN_AMBIENT, Sound.ENTITY_VILLAGER_AMBIENT
        };
        Sound taunt = tauntSounds[random.nextInt(tauntSounds.length)];
        player.getWorld().playSound(player.getLocation(), taunt, 2f, 1f);

        ChatUtils.sendMessage(player, "&e&lProvocação emitida! &7Isso pode chamar a atenção dos caçadores...");
        for (UUID uid : hunters) {
            Player hunter = Bukkit.getPlayer(uid);
            if (hunter != null) {
                ChatUtils.sendMessage(hunter, "&e⚠ Um prop provocou em algum lugar! Ouça com atenção!");
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (state != GameState.IN_GAME) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player victim = (Player) event.getEntity();
        if (!players.contains(victim)) return;

        // Verificar se é prop sendo atingido por caçador (arco ou corpo a corpo)
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            if (hunters.contains(attacker.getUniqueId()) && props.contains(victim.getUniqueId()) && !found.contains(victim.getUniqueId())) {
                event.setCancelled(true);
                foundProp(victim, attacker);
                return;
            }
        }
        // Flecha
        if (event.getDamager() instanceof org.bukkit.entity.Arrow) {
            org.bukkit.entity.Arrow arrow = (org.bukkit.entity.Arrow) event.getDamager();
            if (arrow.getShooter() instanceof Player) {
                Player shooter = (Player) arrow.getShooter();
                if (hunters.contains(shooter.getUniqueId()) && props.contains(victim.getUniqueId()) && !found.contains(victim.getUniqueId())) {
                    event.setCancelled(true);
                    foundProp(victim, shooter);
                }
            }
        }
        // Props não se machucam entre si
        if (props.contains(victim.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    private void foundProp(Player prop, Player hunter) {
        found.add(prop.getUniqueId());
        chosenProp.remove(prop.getUniqueId());

        String propName = prop.getInventory().getItemInMainHand() != null
            ? prop.getInventory().getItemInMainHand().getType().name() : "?";

        broadcastToPlayers(ChatUtils.color("&c" + prop.getName() + " &7foi encontrado por &e" + hunter.getName() +
            "! &7Props restantes: &b" + (props.size() - found.size())));

        prop.getWorld().spawnParticle(Particle.EXPLOSION, prop.getLocation(), 5);
        prop.getWorld().playSound(prop.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1f);

        ChatUtils.sendTitle(prop, "&c&lENCONTRADO!", "&7" + hunter.getName() + " te achou!", 10, 40, 10);
        prop.setGameMode(GameMode.SPECTATOR);

        // Verificar vitória dos props
        if (found.size() >= props.size()) {
            // Todos encontrados — caçadores vencem
            broadcastToPlayers(ChatUtils.color("&c&l✦ OS CAÇADORES VENCERAM! ✦ &7Todos os props foram encontrados!"));
            Player winner = Bukkit.getPlayer(hunters.iterator().next());
            endGame(winner);
        }
    }

    @Override
    protected Player getLeadingPlayer() {
        if (!hunters.isEmpty()) return Bukkit.getPlayer(hunters.iterator().next());
        return props.stream().filter(uid -> !found.contains(uid)).map(Bukkit::getPlayer)
            .filter(Objects::nonNull).findFirst().orElse(null);
    }

    @Override
    protected void endGame(Player winner) {
        // Revelar posições de props sobreviventes
        for (UUID uid : props) {
            if (!found.contains(uid)) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    Material m = chosenProp.getOrDefault(uid, Material.STONE);
                    broadcastToPlayers(ChatUtils.color("&a" + p.getName() + " &7sobreviveu como &e" +
                        m.name().replace("_", " ").toLowerCase() + "&7!"));
                    // Props sobreviventes vencem
                    if (winner == null) winner = p;
                }
            }
        }
        if (found.size() < props.size()) {
            broadcastToPlayers(ChatUtils.color("&b&l✦ OS PROPS SOBREVIVERAM! ✦ &7Parabéns aos escondidos!"));
        }
        super.endGame(winner);
    }

    @Override
    public void onEnd(Player winner) {
        if (radarTask != null) radarTask.cancel();
        if (blindTask != null) blindTask.cancel();
        hunters.clear();
        props.clear();
        found.clear();
        chosenProp.clear();
        lastTauntTime.clear();
        transformCooldown.clear();
        for (Player p : players) p.setGameMode(GameMode.ADVENTURE);
    }

    @Override
    public void onPlayerDeath(Player player) {
        if (props.contains(player.getUniqueId())) foundProp(player, null);
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&b&lBem-vindo ao Prop Hunt! &7Aguardando início...");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uid = player.getUniqueId();
        found.add(uid);
        props.remove(uid);
        hunters.remove(uid);
        chosenProp.remove(uid);
        if (state == GameState.IN_GAME) {
            if (hunters.isEmpty()) {
                broadcastToPlayers(ChatUtils.color("&aTodos os caçadores saíram! Props vencem!"));
                endGame(props.stream().filter(p -> !found.contains(p)).map(Bukkit::getPlayer)
                    .filter(Objects::nonNull).findFirst().orElse(null));
            } else if (found.size() >= props.size()) {
                broadcastToPlayers(ChatUtils.color("&cTodos os props foram eliminados! Caçadores vencem!"));
                endGame(Bukkit.getPlayer(hunters.iterator().next()));
            }
        }
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return world != null ? world.getSpawnLocation() : player.getLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&b&lProp Hunt"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        UUID uid = player.getUniqueId();
        boolean isHunter = hunters.contains(uid);
        lines.add("&7Papel: " + (isHunter ? "&cCaçador" : "&bProp"));
        lines.add("&7Props restantes: &b" + (props.size() - found.size()) + "&7/&b" + props.size());
        if (!isHunter && chosenProp.containsKey(uid)) {
            lines.add("&7Disfarce: &e" + chosenProp.get(uid).name().replace("_", " ").toLowerCase());
        }
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.prophunt.world", "minigame_prophunt");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.NORMAL);
            world = creator.createWorld();
            if (world != null) {
                world.setDifficulty(Difficulty.PEACEFUL);
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.SHOW_DEATH_MESSAGES, false);
            }
        }
        return world;
    }
}
