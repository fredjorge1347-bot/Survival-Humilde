package com.minigamehub.minigames.murdermystery;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Murder Mystery — Um assassino oculto, um detetive e inocentes.
 * - Assassino: elimina inocentes com a faca secreta.
 * - Detetive: tem um arco para eliminar o assassino.
 * - Inocentes: coletam ouro para comprar um arco e revidar.
 */
public class MurderMysteryGame extends MiniGame implements Listener {

    // Roles
    private UUID murdererUUID;
    private UUID detectiveUUID;
    private final Set<UUID> innocents = new HashSet<>();
    private final Set<UUID> dead = new HashSet<>();

    // Gold tracking (inocentes coletam ouro para comprar arco)
    private final Map<UUID, Integer> goldCount = new HashMap<>();
    private static final int GOLD_TO_BOW = 10;

    // Gold spawn task
    private BukkitTask goldTask;

    // Items especiais
    private static final ItemStack MURDER_KNIFE;
    private static final ItemStack DETECTIVE_BOW;
    private static final ItemStack GOLD_COIN;

    static {
        MURDER_KNIFE = new ItemStack(Material.IRON_SWORD);
        ItemMeta knifeMeta = MURDER_KNIFE.getItemMeta();
        if (knifeMeta != null) {
            knifeMeta.setDisplayName(ChatUtils.color("&c&lFaca do Assassino"));
            knifeMeta.setLore(Collections.singletonList(ChatUtils.color("&7Elimine os inocentes sem ser pego!")));
            MURDER_KNIFE.setItemMeta(knifeMeta);
        }

        DETECTIVE_BOW = new ItemStack(Material.BOW);
        ItemMeta bowMeta = DETECTIVE_BOW.getItemMeta();
        if (bowMeta != null) {
            bowMeta.setDisplayName(ChatUtils.color("&b&lArco do Detetive"));
            bowMeta.setLore(Collections.singletonList(ChatUtils.color("&7Encontre e elimine o assassino!")));
            DETECTIVE_BOW.setItemMeta(bowMeta);
        }

        GOLD_COIN = new ItemStack(Material.GOLD_NUGGET);
        ItemMeta goldMeta = GOLD_COIN.getItemMeta();
        if (goldMeta != null) {
            goldMeta.setDisplayName(ChatUtils.color("&6Moeda de Ouro"));
            goldMeta.setLore(Arrays.asList(
                ChatUtils.color("&7Colete &e" + GOLD_TO_BOW + " &7para ganhar um arco!"),
                ChatUtils.color("&7Clique com botão direito para resgatar.")
            ));
            GOLD_COIN.setItemMeta(goldMeta);
        }
    }

    public MurderMysteryGame(MinigameHub plugin) {
        super(plugin, "murdermystery");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        assignRoles();
        giveItems();
        startGoldSpawner();

        for (Player p : players) {
            p.setGameMode(GameMode.ADVENTURE);
            p.setHealth(20);
            p.setFoodLevel(20);
        }
    }

    private void assignRoles() {
        List<Player> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);

        // Assassino
        Player murderer = shuffled.get(0);
        murdererUUID = murderer.getUniqueId();

        // Detetive
        Player detective = shuffled.get(1);
        detectiveUUID = detective.getUniqueId();

        // Inocentes
        for (int i = 2; i < shuffled.size(); i++) {
            innocents.add(shuffled.get(i).getUniqueId());
        }

        // Notificar cada um em privado
        ChatUtils.sendTitle(murderer, "&c&lASSASSINO", "&7Elimine todos sem ser descoberto!", 10, 60, 10);
        ChatUtils.sendMessage(murderer, "&c&l[SECRETO] &cVocê é o ASSASSINO! Use sua faca sem ser visto.");
        murderer.playSound(murderer.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1f);

        ChatUtils.sendTitle(detective, "&b&lDETETIVE", "&7Encontre o assassino!", 10, 60, 10);
        ChatUtils.sendMessage(detective, "&b&l[SECRETO] &bVocê é o DETETIVE! Use seu arco para eliminar o assassino.");
        detective.playSound(detective.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);

        for (UUID uid : innocents) {
            Player innocent = Bukkit.getPlayer(uid);
            if (innocent != null) {
                ChatUtils.sendTitle(innocent, "&a&lINOCENTE", "&7Sobreviva e ajude a pegar o assassino!", 10, 60, 10);
                ChatUtils.sendMessage(innocent, "&a&l[SECRETO] &aVocê é INOCENTE! Colete ouro para comprar um arco.");
                innocent.playSound(innocent.getLocation(), Sound.ENTITY_VILLAGER_AMBIENT, 1f, 1f);
            }
        }

        broadcastToPlayers(ChatUtils.color("&7Os papéis foram distribuídos! &eDescubra quem é o assassino!"));
    }

    private void giveItems() {
        Player murderer = Bukkit.getPlayer(murdererUUID);
        if (murderer != null) {
            murderer.getInventory().addItem(MURDER_KNIFE.clone());
        }

        Player detective = Bukkit.getPlayer(detectiveUUID);
        if (detective != null) {
            detective.getInventory().addItem(DETECTIVE_BOW.clone());
            detective.getInventory().addItem(new ItemStack(Material.ARROW, 1));
        }

        for (UUID uid : innocents) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) {
                goldCount.put(uid, 0);
            }
        }
        goldCount.put(murdererUUID, 0);
    }

    private void startGoldSpawner() {
        // A cada 15 segundos, dar uma moeda de ouro a inocentes vivos
        goldTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { goldTask.cancel(); return; }
            for (UUID uid : innocents) {
                if (dead.contains(uid)) continue;
                Player p = Bukkit.getPlayer(uid);
                if (p != null && p.isOnline()) {
                    int current = goldCount.getOrDefault(uid, 0);
                    goldCount.put(uid, current + 1);
                    p.getInventory().addItem(GOLD_COIN.clone());
                    p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
                    int need = GOLD_TO_BOW - (current + 1);
                    if (need > 0) {
                        ChatUtils.sendMessage(p, "&6+1 moeda de ouro! &7Faltam &e" + need + " &7para o arco.");
                    }
                }
            }
        }, 300L, 300L); // A cada 15 segundos
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        // Inocente troca ouro por arco
        UUID uid = player.getUniqueId();
        if (innocents.contains(uid) && !dead.contains(uid)) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.GOLD_NUGGET) {
                int gold = countGoldInInventory(player);
                if (gold >= GOLD_TO_BOW) {
                    // Remove ouro e dá arco
                    removeGoldFromInventory(player, GOLD_TO_BOW);
                    player.getInventory().addItem(new ItemStack(Material.BOW));
                    player.getInventory().addItem(new ItemStack(Material.ARROW, 3));
                    goldCount.put(uid, 0);
                    ChatUtils.sendMessage(player, "&a&lVocê comprou um arco! &eVá atrás do assassino!");
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                    broadcastToPlayers(ChatUtils.color("&e" + player.getName() + " &acomprou um arco com ouro!"));
                }
            }
        }
    }

    private int countGoldInInventory(Player player) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == Material.GOLD_NUGGET) {
                count += item.getAmount();
            }
        }
        return count;
    }

    private void removeGoldFromInventory(Player player, int amount) {
        int remaining = amount;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == Material.GOLD_NUGGET && remaining > 0) {
                if (item.getAmount() <= remaining) {
                    remaining -= item.getAmount();
                    item.setType(Material.AIR);
                } else {
                    item.setAmount(item.getAmount() - remaining);
                    remaining = 0;
                }
            }
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!players.contains(victim)) return;

        event.setDeathMessage(null);
        event.getDrops().clear();

        UUID victimId = victim.getUniqueId();
        Player killer = victim.getKiller();

        dead.add(victimId);

        if (victimId.equals(murdererUUID)) {
            // Assassino foi eliminado!
            broadcastToPlayers(ChatUtils.color("&a&l✦ O ASSASSINO FOI DESCOBERTO! ✦"));
            broadcastToPlayers(ChatUtils.color("&a" + victim.getName() + " &7era o assassino!"));
            victim.sendMessage(ChatUtils.color("&c&lVocê foi descoberto e eliminado!"));

            // Inocentes e detetive vencem
            Player winner = killer != null ? killer : getAliveDetective();
            endGame(winner != null ? winner : getFirstAliveInnocent());
        } else {
            // Inocente ou detetive morreu
            String role = victimId.equals(detectiveUUID) ? "&bDETETIVE" : "&aINOCENTE";
            broadcastToPlayers(ChatUtils.color("&c" + victim.getName() + " &7(" + role + "&7) foi eliminado!"));

            if (victimId.equals(detectiveUUID)) {
                broadcastToPlayers(ChatUtils.color("&c&lO DETETIVE CAIU! &7Inocentes estão sozinhos..."));
                // Arco do detetive fica no chão para inocentes pegarem
                victim.getWorld().dropItemNaturally(victim.getLocation(), DETECTIVE_BOW.clone());
                victim.getWorld().dropItemNaturally(victim.getLocation(), new ItemStack(Material.ARROW, 1));
            }

            checkMurderWin();
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            victim.spigot().respawn();
        }, 20L);
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!players.contains(player)) return;
        // Mortos ficam como espectadores
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            player.setGameMode(GameMode.SPECTATOR);
            ChatUtils.sendMessage(player, "&7Você está eliminado. Aguarde o fim do jogo como espectador.");
        }, 5L);
    }

    private void checkMurderWin() {
        long aliveCount = players.stream()
            .filter(p -> !dead.contains(p.getUniqueId()))
            .count();

        // Assassino vence se matar todos
        if (aliveCount <= 1) {
            Player murderer = Bukkit.getPlayer(murdererUUID);
            broadcastToPlayers(ChatUtils.color("&c&l✦ O ASSASSINO GANHOU! ✦ &c" +
                (murderer != null ? murderer.getName() : "?") + " &7era o assassino!"));
            endGame(murderer);
        }
    }

    private Player getAliveDetective() {
        if (!dead.contains(detectiveUUID)) return Bukkit.getPlayer(detectiveUUID);
        return null;
    }

    private Player getFirstAliveInnocent() {
        for (UUID uid : innocents) {
            if (!dead.contains(uid)) return Bukkit.getPlayer(uid);
        }
        return null;
    }

    @Override
    public void onEnd(Player winner) {
        if (goldTask != null) goldTask.cancel();
        murdererUUID = null;
        detectiveUUID = null;
        innocents.clear();
        dead.clear();
        goldCount.clear();
    }

    @Override
    public void onPlayerDeath(Player player) { /* handled by event */ }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&6&lBem-vindo ao Murder Mystery! &7Aguardando mais jogadores...");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uid = player.getUniqueId();
        dead.add(uid);
        innocents.remove(uid);
        goldCount.remove(uid);
        if (state == GameState.IN_GAME) {
            if (uid.equals(murdererUUID)) {
                broadcastToPlayers(ChatUtils.color("&aO assassino saiu! &7Inocentes vencem!"));
                endGame(getFirstAliveInnocent());
            } else {
                checkMurderWin();
            }
        }
    }

    @Override
    protected void checkWinCondition() {
        checkMurderWin();
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return world != null ? world.getSpawnLocation() : player.getLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&c&lMurder Mystery"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        UUID uid = player.getUniqueId();
        String role;
        if (uid.equals(murdererUUID)) role = "&cAssassino";
        else if (uid.equals(detectiveUUID)) role = "&bDetetive";
        else role = "&aInocente";

        long alive = players.stream().filter(p -> !dead.contains(p.getUniqueId())).count();
        lines.add("&7Seu papel: " + role);
        lines.add("&7Vivos: &f" + alive + "&7/&f" + players.size());
        if (innocents.contains(uid)) {
            lines.add("&7Ouro: &6" + countGoldInInventory(player) + "&7/&6" + GOLD_TO_BOW);
        }
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.murdermystery.world", "minigame_murdermystery");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.NORMAL);
            world = creator.createWorld();
            if (world != null) {
                world.setDifficulty(Difficulty.PEACEFUL);
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setTime(6000);
                world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
                world.setGameRule(GameRule.SHOW_DEATH_MESSAGES, false);
                world.setGameRule(GameRule.KEEP_INVENTORY, true);
            }
        }
        return world;
    }
}
