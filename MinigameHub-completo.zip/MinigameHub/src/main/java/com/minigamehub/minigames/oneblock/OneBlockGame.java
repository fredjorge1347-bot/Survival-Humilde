package com.minigamehub.minigames.oneblock;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * One Block — cada jogador tem um bloco que se regenera.
 * O objetivo é sobreviver e construir o máximo possível.
 */
public class OneBlockGame extends MiniGame implements Listener {

    // Fases do OneBlock (ciclo de materiais)
    private static final Material[][] PHASES = {
        // Fase 1 - Básico
        { Material.GRASS_BLOCK, Material.DIRT, Material.OAK_LOG, Material.OAK_LOG,
          Material.STONE, Material.GRAVEL, Material.SAND, Material.OAK_SAPLING },
        // Fase 2 - Mineração
        { Material.STONE, Material.COBBLESTONE, Material.COAL_ORE, Material.IRON_ORE,
          Material.GOLD_ORE, Material.SAND, Material.GRAVEL, Material.OBSIDIAN },
        // Fase 3 - Nether
        { Material.NETHERRACK, Material.SOUL_SAND, Material.NETHER_BRICK,
          Material.GLOWSTONE, Material.NETHER_QUARTZ_ORE, Material.BLAZE_ROD },
        // Fase 4 - End/Especial
        { Material.END_STONE, Material.PURPUR_BLOCK, Material.DIAMOND_ORE,
          Material.EMERALD_ORE, Material.ELYTRA, Material.DIAMOND_BLOCK }
    };

    private final Map<UUID, Location> playerBlocks = new HashMap<>();
    private final Map<UUID, Integer> blockCount = new HashMap<>();
    private final Map<UUID, Integer> playerPoints = new HashMap<>();
    private final Random random = new Random();
    private BukkitTask regenerateTask;

    public OneBlockGame(MinigameHub plugin) {
        super(plugin, "oneblock");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        int index = 0;
        World world = getOrCreateWorld();

        for (Player p : players) {
            // Cada jogador começa em uma plataforma separada
            double offsetX = index * 30;
            Location spawnLoc = new Location(world, offsetX + 0.5, 100, 0.5);
            Location blockLoc = new Location(world, offsetX, 99, 0);

            // Criar o bloco inicial
            blockLoc.getBlock().setType(Material.GRASS_BLOCK);
            playerBlocks.put(p.getUniqueId(), blockLoc);
            blockCount.put(p.getUniqueId(), 0);
            playerPoints.put(p.getUniqueId(), 0);

            p.teleport(spawnLoc);
            p.setGameMode(GameMode.SURVIVAL);
            p.setAllowFlight(false);

            // Itens iniciais
            p.getInventory().addItem(new ItemStack(Material.OAK_PICKAXE));
            p.getInventory().addItem(new ItemStack(Material.OAK_AXE));
            p.getInventory().addItem(new ItemStack(Material.OAK_SHOVEL));
            p.getInventory().addItem(new ItemStack(Material.BREAD, 8));

            ChatUtils.sendMessage(p, "&b&lOne Block &a- Quebre o bloco para obter recursos!");
            ChatUtils.sendMessage(p, "&7O bloco se regenera automaticamente em fases!");
            index++;
        }

        // Regenerar blocos a cada 3 segundos se quebrados
        regenerateTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, Location> entry : playerBlocks.entrySet()) {
                Block block = entry.getValue().getBlock();
                if (block.getType() == Material.AIR) {
                    block.setType(getNextBlockMaterial(entry.getKey()));
                }
            }
        }, 0L, 60L);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (state != GameState.IN_GAME) return;
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        UUID uuid = player.getUniqueId();
        Location blockLoc = playerBlocks.get(uuid);

        if (blockLoc != null && event.getBlock().getLocation().equals(blockLoc)) {
            event.setDropItems(false);
            int count = blockCount.getOrDefault(uuid, 0) + 1;
            blockCount.put(uuid, count);

            // Drop baseado na fase atual
            dropPhaseItems(player, count);

            // Pontos
            playerPoints.merge(uuid, 10, Integer::sum);

            // Mensagem de fase
            int phase = getPhase(count);
            if (count % 50 == 0) {
                ChatUtils.sendMessage(player, "&a✦ Bloco #" + count + " quebrado! Fase " + (phase + 1));
                ChatUtils.sendTitle(player, "&6Fase " + (phase + 1), "&eContinue progredindo!", 5, 30, 5);
            }
        }
    }

    private void dropPhaseItems(Player player, int blockCount) {
        int phase = getPhase(blockCount);
        Material[] phaseMats = PHASES[Math.min(phase, PHASES.length - 1)];
        Material mat = phaseMats[random.nextInt(phaseMats.length)];

        // Chance de mobs
        if (random.nextInt(10) == 0) {
            Location loc = player.getLocation();
            spawnMob(loc, phase);
        } else {
            // Drop item
            int amount = (random.nextInt(3) + 1);
            player.getWorld().dropItemNaturally(playerBlocks.get(player.getUniqueId()), new ItemStack(mat, amount));
        }
    }

    private void spawnMob(Location loc, int phase) {
        org.bukkit.entity.EntityType mob;
        switch (phase) {
            case 0: mob = org.bukkit.entity.EntityType.CHICKEN; break;
            case 1: mob = org.bukkit.entity.EntityType.ZOMBIE; break;
            case 2: mob = org.bukkit.entity.EntityType.BLAZE; break;
            default: mob = org.bukkit.entity.EntityType.ENDERMAN; break;
        }
        loc.getWorld().spawnEntity(loc, mob);
    }

    private int getPhase(int blockCount) {
        if (blockCount < 100) return 0;
        if (blockCount < 300) return 1;
        if (blockCount < 600) return 2;
        return 3;
    }

    private Material getNextBlockMaterial(UUID uuid) {
        int count = blockCount.getOrDefault(uuid, 0);
        int phase = getPhase(count);
        Material[] phaseMats = PHASES[Math.min(phase, PHASES.length - 1)];
        return phaseMats[random.nextInt(phaseMats.length)];
    }

    @Override
    public void onEnd(Player winner) {
        if (regenerateTask != null) regenerateTask.cancel();
        // Limpar blocos dos jogadores
        for (Location loc : playerBlocks.values()) {
            loc.getBlock().setType(Material.AIR);
        }
        playerBlocks.clear();
        blockCount.clear();
        playerPoints.clear();
    }

    @Override
    public void onPlayerDeath(Player player) {
        // No OneBlock, morte retorna ao spawn do bloco
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (players.contains(player)) {
                Location blockLoc = playerBlocks.get(player.getUniqueId());
                if (blockLoc != null) {
                    player.teleport(blockLoc.clone().add(0.5, 1, 0.5));
                    ChatUtils.sendMessage(player, "&cVocê morreu! Voltando ao seu bloco...");
                }
            }
        }, 40L);
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&b&lBem-vindo ao &fOne Block&b!");
    }

    @Override
    public void onPlayerLeave(Player player) {
        UUID uuid = player.getUniqueId();
        Location blockLoc = playerBlocks.remove(uuid);
        if (blockLoc != null) blockLoc.getBlock().setType(Material.AIR);
        blockCount.remove(uuid);
        playerPoints.remove(uuid);
    }

    @Override
    protected Player getLeadingPlayer() {
        return playerPoints.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(e -> Bukkit.getPlayer(e.getKey()))
                .filter(Objects::nonNull)
                .orElse(null);
    }

    @Override
    public Location getSpawnLocation(Player player) {
        World world = getOrCreateWorld();
        return new Location(world, 0.5, 100, 0.5);
    }

    @Override
    public String getScoreboardTitle() { return "&b&lOne Block"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        int count = blockCount.getOrDefault(player.getUniqueId(), 0);
        int points = playerPoints.getOrDefault(player.getUniqueId(), 0);
        int phase = getPhase(count) + 1;
        lines.add("&7Blocos: &f" + count);
        lines.add("&7Fase: &e" + phase);
        lines.add("&7Pontos: &a" + points);
        lines.add("");
        lines.add("&7Jogadores: &f" + players.size());
        lines.add("&7Tempo: &f" + ChatUtils.formatTime(gameTimer));
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.oneblock.world", "minigame_oneblock");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            creator.generatorSettings("{\"layers\":[{\"block\":\"air\",\"height\":1}],\"biome\":\"plains\"}");
            world = creator.createWorld();
            if (world != null) {
                world.setSpawnFlags(false, false);
                world.setDifficulty(Difficulty.NORMAL);
            }
        }
        return world;
    }
}
