package com.minigamehub.minigames;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public abstract class MiniGame {

    protected final MinigameHub plugin;
    protected final String id;
    protected final String displayName;
    protected GameState state;
    protected final List<Player> players;
    protected final int maxPlayers;
    protected final int minPlayers;
    protected int countdown;
    protected int gameTimer;
    protected BukkitTask countdownTask;
    protected BukkitTask gameTask;

    public MiniGame(MinigameHub plugin, String id) {
        this.plugin = plugin;
        this.id = id;
        this.displayName = plugin.getConfig().getString("minigames." + id + ".display-name", id);
        this.maxPlayers = plugin.getConfig().getInt("minigames." + id + ".max-players", 8);
        this.minPlayers = plugin.getConfig().getInt("minigames." + id + ".min-players", 2);
        this.countdown = plugin.getConfig().getInt("minigames." + id + ".lobby-countdown", 30);
        this.gameTimer = plugin.getConfig().getInt("minigames." + id + ".game-time", 1800);
        this.state = GameState.WAITING;
        this.players = new ArrayList<>();
    }

    // ── Métodos abstratos (cada minigame implementa) ──
    public abstract void onStart();
    public abstract void onEnd(Player winner);
    public abstract void onPlayerDeath(Player player);
    public abstract void onPlayerJoin(Player player);
    public abstract void onPlayerLeave(Player player);
    public abstract Location getSpawnLocation(Player player);
    public abstract String getScoreboardTitle();
    public abstract List<String> getScoreboardLines(Player player);

    // ── Lógica comum ──
    public boolean addPlayer(Player player) {
        if (state != GameState.WAITING && state != GameState.COUNTDOWN) {
            ChatUtils.sendMessage(player, "&cEsta partida já começou!");
            return false;
        }
        if (players.size() >= maxPlayers) {
            ChatUtils.sendMessage(player, "&cPartida cheia! (" + maxPlayers + "/" + maxPlayers + ")");
            return false;
        }
        players.add(player);
        player.teleport(getSpawnLocation(player));
        player.setGameMode(GameMode.ADVENTURE);
        player.getInventory().clear();
        player.setHealth(20);
        player.setFoodLevel(20);

        broadcastToPlayers(ChatUtils.color("&a" + player.getName() + " &eentrou! &7(" + players.size() + "/" + maxPlayers + ")"));
        onPlayerJoin(player);

        if (players.size() >= minPlayers && state == GameState.WAITING) {
            startCountdown();
        }
        if (players.size() >= maxPlayers && state == GameState.COUNTDOWN) {
            forceStart();
        }
        return true;
    }

    public void removePlayer(Player player) {
        players.remove(player);
        onPlayerLeave(player);

        if (state == GameState.IN_GAME) {
            broadcastToPlayers(ChatUtils.color("&c" + player.getName() + " &esaiu da partida. &7(" + players.size() + " restantes)"));
            checkWinCondition();
        } else if (state == GameState.COUNTDOWN && players.size() < minPlayers) {
            cancelCountdown();
        }
        plugin.getLobbyManager().sendToHub(player);
    }

    protected void startCountdown() {
        state = GameState.COUNTDOWN;
        final int[] timer = {countdown};

        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (timer[0] <= 0) {
                countdownTask.cancel();
                startGame();
                return;
            }
            if (timer[0] <= 5 || timer[0] % 10 == 0) {
                broadcastToPlayers(ChatUtils.color("&aPartida começa em &e" + timer[0] + " &asegundos!"));
                for (Player p : players) {
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                }
            }
            timer[0]--;
        }, 0L, 20L);
    }

    protected void cancelCountdown() {
        if (countdownTask != null) countdownTask.cancel();
        state = GameState.WAITING;
        broadcastToPlayers(ChatUtils.color("&cContagem cancelada. Aguardando mais jogadores... (" + minPlayers + " necessários)"));
    }

    protected void forceStart() {
        if (countdownTask != null) countdownTask.cancel();
        startGame();
    }

    protected void startGame() {
        state = GameState.IN_GAME;
        broadcastToPlayers(ChatUtils.color("&a&l✦ O JOGO COMEÇOU! ✦"));
        for (Player p : players) {
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1f);
            ChatUtils.sendTitle(p, "&a&lINÍCIO!", "&eBoa sorte!", 10, 40, 10);
        }
        onStart();
        startGameTimer();
    }

    protected void startGameTimer() {
        final int[] timer = {gameTimer};
        gameTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != GameState.IN_GAME) { gameTask.cancel(); return; }
            if (timer[0] <= 0) {
                gameTask.cancel();
                // Tempo esgotado: quem tiver mais pontos/vidas ganha
                endGame(getLeadingPlayer());
                return;
            }
            // Avisos de tempo
            if (timer[0] == 300 || timer[0] == 60 || timer[0] == 30 || timer[0] == 10) {
                broadcastToPlayers(ChatUtils.color("&eAtenção! &aRestam &e" + ChatUtils.formatTime(timer[0]) + " &ade jogo!"));
            }
            timer[0]--;
        }, 0L, 20L);
    }

    protected void endGame(Player winner) {
        if (state == GameState.ENDING) return;
        state = GameState.ENDING;
        if (gameTask != null) gameTask.cancel();

        String winnerName = winner != null ? winner.getName() : "Ninguém";
        broadcastToPlayers(ChatUtils.color("&6&l✦ FIM DE JOGO! ✦ &eVencedor: &a" + winnerName));

        for (Player p : players) {
            ChatUtils.sendTitle(p,
                    winner != null && p.equals(winner) ? "&6&lVITÓRIA!" : "&c&lDEROTA!",
                    "&eVencedor: &a" + winnerName, 10, 80, 10);
            p.playSound(p.getLocation(),
                    winner != null && p.equals(winner) ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_WITHER_DEATH,
                    1f, 1f);
        }

        if (winner != null) {
            plugin.getStatsManager().addWin(winner, id);
            onEnd(winner);
        }

        // Salvar stats de participação
        for (Player p : players) {
            plugin.getStatsManager().addGame(p, id);
        }

        // Retornar ao lobby após 5 segundos
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Player p : new ArrayList<>(players)) {
                plugin.getLobbyManager().sendToHub(p);
            }
            players.clear();
            state = GameState.WAITING;
        }, 100L);
    }

    protected Player getLeadingPlayer() {
        return players.isEmpty() ? null : players.get(0);
    }

    protected void checkWinCondition() {
        if (players.size() == 1) {
            endGame(players.get(0));
        } else if (players.isEmpty()) {
            endGame(null);
        }
    }

    public void broadcastToPlayers(String message) {
        for (Player p : players) p.sendMessage(message);
    }

    public void shutdown() {
        if (countdownTask != null) countdownTask.cancel();
        if (gameTask != null) gameTask.cancel();
        for (Player p : new ArrayList<>(players)) {
            plugin.getLobbyManager().sendToHub(p);
        }
        players.clear();
        state = GameState.WAITING;
    }

    // Getters
    public String getId() { return id; }
    public String getDisplayName() { return ChatUtils.color(displayName); }
    public GameState getState() { return state; }
    public List<Player> getPlayers() { return Collections.unmodifiableList(players); }
    public int getMaxPlayers() { return maxPlayers; }
    public int getMinPlayers() { return minPlayers; }
    public boolean isEnabled() { return plugin.getConfig().getBoolean("minigames." + id + ".enabled", true); }
}
