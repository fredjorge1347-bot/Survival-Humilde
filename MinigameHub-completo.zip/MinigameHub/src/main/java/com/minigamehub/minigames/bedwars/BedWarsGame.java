package com.minigamehub.minigames.bedwars;

import com.minigamehub.main.MinigameHub;
import com.minigamehub.minigames.MiniGame;
import com.minigamehub.utils.ChatUtils;
import com.minigamehub.utils.GameState;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * BedWars — destrua a cama inimiga e elimine todos os adversários.
 * 4 times: Vermelho, Azul, Verde, Amarelo.
 */
public class BedWarsGame extends MiniGame implements Listener {

    public enum Team {
        RED("Vermelho", ChatColor.RED, DyeColor.RED, new Location(null, 50, 65, 0)),
        BLUE("Azul", ChatColor.BLUE, DyeColor.BLUE, new Location(null, -50, 65, 0)),
        GREEN("Verde", ChatColor.GREEN, DyeColor.GREEN, new Location(null, 0, 65, 50)),
        YELLOW("Amarelo", ChatColor.YELLOW, DyeColor.YELLOW, new Location(null, 0, 65, -50));

        public final String name;
        public final ChatColor color;
        public final DyeColor dyeColor;
        public final Location relativeSpawn;

        Team(String name, ChatColor color, DyeColor dye, Location spawn) {
            this.name = name; this.color = color; this.dyeColor = dye; this.relativeSpawn = spawn;
        }
    }

    private final Map<UUID, Team> playerTeams = new HashMap<>();
    private final Set<Team> teamsWithBeds = new HashSet<>(Arrays.asList(Team.values()));
    private final Set<Team> eliminatedTeams = new HashSet<>();
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Map<UUID, Boolean> alive = new HashMap<>();
    private final Map<UUID, Location> bedLocations = new HashMap<>();
    private BukkitTask resourceTask;

    public BedWarsGame(MinigameHub plugin) {
        super(plugin, "bedwars");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void onStart() {
        World world = getOrCreateWorld();
        assignTeams(world);
        setupBeds(world);
        setupResourceGenerators(world);

        for (Player p : players) {
            Team team = playerTeams.get(p.getUniqueId());
            teleportToTeamSpawn(p, team, world);
            giveStartItems(p, team);
            alive.put(p.getUniqueId(), true);
            p.setGameMode(GameMode.SURVIVAL);
            ChatUtils.sendMessage(p, team.color + "✦ Você está no time " + team.name + "!");
            ChatUtils.sendMessage(p, "&7Destrua as camas inimigas e elimine todos!");
        }

        // Gerar recursos a cada 10 segundos
        resourceTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> generateResources(world), 0L, 200L);
    }

    private void assignTeams(World world) {
        Team[] teamValues = Team.values();
        int teamIndex = 0;
        for (Player p : players) {
            playerTeams.put(p.getUniqueId(), teamValues[teamIndex % teamValues.length]);
            kills.put(p.getUniqueId(), 0);
            teamIndex++;
        }
    }

    private void setupBeds(World world) {
        for (Team team : Team.values()) {
            Location bedLoc = getTeamBedLocation(team, world);
            bedLoc.getBlock().setType(Material.RED_BED);
            // Segundo bloco da cama
            bedLoc.clone().add(1, 0, 0).getBlock().setType(Material.RED_BED);
        }
    }

    private void teleportToTeamSpawn(Player p, Team team, World world) {
        Location spawn = getTeamSpawn(team, world);
        p.teleport(spawn);
    }

    private Location getTeamSpawn(Team team, World world) {
        return new Location(world,
            team.relativeSpawn.getX() + 0.5,
            team.relativeSpawn.getY(),
            team.relativeSpawn.getZ() + 0.5);
    }

    private Location getTeamBedLocation(Team team, World world) {
        return new Location(world,
            team.relativeSpawn.getX(),
            team.relativeSpawn.getY() - 1,
            team.relativeSpawn.getZ());
    }

    private void giveStartItems(Player player, Team team) {
        player.getInventory().clear();
        player.getInventory().addItem(new ItemStack(Material.WOODEN_SWORD));
        player.getInventory().addItem(new ItemStack(Material.WOODEN_PICKAXE));
        player.getInventory().addItem(new ItemStack(Material.OAK_PLANKS, 16));
        player.getInventory().addItem(new ItemStack(Material.BREAD, 8));

        // Armadura colorida do time
        giveTeamArmor(player, team);
    }

    private void giveTeamArmor(Player player, Team team) {
        ItemStack helmet = new ItemStack(Material.LEATHER_HELMET);
        ItemStack chestplate = new ItemStack(Material.LEATHER_CHESTPLATE);
        ItemStack leggings = new ItemStack(Material.LEATHER_LEGGINGS);
        ItemStack boots = new ItemStack(Material.LEATHER_BOOTS);

        Color armorColor = getTeamColor(team);
        for (ItemStack item : new ItemStack[]{helmet, chestplate, leggings, boots}) {
            LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
            if (meta != null) { meta.setColor(armorColor); item.setItemMeta(meta); }
        }
        player.getInventory().setHelmet(helmet);
        player.getInventory().setChestplate(chestplate);
        player.getInventory().setLeggings(leggings);
        player.getInventory().setBoots(boots);
    }

    private Color getTeamColor(Team team) {
        switch (team) {
            case RED: return Color.RED;
            case BLUE: return Color.BLUE;
            case GREEN: return Color.GREEN;
            case YELLOW: return Color.YELLOW;
            default: return Color.WHITE;
        }
    }

    private void generateResources(World world) {
        // Gerar ferro e ouro no centro das ilhas
        for (Team team : Team.values()) {
            if (eliminatedTeams.contains(team)) continue;
            Location center = getTeamSpawn(team, world);
            world.dropItemNaturally(center, new ItemStack(Material.IRON_INGOT, 4));
            world.dropItemNaturally(center, new ItemStack(Material.GOLD_INGOT, 1));
        }
        // Centro: gerar diamantes
        Location centerMap = new Location(world, 0.5, 65, 0.5);
        world.dropItemNaturally(centerMap, new ItemStack(Material.DIAMOND, 1));
    }

    private void setupResourceGenerators(World world) {
        // Geradores de recursos no centro do mapa
        Location center = new Location(world, 0, 65, 0);
        center.getBlock().setType(Material.GOLD_BLOCK);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!players.contains(victim)) return;

        event.setDeathMessage(null);
        Team victimTeam = playerTeams.get(victim.getUniqueId());

        Player killer = victim.getKiller();
        if (killer != null && players.contains(killer)) {
            kills.merge(killer.getUniqueId(), 1, Integer::sum);
            Team killerTeam = playerTeams.get(killer.getUniqueId());
            broadcastToPlayers(ChatUtils.color(killerTeam.color + killer.getName()
                + " &7eliminou " + victimTeam.color + victim.getName()));
        }

        // Tem cama? Respawn. Sem cama? Eliminado.
        if (teamsWithBeds.contains(victimTeam)) {
            alive.put(victim.getUniqueId(), false);
            broadcastToPlayers(ChatUtils.color(victimTeam.color + victim.getName() + " &7vai renascer em &e5 segundos..."));
        } else {
            alive.put(victim.getUniqueId(), false);
            broadcastToPlayers(ChatUtils.color(victimTeam.color + victim.getName()
                + " &7foi &celiminar&7! Sem cama para renascer!"));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                removePlayer(victim);
                checkTeamElimination(victimTeam);
            }, 40L);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!players.contains(player)) return;

        Team team = playerTeams.get(player.getUniqueId());
        World world = getOrCreateWorld();
        event.setRespawnLocation(getTeamSpawn(team, world));
        alive.put(player.getUniqueId(), true);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            giveStartItems(player, team);
            ChatUtils.sendMessage(player, "&aVocê renasceu! Sua cama te protegeu!");
        }, 5L);
    }

    private void checkTeamElimination(Team team) {
        boolean anyAlive = playerTeams.entrySet().stream()
            .filter(e -> e.getValue() == team)
            .anyMatch(e -> players.stream().anyMatch(p -> p.getUniqueId().equals(e.getKey())));

        if (!anyAlive) {
            eliminatedTeams.add(team);
            broadcastToPlayers(ChatUtils.color(team.color + "Time " + team.name + " &7foi eliminado!"));
        }

        // Verificar se só tem um time
        long activeTeams = Arrays.stream(Team.values())
            .filter(t -> !eliminatedTeams.contains(t))
            .filter(t -> playerTeams.values().contains(t))
            .count();

        if (activeTeams <= 1) {
            endGame(getLeadingPlayer());
        }
    }

    @Override
    public void onPlayerDeath(Player player) { /* handled by event */ }

    @Override
    public void onEnd(Player winner) {
        if (resourceTask != null) resourceTask.cancel();
        // Limpar mundo
        playerTeams.clear();
        teamsWithBeds.clear();
        teamsWithBeds.addAll(Arrays.asList(Team.values()));
        eliminatedTeams.clear();
        kills.clear();
        alive.clear();
    }

    @Override
    public void onPlayerJoin(Player player) {
        ChatUtils.sendMessage(player, "&c&lBem-vindo ao &fBed Wars&c!");
        ChatUtils.sendMessage(player, "&7Aguardando times serem formados...");
    }

    @Override
    public void onPlayerLeave(Player player) {
        Team team = playerTeams.remove(player.getUniqueId());
        kills.remove(player.getUniqueId());
        alive.remove(player.getUniqueId());
        if (team != null && state == GameState.IN_GAME) {
            checkTeamElimination(team);
        }
    }

    @Override
    protected Player getLeadingPlayer() {
        return kills.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(e -> Bukkit.getPlayer(e.getKey()))
            .filter(Objects::nonNull)
            .orElse(players.isEmpty() ? null : players.get(0));
    }

    @Override
    public Location getSpawnLocation(Player player) {
        return getOrCreateWorld().getSpawnLocation();
    }

    @Override
    public String getScoreboardTitle() { return "&c&lBed Wars"; }

    @Override
    public List<String> getScoreboardLines(Player player) {
        List<String> lines = new ArrayList<>();
        Team myTeam = playerTeams.get(player.getUniqueId());
        for (Team t : Team.values()) {
            boolean bedAlive = teamsWithBeds.contains(t);
            boolean eliminated = eliminatedTeams.contains(t);
            String status = eliminated ? "&8Eliminado" : (bedAlive ? "&a✔ Cama" : "&c✖ Sem cama");
            String indicator = (myTeam == t) ? " &7(você)" : "";
            lines.add(t.color + t.name + "&7: " + status + indicator);
        }
        lines.add("");
        lines.add("&7Kills: &f" + kills.getOrDefault(player.getUniqueId(), 0));
        lines.add("&7Jogadores: &f" + players.size());
        return lines;
    }

    private World getOrCreateWorld() {
        String worldName = plugin.getConfig().getString("minigames.bedwars.world", "minigame_bedwars");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            creator.generatorSettings("{\"layers\":[{\"block\":\"air\",\"height\":1}],\"biome\":\"plains\"}");
            world = creator.createWorld();
            if (world != null) {
                world.setSpawnFlags(false, false);
                world.setDifficulty(Difficulty.NORMAL);
                world.setTime(6000); // Dia permanente
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            }
        }
        return world;
    }
}
