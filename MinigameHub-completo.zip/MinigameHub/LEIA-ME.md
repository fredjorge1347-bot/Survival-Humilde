# 🎮 MinigameHub Plugin

Plugin completo de Hub + Minigames para Minecraft 1.20.1 (Spigot/Paper).

## ✨ Minigames incluídos

### 🟦 One Block
- Cada jogador começa em uma plataforma com 1 bloco mágico
- O bloco se regenera ao ser quebrado, com novos materiais
- 4 fases progressivas: Grama → Pedra → Nether → End
- Mobs spawnados aleatoriamente conforme a fase
- Vence quem tiver mais pontos quando o tempo acabar

### 🔴 Bed Wars
- 4 times: Vermelho, Azul, Verde, Amarelo
- Destrua a cama inimiga para impedir respawn
- Geradores de ferro, ouro e diamante
- Armadura colorida por time
- Sistema de kills e respawn

### 🟡 Sky Wars
- Ilhas flutuantes com baús de loot (3 níveis de raridade)
- Ilha central com loot épico
- Borda que se fecha a cada 60 segundos
- Último sobrevivente vence

## 📦 Como instalar

### Pré-requisitos
- Java 17+
- Spigot ou PaperMC 1.20.1
- Maven 3.6+

### Compilar
```bash
cd MinigameHub
mvn clean package
```
O .jar gerado estará em `target/MinigameHub-1.0.0.jar`

### Instalar
1. Copie `MinigameHub-1.0.0.jar` para a pasta `plugins/` do seu servidor
2. Reinicie o servidor
3. Configure o `plugins/MinigameHub/config.yml`
4. Use `/sethub` no spawn do lobby

## 🎮 Comandos

| Comando | Descrição |
|---------|-----------|
| `/hub` ou `/lobby` | Volta para o lobby |
| `/minigames` ou `/mg` | Abre o menu de minigames |
| `/stats [jogador]` | Ver estatísticas |
| `/sethub` | Define spawn do hub (admin) |
| `/startgame <id>` | Inicia jogo manualmente (admin) |

## 🔑 Permissões

| Permissão | Descrição | Padrão |
|-----------|-----------|--------|
| `minigamehub.admin` | Acesso admin | OP |
| `minigamehub.play` | Jogar minigames | Todos |

## ⚙️ Como usar no servidor

1. Entre no servidor → teleportado automaticamente ao lobby
2. Clique na **bússola** ou use `/minigames` para abrir o menu
3. Clique no minigame desejado para entrar na fila
4. Aguarde o mínimo de jogadores e o jogo começa!

## 🗂️ Estrutura de arquivos

```
plugins/MinigameHub/
├── config.yml          # Configurações gerais
└── stats.yml           # Estatísticas dos jogadores
```

## 💡 Dicas de configuração

No `config.yml` você pode ajustar:
- Número máximo/mínimo de jogadores por jogo
- Tempo da contagem regressiva
- Duração do jogo
- Mensagens personalizadas
- Ativar/desativar minigames
