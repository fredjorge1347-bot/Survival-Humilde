package com.survivalhumilde.bounty;

import com.survivalhumilde.PlusMain;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.*;

public class BountyManager {

    private final PlusMain plugin;
    // UUID alvo -> valor total da recompensa
    private final Map<UUID, Double> bounties = new HashMap<>();
    // UUID alvo -> nome
    private final Map<UUID, String> bountyNames = new HashMap<>();

    public BountyManager(PlusMain plugin) { this.plugin = plugin; }

    public boolean addBounty(Player placer, Player target, double amount) {
        double min = plugin.getConfig().getDouble("bounty.min-value", 50.0);
        if (amount < min) {
            placer.sendMessage(ChatColor.RED + "Recompensa minima: " + plugin.getEconomyStr(min));
            return false;
        }
        if (!plugin.hasBalance(placer, amount)) {
            placer.sendMessage(ChatColor.RED + "Saldo insuficiente!");
            return false;
        }
        if (target.equals(placer)) {
            placer.sendMessage(ChatColor.RED + "Voce nao pode colocar recompensa em si mesmo!");
            return false;
        }

        plugin.withdraw(placer, amount);
        UUID targetUuid = target.getUniqueId();
        bounties.merge(targetUuid, amount, Double::sum);
        bountyNames.put(targetUuid, target.getName());

        Bukkit.broadcastMessage(ChatColor.RED + "[Recompensa] " + ChatColor.YELLOW + placer.getName()
                + ChatColor.WHITE + " colocou " + ChatColor.GREEN + plugin.getEconomyStr(amount)
                + ChatColor.WHITE + " na cabeca de " + ChatColor.RED + target.getName() + "!");

        return true;
    }

    public void claimBounty(Player killer, Player victim) {
        UUID victimUuid = victim.getUniqueId();
        if (!bounties.containsKey(victimUuid)) return;

        double reward = bounties.remove(victimUuid);
        bountyNames.remove(victimUuid);

        plugin.deposit(killer, reward);
        killer.sendMessage(ChatColor.GREEN + "Voce coletou a recompensa de "
                + plugin.getEconomyStr(reward) + " por matar " + victim.getName() + "!");
        Bukkit.broadcastMessage(ChatColor.RED + "[Recompensa] " + ChatColor.YELLOW + killer.getName()
                + ChatColor.WHITE + " coletou " + ChatColor.GREEN + plugin.getEconomyStr(reward)
                + ChatColor.WHITE + " por eliminar " + ChatColor.RED + victim.getName() + "!");
    }

    public double getBounty(UUID uuid) { return bounties.getOrDefault(uuid, 0.0); }
    public boolean hasBounty(UUID uuid) { return bounties.containsKey(uuid); }
    public Map<UUID, Double> getAllBounties() { return Collections.unmodifiableMap(bounties); }
    public String getName(UUID uuid) { return bountyNames.getOrDefault(uuid, "Desconhecido"); }
}
