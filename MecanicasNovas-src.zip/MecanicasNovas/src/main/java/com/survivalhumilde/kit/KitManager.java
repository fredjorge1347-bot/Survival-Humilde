package com.survivalhumilde.kit;

import com.survivalhumilde.PlusMain;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class KitManager {

    private final PlusMain plugin;
    private final Set<UUID> claimed = new HashSet<>();
    private File dataFile;
    private FileConfiguration dataCfg;

    public KitManager(PlusMain plugin) {
        this.plugin = plugin;
        loadData();
    }

    public boolean giveKit(Player player) {
        if (claimed.contains(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Voce ja pegou o kit de iniciante!");
            return false;
        }

        // Itens do kit
        ItemStack[] kit = {
            new ItemStack(Material.STONE_PICKAXE),
            new ItemStack(Material.STONE_AXE),
            new ItemStack(Material.STONE_SWORD),
            new ItemStack(Material.STONE_SHOVEL),
            new ItemStack(Material.BREAD, 16),
            new ItemStack(Material.OAK_LOG, 32),
            new ItemStack(Material.TORCH, 16),
            new ItemStack(Material.CRAFTING_TABLE),
            new ItemStack(Material.FURNACE),
        };

        for (ItemStack item : kit) {
            player.getInventory().addItem(item);
        }

        // Dar 100 moedas iniciais
        plugin.deposit(player, 100.0);

        claimed.add(player.getUniqueId());
        saveData();

        player.sendMessage(ChatColor.GREEN + "=== Kit de Iniciante ===");
        player.sendMessage(ChatColor.YELLOW + "Voce recebeu ferramentas de pedra, comida e mais!");
        player.sendMessage(ChatColor.GOLD + "+100 moedas de boas-vindas!");
        player.sendMessage(ChatColor.GRAY + "Boa sorte na sua aventura!");
        return true;
    }

    public boolean hasClaimed(UUID uuid) { return claimed.contains(uuid); }

    private void loadData() {
        dataFile = new File(plugin.getDataFolder(), "kit.yml");
        dataCfg = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : dataCfg.getKeys(false)) {
            try { claimed.add(UUID.fromString(key)); } catch (Exception ignored) {}
        }
    }

    private void saveData() {
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            claimed.forEach(uuid -> dataCfg.set(uuid.toString(), true));
            try { dataCfg.save(dataFile); }
            catch (IOException e) { plugin.getLogger().warning("Erro ao salvar kit: " + e.getMessage()); }
        });
    }
}
