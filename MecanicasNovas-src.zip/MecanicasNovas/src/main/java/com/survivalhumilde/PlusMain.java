package com.survivalhumilde;

import com.survivalhumilde.auction.AuctionManager;
import com.survivalhumilde.bounty.BountyManager;
import com.survivalhumilde.boss.BossManager;
import com.survivalhumilde.commands.PlusCommands;
import com.survivalhumilde.house.HouseManager;
import com.survivalhumilde.kit.KitManager;
import com.survivalhumilde.level.LevelManager;
import com.survivalhumilde.listeners.PlusListener;
import com.survivalhumilde.mail.MailManager;
import com.survivalhumilde.treasure.TreasureManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class PlusMain extends JavaPlugin {

    private static PlusMain instance;
    private Economy economy;

    private AuctionManager auctionManager;
    private BountyManager bountyManager;
    private BossManager bossManager;
    private HouseManager houseManager;
    private KitManager kitManager;
    private LevelManager levelManager;
    private MailManager mailManager;
    private TreasureManager treasureManager;

    // Estado temporário
    private final Map<UUID, Double> pendingHousePrices = new HashMap<>();
    private final Set<UUID> pendingHouseBuys = new HashSet<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        if (!setupEconomy()) {
            getLogger().severe("Vault nao encontrado! Desativando SurvivalPlus.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Inicializar sistemas
        levelManager    = new LevelManager(this);
        auctionManager  = new AuctionManager(this);
        bountyManager   = new BountyManager(this);
        bossManager     = new BossManager(this);
        houseManager    = new HouseManager(this);
        kitManager      = new KitManager(this);
        mailManager     = new MailManager(this);
        treasureManager = new TreasureManager(this);

        // Registrar listener
        getServer().getPluginManager().registerEvents(new PlusListener(this), this);

        // Registrar comandos
        getCommand("leilao").setExecutor(new PlusCommands.LeilaoCommand(this));
        getCommand("lances").setExecutor(new PlusCommands.LancesCommand(this));
        getCommand("lance").setExecutor(new PlusCommands.LanceCommand(this));
        getCommand("bounty").setExecutor(new PlusCommands.BountyCommand(this));
        getCommand("bounties").setExecutor(new PlusCommands.BountiesCommand(this));
        getCommand("correio").setExecutor(new PlusCommands.CorreioCommand(this));
        getCommand("casa").setExecutor(new PlusCommands.CasaCommand(this));
        getCommand("kit").setExecutor(new PlusCommands.KitCommand(this));
        getCommand("nivel").setExecutor(new PlusCommands.NivelCommand(this));
        getCommand("tesouro").setExecutor(new PlusCommands.TesouroCommand(this));
        getCommand("evento").setExecutor(new PlusCommands.EventoCommand(this));

        getLogger().info("SurvivalPlus ativado com sucesso!");
    }

    @Override
    public void onDisable() {
        if (levelManager != null) levelManager.saveData();
        if (bossManager != null) bossManager.stop();
        getLogger().info("SurvivalPlus desativado.");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    // ─── Helpers de economia ───────────────────────────────────────────────────

    public boolean hasBalance(Player p, double amount) { return economy.has(p, amount); }
    public boolean hasBalance(OfflinePlayer p, double amount) { return economy.has(p, amount); }
    public void deposit(Player p, double amount) { economy.depositPlayer(p, amount); }
    public void deposit(OfflinePlayer p, double amount) { economy.depositPlayer(p, amount); }
    public void withdraw(Player p, double amount) { economy.withdrawPlayer(p, amount); }
    public String getEconomyStr(double amount) { return economy.format(amount); }

    // ─── Getters ───────────────────────────────────────────────────────────────

    public static PlusMain getInstance() { return instance; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public BountyManager getBountyManager() { return bountyManager; }
    public BossManager getBossManager() { return bossManager; }
    public HouseManager getHouseManager() { return houseManager; }
    public KitManager getKitManager() { return kitManager; }
    public LevelManager getLevelManager() { return levelManager; }
    public MailManager getMailManager() { return mailManager; }
    public TreasureManager getTreasureManager() { return treasureManager; }
    public Map<UUID, Double> getPendingHousePrices() { return pendingHousePrices; }
    public Set<UUID> getPendingHouseBuys() { return pendingHouseBuys; }
}
