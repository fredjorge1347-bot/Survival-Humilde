package com.survivalhumilde.listeners;

import com.survivalhumilde.PlusMain;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class PlusListener implements Listener {

    private final PlusMain plugin;

    public PlusListener(PlusMain plugin) { this.plugin = plugin; }

    // ─── Kit ao entrar pela primeira vez ───────────────────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Entregar correio
        plugin.getMailManager().deliverOnJoin(player);

        // Kit automático para novos jogadores
        if (!player.hasPlayedBefore() && plugin.getConfig().getBoolean("kit.enabled", true)) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                plugin.getKitManager().giveKit(player);
            }, 40L);
        }

        // Mostrar título com nível
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            String title = plugin.getLevelManager().getFormattedTitle(player.getUniqueId());
            player.sendMessage(ChatColor.GRAY + "Seu titulo: " + title);
        }, 20L);
    }

    // ─── XP por minerar ────────────────────────────────────────────────────────

    @EventHandler
    public void onMine(BlockBreakEvent event) {
        Player player = event.getPlayer();
        int xp = 0;
        switch (event.getBlock().getType()) {
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> xp = 20;
            case EMERALD_ORE, DEEPSLATE_EMERALD_ORE -> xp = 15;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE       -> xp = 8;
            case IRON_ORE, DEEPSLATE_IRON_ORE       -> xp = 5;
            case COAL_ORE, DEEPSLATE_COAL_ORE       -> xp = 3;
            case ANCIENT_DEBRIS                      -> xp = 50;
            default -> xp = plugin.getConfig().getInt("levels.xp-per-mine", 2);
        }
        plugin.getLevelManager().addXp(player.getUniqueId(), xp);
    }

    // ─── XP por matar mob ──────────────────────────────────────────────────────

    @EventHandler
    public void onKill(EntityDeathEvent event) {
        if (event.getEntity().getKiller() == null) return;
        Player killer = event.getEntity().getKiller();
        int xp = plugin.getConfig().getInt("levels.xp-per-kill", 5);
        plugin.getLevelManager().addXp(killer.getUniqueId(), xp);
    }

    // ─── XP por pescar ─────────────────────────────────────────────────────────

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        plugin.getLevelManager().addXp(event.getPlayer().getUniqueId(),
                plugin.getConfig().getInt("levels.xp-per-fish", 3));
    }

    // ─── Bounty ao matar jogador ───────────────────────────────────────────────

    @EventHandler
    public void onPlayerKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return;

        if (plugin.getBountyManager().hasBounty(victim.getUniqueId())) {
            plugin.getBountyManager().claimBounty(killer, victim);
        }

        // XP por matar jogador
        plugin.getLevelManager().addXp(killer.getUniqueId(), 25);
    }

    // ─── Dano ao chefe ─────────────────────────────────────────────────────────

    @EventHandler
    public void onBossDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!plugin.getBossManager().isCurrentBoss(event.getEntity())) return;
        plugin.getBossManager().registerDamage(player.getUniqueId(), event.getFinalDamage());
    }

    @EventHandler
    public void onBossDeath(EntityDeathEvent event) {
        if (!plugin.getBossManager().isCurrentBoss(event.getEntity())) return;
        event.getDrops().clear();
        event.setDroppedExp(0);
        plugin.getBossManager().onBossDeath();
    }

    // ─── Placa de casa (colocar) ───────────────────────────────────────────────

    @EventHandler
    public void onSignPlace(SignChangeEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        if (!plugin.getPendingHousePrices().containsKey(uuid)) return;

        double price = plugin.getPendingHousePrices().remove(uuid);
        Block block = event.getBlock();

        // Registrar a listagem
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getHouseManager().createListing(player, block, price);
        }, 1L);
    }

    // ─── Clique em placa de casa (comprar) ─────────────────────────────────────

    @EventHandler
    public void onSignClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!block.getType().name().endsWith("_SIGN") && block.getType() != Material.OAK_SIGN) return;

        if (!plugin.getHouseManager().isListingSign(block)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        var listing = plugin.getHouseManager().getListing(block);

        if (listing == null) return;

        // Mostrar info ou comprar
        if (listing.getSeller().equals(player.getUniqueId())) {
            player.sendMessage(ChatColor.YELLOW + "Esta e sua casa a venda por "
                    + plugin.getEconomyStr(listing.getPrice()));
            player.sendMessage(ChatColor.GRAY + "Use /casa cancelar para remover.");
        } else {
            player.sendMessage(ChatColor.GOLD + "=== Casa a Venda ===");
            player.sendMessage(ChatColor.YELLOW + "Dono: " + listing.getSellerName());
            player.sendMessage(ChatColor.GREEN + "Preco: " + plugin.getEconomyStr(listing.getPrice()));
            player.sendMessage(ChatColor.GRAY + "Clique novamente para confirmar a compra!");

            // Segundo clique para confirmar
            if (plugin.getPendingHouseBuys().contains(player.getUniqueId())) {
                plugin.getPendingHouseBuys().remove(player.getUniqueId());
                plugin.getHouseManager().buyHouse(player, block);
            } else {
                plugin.getPendingHouseBuys().add(player.getUniqueId());
                Bukkit.getScheduler().runTaskLater(plugin, () ->
                        plugin.getPendingHouseBuys().remove(player.getUniqueId()), 100L);
            }
        }
    }

    // ─── Abrir baú do tesouro ──────────────────────────────────────────────────

    @EventHandler
    public void onChestOpen(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.CHEST) return;

        Player player = event.getPlayer();
        if (!plugin.getTreasureManager().hasActiveTreasure(player.getUniqueId())) return;

        plugin.getTreasureManager().onChestOpen(player, block.getLocation());
    }
}
