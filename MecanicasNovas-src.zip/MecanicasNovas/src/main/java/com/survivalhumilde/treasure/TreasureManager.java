package com.survivalhumilde.treasure;

import com.survivalhumilde.PlusMain;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.*;

import java.util.*;

public class TreasureManager {

    private final PlusMain plugin;
    private final Random random = new Random();

    // UUID -> localização do tesouro ativo
    private final Map<UUID, Location> activeTreasures = new HashMap<>();

    public TreasureManager(PlusMain plugin) { this.plugin = plugin; }

    public boolean createTreasure(Player player) {
        if (activeTreasures.containsKey(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Voce ja tem um tesouro ativo! Procure-o primeiro.");
            return false;
        }

        String worldName = plugin.getConfig().getString("treasure.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);

        // Gerar localização aleatória entre 100 e 3000 blocos
        int x = (random.nextBoolean() ? 1 : -1) * (100 + random.nextInt(2900));
        int z = (random.nextBoolean() ? 1 : -1) * (100 + random.nextInt(2900));

        @SuppressWarnings("deprecation")
        int y = world.getHighestBlockAt(x, z).getY() + 1;

        Location loc = new Location(world, x, y, z);

        // Colocar baú com tesouro
        Block block = world.getBlockAt(loc);
        block.setType(Material.CHEST);

        Chest chest = (Chest) block.getState();
        fillTreasureChest(chest);

        activeTreasures.put(player.getUniqueId(), loc);

        // Dar coordenadas ao jogador
        player.sendMessage(ChatColor.GOLD + "=== Caça ao Tesouro ===");
        player.sendMessage(ChatColor.YELLOW + "Um tesouro foi escondido em:");
        player.sendMessage(ChatColor.WHITE + "X: " + x + " | Z: " + z);
        player.sendMessage(ChatColor.GRAY + "Use /tesouro para ver as coordenadas novamente!");
        player.sendMessage(ChatColor.GRAY + "Procure o bau no chão nessas coordenadas.");

        return true;
    }

    private void fillTreasureChest(Chest chest) {
        double rewardMin = plugin.getConfig().getDouble("treasure.reward-min", 200.0);
        double rewardMax = plugin.getConfig().getDouble("treasure.reward-max", 1000.0);
        double reward = rewardMin + (rewardMax - rewardMin) * random.nextDouble();

        // Itens aleatórios no baú
        List<ItemStack> items = new ArrayList<>();
        items.add(new ItemStack(Material.DIAMOND, 1 + random.nextInt(5)));
        items.add(new ItemStack(Material.GOLD_INGOT, 5 + random.nextInt(15)));
        items.add(new ItemStack(Material.IRON_INGOT, 10 + random.nextInt(20)));
        items.add(new ItemStack(Material.EMERALD, 1 + random.nextInt(3)));

        // Chance de item especial
        int special = random.nextInt(10);
        if (special == 0) items.add(new ItemStack(Material.NETHERITE_INGOT, 1));
        else if (special <= 2) items.add(new ItemStack(Material.DIAMOND_SWORD, 1));
        else if (special <= 4) items.add(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 1));

        // Colocar em slots aleatórios
        Set<Integer> usedSlots = new HashSet<>();
        for (ItemStack item : items) {
            int slot;
            do { slot = random.nextInt(27); } while (usedSlots.contains(slot));
            usedSlots.add(slot);
            chest.getInventory().setItem(slot, item);
        }

        // Guardar recompensa em moedas como papel com lore
        ItemStack reward_note = new ItemStack(Material.PAPER);
        org.bukkit.inventory.meta.ItemMeta meta = reward_note.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Nota de Recompensa");
        meta.setLore(List.of(
                ChatColor.YELLOW + "Valor: " + plugin.getEconomyStr(reward),
                ChatColor.GRAY + "Leve ao spawn para resgatar!",
                ChatColor.WHITE + "TESOURO:" + (int)reward
        ));
        reward_note.setItemMeta(meta);
        chest.getInventory().setItem(0, reward_note);
        chest.update();
    }

    public Location getActiveTreasure(UUID uuid) { return activeTreasures.get(uuid); }

    public void claimTreasure(Player player, double reward) {
        activeTreasures.remove(player.getUniqueId());
        plugin.deposit(player, reward);
        player.sendMessage(ChatColor.GREEN + "Tesouro resgatado! +" + plugin.getEconomyStr(reward));
        Bukkit.broadcastMessage(ChatColor.GOLD + "[Tesouro] " + ChatColor.YELLOW + player.getName()
                + ChatColor.WHITE + " encontrou um tesouro valendo "
                + ChatColor.GREEN + plugin.getEconomyStr(reward) + "!");
    }

    public boolean hasActiveTreasure(UUID uuid) { return activeTreasures.containsKey(uuid); }

    // Chamado quando o jogador abre o baú do tesouro
    public void onChestOpen(Player player, Location loc) {
        Location treasure = activeTreasures.get(player.getUniqueId());
        if (treasure == null) return;
        if (treasure.getBlockX() != loc.getBlockX() ||
            treasure.getBlockY() != loc.getBlockY() ||
            treasure.getBlockZ() != loc.getBlockZ()) return;

        // Verificar nota de recompensa no baú
        org.bukkit.block.Chest chest = (org.bukkit.block.Chest) loc.getBlock().getState();
        ItemStack note = chest.getInventory().getItem(0);
        if (note == null || note.getType() != Material.PAPER) return;
        if (!note.hasItemMeta() || !note.getItemMeta().hasLore()) return;

        for (String lore : note.getItemMeta().getLore()) {
            if (lore.startsWith(ChatColor.WHITE + "TESOURO:")) {
                try {
                    double reward = Double.parseDouble(lore.replace(ChatColor.WHITE + "TESOURO:", "").trim());
                    // Dar XP de nível
                    plugin.getLevelManager().addXp(player.getUniqueId(), 50);
                    Bukkit.getScheduler().runTaskLater(plugin, () -> claimTreasure(player, reward), 1L);
                } catch (NumberFormatException ignored) {}
                break;
            }
        }
    }
}
