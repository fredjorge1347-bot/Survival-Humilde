package com.survivalhumilde.mail;

import com.survivalhumilde.PlusMain;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MailManager {

    private final PlusMain plugin;
    private File dataFile;
    private FileConfiguration dataCfg;

    public MailManager(PlusMain plugin) {
        this.plugin = plugin;
        loadData();
    }

    public void sendMail(String fromName, UUID to, String message) {
        String path = to.toString();
        List<String> messages = dataCfg.getStringList(path);
        messages.add(fromName + "§8: §f" + message);
        dataCfg.set(path, messages);
        saveData();
    }

    public List<String> getMail(UUID uuid) {
        return dataCfg.getStringList(uuid.toString());
    }

    public void clearMail(UUID uuid) {
        dataCfg.set(uuid.toString(), null);
        saveData();
    }

    public boolean hasMail(UUID uuid) {
        List<String> mail = getMail(uuid);
        return !mail.isEmpty();
    }

    public void deliverOnJoin(Player player) {
        List<String> mail = getMail(player.getUniqueId());
        if (mail.isEmpty()) return;

        player.sendMessage(org.bukkit.ChatColor.AQUA + "=== Correio (" + mail.size() + " mensagens) ===");
        for (String msg : mail) {
            player.sendMessage(org.bukkit.ChatColor.GRAY + msg);
        }
        player.sendMessage(org.bukkit.ChatColor.AQUA + "========================");
        clearMail(player.getUniqueId());
    }

    private void loadData() {
        dataFile = new File(plugin.getDataFolder(), "mail.yml");
        dataCfg = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveData() {
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try { dataCfg.save(dataFile); }
            catch (IOException e) { plugin.getLogger().warning("Erro ao salvar correio: " + e.getMessage()); }
        });
    }
}
