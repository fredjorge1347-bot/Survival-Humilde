package com.survivalhumilde.level;

import com.survivalhumilde.PlusMain;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LevelManager {

    private final PlusMain plugin;
    private final Map<UUID, Integer> xpMap = new HashMap<>();

    private File dataFile;
    private FileConfiguration dataCfg;

    // Títulos por nível
    public static final Map<Integer, String[]> LEVELS = new LinkedHashMap<>();
    static {
        //        nível -> {título, cor}
        LEVELS.put(0,   new String[]{"Novato",      "§7"});
        LEVELS.put(5,   new String[]{"Explorador",  "§a"});
        LEVELS.put(15,  new String[]{"Aventureiro", "§b"});
        LEVELS.put(30,  new String[]{"Guerreiro",   "§e"});
        LEVELS.put(50,  new String[]{"Veterano",    "§6"});
        LEVELS.put(75,  new String[]{"Elite",       "§c"});
        LEVELS.put(100, new String[]{"Lendario",    "§5"});
        LEVELS.put(150, new String[]{"Mitico",      "§d"});
    }

    public LevelManager(PlusMain plugin) {
        this.plugin = plugin;
        loadData();
        startXpTimer();
    }

    private void startXpTimer() {
        // XP por minuto jogando
        int xpPerMin = plugin.getConfig().getInt("levels.xp-per-minute", 1);
        org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
                addXp(p.getUniqueId(), xpPerMin);
            }
        }, 1200L, 1200L); // a cada 1 minuto
    }

    public int getXp(UUID uuid) { return xpMap.getOrDefault(uuid, 0); }

    public int getLevel(UUID uuid) {
        int xp = getXp(uuid);
        return xpToLevel(xp);
    }

    public int xpToLevel(int xp) { return (int) Math.floor(Math.sqrt(xp / 10.0)); }

    public int levelToXp(int level) { return level * level * 10; }

    public int xpToNextLevel(UUID uuid) {
        int level = getLevel(uuid);
        return levelToXp(level + 1) - getXp(uuid);
    }

    public void addXp(UUID uuid, int amount) {
        int before = getLevel(uuid);
        xpMap.put(uuid, getXp(uuid) + amount);
        int after = getLevel(uuid);

        if (after > before) {
            org.bukkit.entity.Player p = org.bukkit.Bukkit.getPlayer(uuid);
            if (p != null) {
                p.sendMessage(org.bukkit.ChatColor.GREEN + "Subiu para nivel " + after + "!");
                String[] title = getTitleInfo(after);
                p.sendMessage(org.bukkit.ChatColor.YELLOW + "Titulo: " + title[1] + title[0]);
                p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            }
        }
        saveData();
    }

    public String[] getTitleInfo(int level) {
        String[] result = LEVELS.get(0);
        for (Map.Entry<Integer, String[]> entry : LEVELS.entrySet()) {
            if (level >= entry.getKey()) result = entry.getValue();
        }
        return result;
    }

    public String getFormattedTitle(UUID uuid) {
        int level = getLevel(uuid);
        String[] info = getTitleInfo(level);
        return info[1] + "[" + info[0] + " Lv." + level + "]";
    }

    private void loadData() {
        dataFile = new File(plugin.getDataFolder(), "levels.yml");
        dataCfg = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : dataCfg.getKeys(false)) {
            try { xpMap.put(UUID.fromString(key), dataCfg.getInt(key)); }
            catch (Exception ignored) {}
        }
    }

    public void saveData() {
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            xpMap.forEach((uuid, xp) -> dataCfg.set(uuid.toString(), xp));
            try { dataCfg.save(dataFile); }
            catch (IOException e) { plugin.getLogger().warning("Erro ao salvar levels: " + e.getMessage()); }
        });
    }
}
