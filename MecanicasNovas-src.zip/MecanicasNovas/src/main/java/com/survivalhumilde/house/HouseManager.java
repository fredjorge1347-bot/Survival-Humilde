package com.survivalhumilde.house;

import com.survivalhumilde.PlusMain;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;

import java.util.*;

public class HouseManager {

    private final PlusMain plugin;
    // Location key -> HouseListing
    private final Map<String, HouseListing> listings = new HashMap<>();

    public HouseManager(PlusMain plugin) { this.plugin = plugin; }

    public boolean createListing(Player seller, Block signBlock, double price) {
        String key = locationKey(signBlock.getLocation());

        if (listings.containsKey(key)) {
            seller.sendMessage(ChatColor.RED + "Ja existe uma placa de venda aqui!");
            return false;
        }

        HouseListing listing = new HouseListing(seller.getUniqueId(), seller.getName(),
                signBlock.getLocation(), price);
        listings.put(key, listing);

        // Escrever na placa
        updateSign(signBlock, listing);

        seller.sendMessage(ChatColor.GREEN + "Casa colocada a venda por " + plugin.getEconomyStr(price) + "!");
        seller.sendMessage(ChatColor.GRAY + "Use /casa cancelar para remover a venda.");
        return true;
    }

    public boolean buyHouse(Player buyer, Block signBlock) {
        String key = locationKey(signBlock.getLocation());
        HouseListing listing = listings.get(key);

        if (listing == null) return false;

        if (listing.getSeller().equals(buyer.getUniqueId())) {
            buyer.sendMessage(ChatColor.RED + "Esta e sua propria casa!");
            return false;
        }

        if (!plugin.hasBalance(buyer, listing.getPrice())) {
            buyer.sendMessage(ChatColor.RED + "Saldo insuficiente! Precisa de "
                    + plugin.getEconomyStr(listing.getPrice()));
            return false;
        }

        // Transação
        plugin.withdraw(buyer, listing.getPrice());
        plugin.deposit(Bukkit.getOfflinePlayer(listing.getSeller()), listing.getPrice());

        // Remover placa
        listings.remove(key);
        signBlock.setType(Material.AIR);

        buyer.sendMessage(ChatColor.GREEN + "Casa comprada por " + plugin.getEconomyStr(listing.getPrice()) + "!");
        buyer.sendMessage(ChatColor.GRAY + "A casa e sua agora! Proteja-a com /rg define <nome>");

        Player seller = Bukkit.getPlayer(listing.getSeller());
        if (seller != null) {
            seller.sendMessage(ChatColor.GREEN + buyer.getName() + " comprou sua casa por "
                    + plugin.getEconomyStr(listing.getPrice()) + "!");
        }

        Bukkit.broadcastMessage(ChatColor.GOLD + "[Casa] " + ChatColor.YELLOW + buyer.getName()
                + ChatColor.WHITE + " comprou uma casa de " + ChatColor.YELLOW + listing.getSellerName()
                + ChatColor.WHITE + " por " + ChatColor.GREEN + plugin.getEconomyStr(listing.getPrice()) + "!");

        return true;
    }

    public boolean cancelListing(Player player, Block signBlock) {
        String key = locationKey(signBlock.getLocation());
        HouseListing listing = listings.get(key);

        if (listing == null) {
            // Cancelar qualquer listagem do jogador
            String playerKey = listings.entrySet().stream()
                    .filter(e -> e.getValue().getSeller().equals(player.getUniqueId()))
                    .map(Map.Entry::getKey)
                    .findFirst().orElse(null);

            if (playerKey == null) {
                player.sendMessage(ChatColor.RED + "Voce nao tem nenhuma casa a venda.");
                return false;
            }
            HouseListing pl = listings.remove(playerKey);
            Block sign = pl.getSignLocation().getBlock();
            if (sign.getType() == Material.OAK_SIGN || sign.getType().name().endsWith("_SIGN")) {
                sign.setType(Material.AIR);
            }
            player.sendMessage(ChatColor.YELLOW + "Venda cancelada!");
            return true;
        }

        if (!listing.getSeller().equals(player.getUniqueId()) && !player.hasPermission("survivalplus.admin")) {
            player.sendMessage(ChatColor.RED + "Esta nao e sua casa!");
            return false;
        }

        listings.remove(key);
        signBlock.setType(Material.AIR);
        player.sendMessage(ChatColor.YELLOW + "Venda cancelada!");
        return true;
    }

    public HouseListing getListing(Block signBlock) {
        return listings.get(locationKey(signBlock.getLocation()));
    }

    public boolean isListingSign(Block block) {
        return listings.containsKey(locationKey(block.getLocation()));
    }

    private void updateSign(Block signBlock, HouseListing listing) {
        if (!(signBlock.getState() instanceof Sign sign)) return;

        var lines = sign.getSide(Side.FRONT);
        lines.line(0, net.kyori.adventure.text.Component.text(ChatColor.DARK_GREEN + "[VENDA]"));
        lines.line(1, net.kyori.adventure.text.Component.text(ChatColor.YELLOW + listing.getSellerName()));
        lines.line(2, net.kyori.adventure.text.Component.text(ChatColor.GREEN + plugin.getEconomyStr(listing.getPrice())));
        lines.line(3, net.kyori.adventure.text.Component.text(ChatColor.GRAY + "Clique p/ comprar"));
        sign.update();
    }

    private String locationKey(Location loc) {
        return loc.getWorld().getName() + "_" + loc.getBlockX() + "_" + loc.getBlockY() + "_" + loc.getBlockZ();
    }
}
