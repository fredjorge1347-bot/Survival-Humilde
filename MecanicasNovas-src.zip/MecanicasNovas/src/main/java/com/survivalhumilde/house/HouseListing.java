package com.survivalhumilde.house;

import org.bukkit.Location;
import java.util.UUID;

public class HouseListing {
    private final UUID seller;
    private final String sellerName;
    private final Location signLocation;
    private final double price;

    public HouseListing(UUID seller, String sellerName, Location signLocation, double price) {
        this.seller = seller;
        this.sellerName = sellerName;
        this.signLocation = signLocation;
        this.price = price;
    }

    public UUID getSeller() { return seller; }
    public String getSellerName() { return sellerName; }
    public Location getSignLocation() { return signLocation; }
    public double getPrice() { return price; }
}
