package com.survivalhumilde.commands;

import com.survivalhumilde.PlusMain;
import com.survivalhumilde.auction.AuctionItem;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class PlusCommands {

    // ─── /leilao ───────────────────────────────────────────────────────────────
    public static class LeilaoCommand implements CommandExecutor {
        private final PlusMain plugin;
        public LeilaoCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            if (args.length < 1) { player.sendMessage(ChatColor.RED + "Uso: /leilao <preco> [quantidade]"); return true; }

            double price;
            try { price = Double.parseDouble(args[0]); }
            catch (NumberFormatException e) { player.sendMessage(ChatColor.RED + "Preco invalido."); return true; }

            int qty = args.length > 1 ? Math.max(1, Math.min(64, Integer.parseInt(args[1]))) : 1;

            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) { player.sendMessage(ChatColor.RED + "Segure o item na mao!"); return true; }

            ItemStack toAuction = hand.clone();
            toAuction.setAmount(qty);

            if (plugin.getAuctionManager().createAuction(player, toAuction, price)) {
                player.sendMessage(ChatColor.GREEN + "Item leiloado com sucesso!");
            } else {
                player.sendMessage(ChatColor.RED + "Preco minimo: " + plugin.getEconomyStr(
                        plugin.getConfig().getDouble("auction.min-price", 10.0)));
            }
            return true;
        }
    }

    // ─── /lances ───────────────────────────────────────────────────────────────
    public static class LancesCommand implements CommandExecutor {
        private final PlusMain plugin;
        public LancesCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            var auctions = plugin.getAuctionManager().getAll();
            if (auctions.isEmpty()) { player.sendMessage(ChatColor.YELLOW + "Nenhum leilao ativo."); return true; }

            player.sendMessage(ChatColor.GOLD + "=== Leiloes Ativos ===");
            for (AuctionItem a : auctions) {
                String item = a.getItem().getType().name().replace("_", " ");
                String top = a.getTopBidder() != null ? a.getTopBidderName() : "Nenhum";
                player.sendMessage(ChatColor.YELLOW + "#" + a.getId() + " " + ChatColor.WHITE + item + " x" + a.getItem().getAmount()
                        + ChatColor.GRAY + " - Lance: " + ChatColor.GREEN + plugin.getEconomyStr(a.getCurrentBid())
                        + ChatColor.GRAY + " - Top: " + top + " - Dono: " + a.getSellerName());
            }
            player.sendMessage(ChatColor.GRAY + "Use /lance <id> <valor> para dar um lance!");
            return true;
        }
    }

    // ─── /lance ────────────────────────────────────────────────────────────────
    public static class LanceCommand implements CommandExecutor {
        private final PlusMain plugin;
        public LanceCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            if (args.length < 2) { player.sendMessage(ChatColor.RED + "Uso: /lance <id> <valor>"); return true; }
            try {
                int id = Integer.parseInt(args[0]);
                double value = Double.parseDouble(args[1]);
                plugin.getAuctionManager().placeBid(player, id, value);
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "ID ou valor invalido.");
            }
            return true;
        }
    }

    // ─── /bounty ───────────────────────────────────────────────────────────────
    public static class BountyCommand implements CommandExecutor {
        private final PlusMain plugin;
        public BountyCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            if (args.length < 2) { player.sendMessage(ChatColor.RED + "Uso: /bounty <jogador> <valor>"); return true; }

            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { player.sendMessage(ChatColor.RED + "Jogador nao encontrado ou offline."); return true; }

            double value;
            try { value = Double.parseDouble(args[1]); }
            catch (NumberFormatException e) { player.sendMessage(ChatColor.RED + "Valor invalido."); return true; }

            plugin.getBountyManager().addBounty(player, target, value);
            return true;
        }
    }

    // ─── /bounties ─────────────────────────────────────────────────────────────
    public static class BountiesCommand implements CommandExecutor {
        private final PlusMain plugin;
        public BountiesCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            var all = plugin.getBountyManager().getAllBounties();
            if (all.isEmpty()) { player.sendMessage(ChatColor.YELLOW + "Nenhuma recompensa ativa."); return true; }

            player.sendMessage(ChatColor.RED + "=== Recompensas Ativas ===");
            all.forEach((uuid, value) -> {
                String name = plugin.getBountyManager().getName(uuid);
                player.sendMessage(ChatColor.YELLOW + name + ChatColor.WHITE + ": "
                        + ChatColor.GREEN + plugin.getEconomyStr(value));
            });
            return true;
        }
    }

    // ─── /correio ──────────────────────────────────────────────────────────────
    public static class CorreioCommand implements CommandExecutor {
        private final PlusMain plugin;
        public CorreioCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            if (args.length < 2) { player.sendMessage(ChatColor.RED + "Uso: /correio <jogador> <mensagem>"); return true; }

            String targetName = args[0];
            String message = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

            // Checar se jogador existe
            @SuppressWarnings("deprecation")
            org.bukkit.OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
            if (!target.hasPlayedBefore() && !target.isOnline()) {
                player.sendMessage(ChatColor.RED + "Jogador nao encontrado.");
                return true;
            }

            // Se online, entregar direto
            Player online = Bukkit.getPlayer(target.getUniqueId());
            if (online != null) {
                online.sendMessage(ChatColor.AQUA + "[Correio] " + player.getName() + ": " + ChatColor.WHITE + message);
                player.sendMessage(ChatColor.GREEN + "Mensagem entregue diretamente a " + targetName + "!");
            } else {
                plugin.getMailManager().sendMail(player.getName(), target.getUniqueId(), message);
                player.sendMessage(ChatColor.GREEN + "Mensagem enviada! " + targetName + " vai receber ao entrar.");
            }
            return true;
        }
    }

    // ─── /casa ─────────────────────────────────────────────────────────────────
    public static class CasaCommand implements CommandExecutor {
        private final PlusMain plugin;
        public CasaCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }

            if (args.length == 0) {
                player.sendMessage(ChatColor.GOLD + "=== Sistema de Casas ===");
                player.sendMessage(ChatColor.YELLOW + "/casa vender <preco> " + ChatColor.GRAY + "- Coloque uma placa e use este comando");
                player.sendMessage(ChatColor.YELLOW + "/casa cancelar " + ChatColor.GRAY + "- Cancelar venda");
                player.sendMessage(ChatColor.GRAY + "Dica: Coloque uma placa na porta da casa e use /casa vender <preco>!");
                return true;
            }

            switch (args[0].toLowerCase()) {
                case "vender" -> {
                    if (args.length < 2) { player.sendMessage(ChatColor.RED + "Uso: /casa vender <preco>"); return true; }
                    double price;
                    try { price = Double.parseDouble(args[1]); }
                    catch (NumberFormatException e) { player.sendMessage(ChatColor.RED + "Preco invalido."); return true; }

                    // Verificar placa na mão
                    ItemStack hand = player.getInventory().getItemInMainHand();
                    if (!hand.getType().name().endsWith("_SIGN") && hand.getType() != Material.OAK_SIGN) {
                        player.sendMessage(ChatColor.RED + "Segure uma placa na mao e olhe para onde quer colocar!");
                        player.sendMessage(ChatColor.GRAY + "Dica: Primeiro coloque a placa no chão/parede, depois use /casa vender <preco>");
                        return true;
                    }
                    player.sendMessage(ChatColor.YELLOW + "Coloque a placa onde quiser e o sistema vai registrar automaticamente!");
                    player.sendMessage(ChatColor.GRAY + "Preco definido: " + plugin.getEconomyStr(price));
                    // Guardar preço temporariamente
                    plugin.getPendingHousePrices().put(player.getUniqueId(), price);
                }
                case "cancelar" -> {
                    org.bukkit.block.Block looking = player.getTargetBlockExact(5);
                    if (looking != null) {
                        plugin.getHouseManager().cancelListing(player, looking);
                    } else {
                        plugin.getHouseManager().cancelListing(player, null);
                    }
                }
                default -> player.sendMessage(ChatColor.RED + "Uso: /casa <vender|cancelar>");
            }
            return true;
        }
    }

    // ─── /kit ──────────────────────────────────────────────────────────────────
    public static class KitCommand implements CommandExecutor {
        private final PlusMain plugin;
        public KitCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }
            plugin.getKitManager().giveKit(player);
            return true;
        }
    }

    // ─── /nivel ────────────────────────────────────────────────────────────────
    public static class NivelCommand implements CommandExecutor {
        private final PlusMain plugin;
        public NivelCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }

            UUID target = player.getUniqueId();
            String name = player.getName();

            if (args.length > 0) {
                @SuppressWarnings("deprecation")
                org.bukkit.OfflinePlayer op = Bukkit.getOfflinePlayer(args[0]);
                if (op.hasPlayedBefore()) { target = op.getUniqueId(); name = op.getName(); }
            }

            int level = plugin.getLevelManager().getLevel(target);
            int xp = plugin.getLevelManager().getXp(target);
            int toNext = plugin.getLevelManager().xpToNextLevel(target);
            String title = plugin.getLevelManager().getFormattedTitle(target);

            player.sendMessage(ChatColor.GOLD + "=== Nivel de " + name + " ===");
            player.sendMessage(ChatColor.YELLOW + "Titulo: " + title);
            player.sendMessage(ChatColor.YELLOW + "Nivel: " + ChatColor.WHITE + level);
            player.sendMessage(ChatColor.YELLOW + "XP: " + ChatColor.WHITE + xp
                    + ChatColor.GRAY + " (+" + toNext + " para proximo nivel)");
            return true;
        }
    }

    // ─── /tesouro ──────────────────────────────────────────────────────────────
    public static class TesouroCommand implements CommandExecutor {
        private final PlusMain plugin;
        public TesouroCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores."); return true; }

            if (plugin.getTreasureManager().hasActiveTreasure(player.getUniqueId())) {
                org.bukkit.Location loc = plugin.getTreasureManager().getActiveTreasure(player.getUniqueId());
                player.sendMessage(ChatColor.GOLD + "=== Seu Tesouro Ativo ===");
                player.sendMessage(ChatColor.YELLOW + "X: " + (int)loc.getX() + " | Z: " + (int)loc.getZ());
                player.sendMessage(ChatColor.GRAY + "Procure o bau nessas coordenadas!");
            } else {
                plugin.getTreasureManager().createTreasure(player);
            }
            return true;
        }
    }

    // ─── /evento ───────────────────────────────────────────────────────────────
    public static class EventoCommand implements CommandExecutor {
        private final PlusMain plugin;
        public EventoCommand(PlusMain p) { plugin = p; }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!sender.hasPermission("survivalplus.admin")) {
                sender.sendMessage(ChatColor.RED + "Sem permissao.");
                return true;
            }
            plugin.getBossManager().spawnBoss();
            sender.sendMessage(ChatColor.GREEN + "Evento de chefe iniciado!");
            return true;
        }
    }
}
