package com.survivalhumilde.boss;

import com.survivalhumilde.PlusMain;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class BossManager {

    private final PlusMain plugin;
    private BukkitTask bossTask;
    private Entity currentBoss = null;
    private final Map<UUID, Double> damageMap = new HashMap<>();

    public BossManager(PlusMain plugin) {
        this.plugin = plugin;
        scheduleNextBoss();
    }

    private void scheduleNextBoss() {
        int hours = plugin.getConfig().getInt("boss.interval-hours", 2);
        long ticks = hours * 60L * 60L * 20L;

        bossTask = Bukkit.getScheduler().runTaskLater(plugin, this::spawnBoss, ticks);
    }

    public void spawnBoss() {
        if (Bukkit.getOnlinePlayers().isEmpty()) {
            scheduleNextBoss();
            return;
        }

        String worldName = plugin.getConfig().getString("boss.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);

        // Spawnar próximo a um jogador aleatório
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        Player randomPlayer = players.get(new Random().nextInt(players.size()));
        Location loc = randomPlayer.getLocation().add(
                new Random().nextInt(50) - 25, 0, new Random().nextInt(50) - 25);
        loc.setY(world.getHighestBlockAt(loc).getY() + 1);

        // Spawnar Wither como chefe
        Wither boss = (Wither) world.spawnEntity(loc, EntityType.WITHER);
        boss.setCustomName(ChatColor.RED + "" + ChatColor.BOLD + "CHEFE DO MUNDO");
        boss.setCustomNameVisible(true);

        // 500 de vida
        Objects.requireNonNull(boss.getAttribute(Attribute.MAX_HEALTH)).setBaseValue(500.0);
        boss.setHealth(500.0);

        currentBoss = boss;
        damageMap.clear();

        Bukkit.broadcastMessage(ChatColor.RED + "");
        Bukkit.broadcastMessage(ChatColor.DARK_RED + "★ CHEFE DO MUNDO APARECEU! ★");
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Local: " + (int)loc.getX() + ", " + (int)loc.getY() + ", " + (int)loc.getZ());
        Bukkit.broadcastMessage(ChatColor.WHITE + "Derrotem-no para ganhar recompensas!");
        Bukkit.broadcastMessage(ChatColor.RED + "");
    }

    public void registerDamage(UUID uuid, double damage) {
        damageMap.merge(uuid, damage, Double::sum);
    }

    public boolean isCurrentBoss(Entity entity) {
        return currentBoss != null && currentBoss.equals(entity);
    }

    public void onBossDeath() {
        if (damageMap.isEmpty()) {
            scheduleNextBoss();
            return;
        }

        // Calcular total de dano
        double totalDamage = damageMap.values().stream().mapToDouble(Double::doubleValue).sum();

        // Recompensar por dano proporcional
        double totalReward = 5000.0;

        Bukkit.broadcastMessage(ChatColor.GOLD + "★ CHEFE DERROTADO! ★");
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Recompensas distribuidas por dano causado:");

        // Top 3 recebem bônus extra
        List<Map.Entry<UUID, Double>> sorted = new ArrayList<>(damageMap.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        int rank = 1;
        for (Map.Entry<UUID, Double> entry : sorted) {
            UUID uuid = entry.getKey();
            double dmg = entry.getValue();
            double share = (dmg / totalDamage) * totalReward;

            // Bônus para top 3
            if (rank == 1) share *= 2.0;
            else if (rank == 2) share *= 1.5;
            else if (rank == 3) share *= 1.2;

            plugin.deposit(Bukkit.getOfflinePlayer(uuid), share);

            Player p = Bukkit.getPlayer(uuid);
            String name = p != null ? p.getName() : "Jogador";
            String medal = rank == 1 ? "🥇" : rank == 2 ? "🥈" : rank == 3 ? "🥉" : "  ";

            Bukkit.broadcastMessage(ChatColor.YELLOW + medal + " " + rank + ". " + name
                    + ChatColor.WHITE + " - " + String.format("%.0f", dmg) + " dano"
                    + ChatColor.GREEN + " → +" + plugin.getEconomyStr(share));
            rank++;
        }

        currentBoss = null;
        damageMap.clear();
        scheduleNextBoss();
    }

    public void stop() {
        if (bossTask != null) bossTask.cancel();
    }

    public Entity getCurrentBoss() { return currentBoss; }
}
