package com.survivalhumilde.auction;

import com.survivalhumilde.PlusMain;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class AuctionManager {

    private final PlusMain plugin;
    private final List<AuctionItem> auctions = new ArrayList<>();
    private int nextId = 1;

    public AuctionManager(PlusMain plugin) { this.plugin = plugin; }

    public boolean createAuction(Player seller, ItemStack item, double startPrice) {
        if (item == null || item.getType().isAir()) return false;

        double minPrice = plugin.getConfig().getDouble("auction.min-price", 10.0);
        if (startPrice < minPrice) return false;

        int durationMin = plugin.getConfig().getInt("auction.duration-minutes", 10);

        AuctionItem auction = new AuctionItem(nextId++, seller.getUniqueId(),
                seller.getName(), item.clone(), startPrice);

        // Remover item do inventário
        seller.getInventory().removeItem(item);
        auctions.add(auction);

        // Anunciar
        Bukkit.broadcastMessage(ChatColor.GOLD + "[Leilao] " + ChatColor.YELLOW + seller.getName()
                + ChatColor.WHITE + " leiloou " + ChatColor.AQUA + getItemName(item)
                + ChatColor.WHITE + " por " + ChatColor.GREEN + plugin.getEconomyStr(startPrice) + "!");
        Bukkit.broadcastMessage(ChatColor.GRAY + "Use /lance " + auction.getId() + " <valor> para dar um lance!");

        // Timer de expiração
        Bukkit.getScheduler().runTaskLater(plugin, () -> expireAuction(auction),
                durationMin * 60L * 20L);

        return true;
    }

    public boolean placeBid(Player bidder, int auctionId, double amount) {
        AuctionItem auction = getById(auctionId);
        if (auction == null) return false;
        if (auction.getSeller().equals(bidder.getUniqueId())) {
            bidder.sendMessage(ChatColor.RED + "Voce nao pode dar lance no seu proprio leilao!");
            return false;
        }
        if (amount <= auction.getCurrentBid()) {
            bidder.sendMessage(ChatColor.RED + "Lance deve ser maior que " + plugin.getEconomyStr(auction.getCurrentBid()));
            return false;
        }
        if (!plugin.hasBalance(bidder, amount)) {
            bidder.sendMessage(ChatColor.RED + "Saldo insuficiente!");
            return false;
        }

        // Devolver dinheiro ao lance anterior
        if (auction.getTopBidder() != null) {
            OfflinePlayer prev = Bukkit.getOfflinePlayer(auction.getTopBidder());
            plugin.deposit(prev, auction.getCurrentBid());
            Player prevOnline = Bukkit.getPlayer(auction.getTopBidder());
            if (prevOnline != null)
                prevOnline.sendMessage(ChatColor.YELLOW + "Seu lance no leilao #" + auctionId + " foi superado! Dinheiro devolvido.");
        }

        // Cobrar novo lance
        plugin.withdraw(bidder, amount);
        auction.setTopBidder(bidder.getUniqueId(), bidder.getName(), amount);

        Bukkit.broadcastMessage(ChatColor.GOLD + "[Leilao #" + auctionId + "] " + ChatColor.YELLOW + bidder.getName()
                + ChatColor.WHITE + " deu lance de " + ChatColor.GREEN + plugin.getEconomyStr(amount) + "!");

        return true;
    }

    private void expireAuction(AuctionItem auction) {
        auctions.remove(auction);

        if (auction.getTopBidder() == null) {
            // Sem lances — devolver item ao vendedor
            Player seller = Bukkit.getPlayer(auction.getSeller());
            if (seller != null) {
                seller.getInventory().addItem(auction.getItem());
                seller.sendMessage(ChatColor.YELLOW + "Seu leilao expirou sem lances. Item devolvido!");
            }
            return;
        }

        // Venda concluída
        plugin.deposit(Bukkit.getOfflinePlayer(auction.getSeller()), auction.getCurrentBid());

        Player winner = Bukkit.getPlayer(auction.getTopBidder());
        if (winner != null) {
            winner.getInventory().addItem(auction.getItem());
            winner.sendMessage(ChatColor.GREEN + "Voce ganhou o leilao #" + auction.getId()
                    + "! Item adicionado ao inventario.");
        }

        Player seller = Bukkit.getPlayer(auction.getSeller());
        if (seller != null)
            seller.sendMessage(ChatColor.GREEN + "Seu leilao #" + auction.getId() + " foi vendido por "
                    + plugin.getEconomyStr(auction.getCurrentBid()) + "!");

        Bukkit.broadcastMessage(ChatColor.GOLD + "[Leilao] " + ChatColor.YELLOW + auction.getTopBidderName()
                + ChatColor.WHITE + " venceu o leilao de " + ChatColor.AQUA + getItemName(auction.getItem())
                + ChatColor.WHITE + " por " + ChatColor.GREEN + plugin.getEconomyStr(auction.getCurrentBid()) + "!");
    }

    public AuctionItem getById(int id) {
        return auctions.stream().filter(a -> a.getId() == id).findFirst().orElse(null);
    }

    public List<AuctionItem> getAll() { return Collections.unmodifiableList(auctions); }

    private String getItemName(ItemStack item) {
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName())
            return item.getItemMeta().getDisplayName();
        return item.getType().name().replace("_", " ");
    }
}
