package com.survivalhumilde.auction;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class AuctionItem {
    private final int id;
    private final UUID seller;
    private final String sellerName;
    private final ItemStack item;
    private double currentBid;
    private UUID topBidder;
    private String topBidderName;

    public AuctionItem(int id, UUID seller, String sellerName, ItemStack item, double startPrice) {
        this.id = id;
        this.seller = seller;
        this.sellerName = sellerName;
        this.item = item;
        this.currentBid = startPrice;
    }

    public int getId() { return id; }
    public UUID getSeller() { return seller; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItem() { return item; }
    public double getCurrentBid() { return currentBid; }
    public UUID getTopBidder() { return topBidder; }
    public String getTopBidderName() { return topBidderName; }

    public void setTopBidder(UUID uuid, String name, double bid) {
        this.topBidder = uuid;
        this.topBidderName = name;
        this.currentBid = bid;
    }
}
