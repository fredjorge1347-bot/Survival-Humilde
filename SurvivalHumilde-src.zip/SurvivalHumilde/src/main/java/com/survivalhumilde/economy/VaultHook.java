package com.survivalhumilde.economy;

import com.survivalhumilde.Main;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

/**
 * Registra o sistema de economia interno no Vault.
 * Isso permite que QuickShop-Hikari e outros plugins reconheçam o saldo.
 */
public class VaultHook implements Economy {

    private final Main plugin;
    private final SurvivalEconomy eco;
    private boolean registered = false;

    public VaultHook(Main plugin, SurvivalEconomy eco) {
        this.plugin = plugin;
        this.eco = eco;
    }

    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) return false;
        plugin.getServer().getServicesManager().register(Economy.class, this, plugin, ServicePriority.High);
        registered = true;
        return true;
    }

    public void unregister() {
        if (registered) {
            plugin.getServer().getServicesManager().unregister(Economy.class, this);
        }
    }

    // ─── Implementação da interface Economy do Vault ────────────────────────────

    @Override public boolean isEnabled() { return true; }
    @Override public String getName() { return "SurvivalHumilde"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) { return eco.format(amount); }
    @Override public String currencyNamePlural() { return eco.getCurrencyNamePlural(); }
    @Override public String currencyNameSingular() { return eco.getCurrencyName(); }

    @Override
    public boolean hasAccount(OfflinePlayer player) { return eco.hasAccount(player); }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) { return eco.hasAccount(player); }

    @Override
    public double getBalance(OfflinePlayer player) { return eco.getBalance(player); }

    @Override
    public double getBalance(OfflinePlayer player, String world) { return eco.getBalance(player); }

    @Override
    public boolean has(OfflinePlayer player, double amount) { return eco.has(player, amount); }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) { return eco.has(player, amount); }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) return new EconomyResponse(0, eco.getBalance(player),
                EconomyResponse.ResponseType.FAILURE, "Valor negativo.");
        if (!eco.has(player, amount)) return new EconomyResponse(0, eco.getBalance(player),
                EconomyResponse.ResponseType.FAILURE, "Saldo insuficiente.");
        eco.withdraw(player, amount);
        return new EconomyResponse(amount, eco.getBalance(player), EconomyResponse.ResponseType.SUCCESS, "");
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdrawPlayer(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) return new EconomyResponse(0, eco.getBalance(player),
                EconomyResponse.ResponseType.FAILURE, "Valor negativo.");
        eco.deposit(player, amount);
        return new EconomyResponse(amount, eco.getBalance(player), EconomyResponse.ResponseType.SUCCESS, "");
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return depositPlayer(player, amount);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) { return true; }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) { return true; }

    // ─── Métodos de banco (não suportados) ─────────────────────────────────────

    @Override public EconomyResponse createBank(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse deleteBank(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse bankBalance(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse bankHas(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse bankWithdraw(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse bankDeposit(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Sem suporte a bancos.");
    }
    @Override public java.util.List<String> getBanks() { return java.util.Collections.emptyList(); }

    // ─── Métodos deprecated por String (delegam para OfflinePlayer) ────────────

    @Override @Deprecated public boolean hasAccount(String playerName) { return true; }
    @Override @Deprecated public boolean hasAccount(String playerName, String worldName) { return true; }
    @Override @Deprecated public double getBalance(String playerName) { return 0; }
    @Override @Deprecated public double getBalance(String playerName, String world) { return 0; }
    @Override @Deprecated public boolean has(String playerName, double amount) { return false; }
    @Override @Deprecated public boolean has(String playerName, String worldName, double amount) { return false; }
    @Override @Deprecated public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Use UUID.");
    }
    @Override @Deprecated public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Use UUID.");
    }
    @Override @Deprecated public EconomyResponse depositPlayer(String playerName, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Use UUID.");
    }
    @Override @Deprecated public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Use UUID.");
    }
    @Override @Deprecated public boolean createPlayerAccount(String playerName) { return true; }
    @Override @Deprecated public boolean createPlayerAccount(String playerName, String worldName) { return true; }
}
