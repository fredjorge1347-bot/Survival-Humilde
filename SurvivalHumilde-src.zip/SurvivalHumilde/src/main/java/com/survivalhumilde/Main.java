package com.survivalhumilde;

import com.survivalhumilde.commands.*;
import com.survivalhumilde.economy.SurvivalEconomy;
import com.survivalhumilde.economy.VaultHook;
import com.survivalhumilde.games.ChatGames;
import com.survivalhumilde.listeners.AutoLockListener;
import com.survivalhumilde.listeners.PlayerListener;
import com.survivalhumilde.managers.DataManager;
import com.survivalhumilde.managers.HomeManager;
import com.survivalhumilde.managers.TpaManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    private static Main instance;
    private SurvivalEconomy economy;
    private DataManager dataManager;
    private HomeManager homeManager;
    private TpaManager tpaManager;
    private ChatGames chatGames;
    private VaultHook vaultHook;

    @Override
    public void onEnable() {
        instance = this;

        // Salvar config padrão
        saveDefaultConfig();

        // Inicializar managers
        dataManager = new DataManager(this);
        homeManager = new HomeManager(this);
        tpaManager = new TpaManager(this);

        // Inicializar economia interna
        economy = new SurvivalEconomy(this);

        // Registrar hook do Vault (obrigatório para QuickShop etc.)
        vaultHook = new VaultHook(this, economy);
        if (!vaultHook.setup()) {
            getLogger().warning("Vault nao encontrado! Economia nao sera registrada no Vault.");
        } else {
            getLogger().info("Vault registrado com sucesso!");
        }

        // Registrar listeners
        getServer().getPluginManager().registerEvents(new AutoLockListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        // Registrar comandos
        getCommand("money").setExecutor(new MoneyCommand(this));
        getCommand("pay").setExecutor(new PayCommand(this));
        getCommand("spawn").setExecutor(new SpawnCommand(this));
        getCommand("sethome").setExecutor(new SetHomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("tpa").setExecutor(new TpaCommand(this));
        getCommand("tpaccept").setExecutor(new TpAcceptCommand(this));
        getCommand("tpdeny").setExecutor(new TpDenyCommand(this));
        getCommand("rtp").setExecutor(new RtpCommand(this));
        getCommand("servico").setExecutor(new ServicoCommand(this));
        getCommand("setspawn").setExecutor(new SetSpawnCommand(this));

        // Iniciar Chat Games
        chatGames = new ChatGames(this);
        chatGames.start();

        getLogger().info("SurvivalHumilde ativado com sucesso!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.saveAll();
        if (chatGames != null) chatGames.stop();
        if (vaultHook != null) vaultHook.unregister();
        getLogger().info("SurvivalHumilde desativado.");
    }

    public static Main getInstance() { return instance; }
    public SurvivalEconomy getEconomy() { return economy; }
    public DataManager getDataManager() { return dataManager; }
    public HomeManager getHomeManager() { return homeManager; }
    public TpaManager getTpaManager() { return tpaManager; }
}
